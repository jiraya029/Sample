// Boots the app in-process with a mocked Gemini and exercises /api/session/turn
// over real HTTP, plus the validation / auth / CSRF guards around it.
// Run: node test/http_stream_test.js
// Optionally set DATABASE_URL to a scratch Postgres to also exercise the
// DB-backed auth/signup/admin paths for real instead of expecting 503s.
process.env.AWS_BEARER_TOKEN_BEDROCK = 'test-key';
const path = require('path');
const jwt = require('jsonwebtoken');
const realFetch = global.fetch;

// Fake Bedrock text model: streams the turn as tool-use JSON fragments; answers scoring with a tool result.
const bedrock = require(path.join(__dirname, '..', 'lib', 'bedrock.js'));
const frags = ['{"reply": "This is the third', ' time this week. Just fix it.",', ' "satisfaction": 15, "status": "ongoing"}'];
bedrock._setClient({
  send: async (cmd) => {
    if (cmd.constructor.name === 'ConverseStreamCommand') {
      async function* stream() {
        yield { contentBlockStart: { start: { toolUse: { toolUseId: 't', name: 'turn' } } } };
        for (const f of frags) { await new Promise(r => setTimeout(r, 5)); yield { contentBlockDelta: { delta: { toolUse: { input: f } } } }; }
        yield { messageStop: { stopReason: 'tool_use' } };
      }
      return { stream: stream() };
    }
    const name = cmd.input.toolConfig.toolChoice.tool.name;
    const input = name === 'gauge' ? { satisfaction: 41, status: 'ongoing' }
      : { overall_score: 72, empathy: 70, technical_accuracy: 68, resolution: 75, communication: 74, verdict: 'Solid, a little slow to confirm.', strengths: ['Acknowledged urgency'], improvements: ['Confirm the fix'] };
    return { output: { message: { content: [{ toolUse: { toolUseId: 't', name, input } }] } } };
  }
});

// Fake Nova Sonic for the WebSocket test.
const voice = require(path.join(__dirname, '..', 'lib', 'voice.js'));
voice._setClient({
  send: async (cmd) => {
    (async () => { for await (const c of cmd.input.body) { /* drain */ } })();
    async function* body() {
      const ev = (e) => ({ chunk: { bytes: Buffer.from(JSON.stringify({ event: e })) } });
      await new Promise(r => setTimeout(r, 5));
      yield ev({ contentStart: { contentName: 'a1', role: 'ASSISTANT', type: 'TEXT', additionalModelFields: '{"generationStage":"FINAL"}' } });
      yield ev({ textOutput: { contentName: 'a1', role: 'ASSISTANT', content: 'Hi, my internet is down and I have a demo in ten minutes.' } });
      yield ev({ contentEnd: { contentName: 'a1', type: 'TEXT', stopReason: 'END_TURN' } });
      yield ev({ contentStart: { contentName: 'a2', role: 'ASSISTANT', type: 'AUDIO' } });
      yield ev({ audioOutput: { contentName: 'a2', content: Buffer.alloc(480, 7).toString('base64') } });
      yield ev({ contentEnd: { contentName: 'a2', type: 'AUDIO', stopReason: 'END_TURN' } });
      yield ev({ contentStart: { contentName: 'u1', role: 'USER', type: 'TEXT' } });
      yield ev({ textOutput: { contentName: 'u1', role: 'USER', content: 'So sorry about that, are you on Wi-Fi or a cable right now?' } });
      yield ev({ contentEnd: { contentName: 'u1', type: 'TEXT', stopReason: 'END_TURN' } });
      await new Promise(r => setTimeout(r, 5000)); // stay open until hang-up
    }
    return { body: body() };
  }
});

const app = require(path.join(__dirname, '..', 'server.js'));
const WebSocket = require('ws');
const db = require(path.join(__dirname, '..', 'db.js'));
const auth = require(path.join(__dirname, '..', 'auth.js'));
const hasDb = Boolean(process.env.DATABASE_URL);
const PORT = 4101;
const base = 'http://localhost:' + PORT;

const server = app.createServer();
server.listen(PORT, async () => {
  let failures = 0;
  const check = (label, cond, detail) => { console.log((cond ? 'PASS ' : 'FAIL ') + label + (detail ? '  -> ' + detail : '')); if (!cond) failures++; };

  // With a real DB, seed matching rows so tokens have a genuine session_epoch to
  // check against - otherwise every authed request would (correctly) 401 as
  // "signed out" for a user id that doesn't exist, which would make these tests
  // about the seeding gap instead of the route logic they're meant to cover.
  let token, adminToken;
  if (hasDb) {
    await db.initSchema();
    await db.query('TRUNCATE users, reports, otp_codes RESTART IDENTITY CASCADE');
    const plainUser = await db.createUser({ name: 'Test Agent', email: 'agent@example.com', sapId: 'AGT-1', passwordHash: await auth.hashPassword('agentpass1'), project: 'P', lob: 'L' });
    await db.markEmailVerified(plainUser.id);
    const adminUser = await db.createUser({ name: 'Admin', email: 'admin@example.com', sapId: 'ADM-1', passwordHash: await auth.hashPassword('adminpass1'), project: 'P', lob: 'L' });
    await db.query("UPDATE users SET role = 'admin' WHERE id = $1", [adminUser.id]);
    await db.markEmailVerified(adminUser.id);
    token = auth.issueToken({ ...plainUser, session_epoch: 1 });
    adminToken = auth.issueToken({ ...adminUser, role: 'admin', session_epoch: 1 });
  } else {
    token = jwt.sign({ sub: 1, role: 'user', name: 'Test Agent', ep: 1 }, 'dev-secret-change-me', { algorithm: 'HS256' });
    adminToken = jwt.sign({ sub: 999, role: 'admin', name: 'Admin', ep: 1 }, 'dev-secret-change-me', { algorithm: 'HS256' });
  }
  const H = { 'Content-Type': 'application/json', Cookie: 'sdt_token=' + token };
  const post = (p, body, headers) => realFetch(base + p, { method: 'POST', headers: { ...H, ...(headers || {}) }, body: JSON.stringify(body) });

  const res = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [] }, { Origin: base });
  const text = await res.text();
  const events = [...text.matchAll(/event: (\w+)\ndata: (.*)\n/g)].map(m => [m[1], JSON.parse(m[2])]);
  const done = events.find(e => e[0] === 'done');
  check('SSE status 200 + event-stream', res.status === 200 && /text\/event-stream/.test(res.headers.get('content-type')), res.status + ' ' + res.headers.get('content-type'));
  check('SSE emits partial events', events.some(e => e[0] === 'partial'), events.map(e => e[0]).join(','));
  check('SSE done payload correct', done && done[1].satisfaction === 15 && done[1].status === 'ongoing' && done[1].reply.endsWith('fix it.'), done && JSON.stringify(done[1]));

  let r = await post('/api/session/turn', { moodId: 'nope', scenarioId: 'network', history: [] });
  check('unknown mood -> 400', r.status === 400, await r.text());
  r = await realFetch(base + '/api/session/turn', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  check('no auth -> 401', r.status === 401, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [] }, { Origin: 'https://evil.example' });
  check('cross-origin POST -> 403', r.status === 403, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: Array(61).fill({ role: 'agent', text: 'hi' }) });
  check('61 turns -> 400', r.status === 400, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [{ role: 'hacker', text: 'x' }] });
  check('malformed history -> 400', r.status === 400, await r.text());
  r = await realFetch(base + '/api/reports');
  check('anon /api/reports -> 401 (no DB wake)', r.status === 401, await r.text());
  r = await realFetch(base + '/api/reports', { headers: { Cookie: 'sdt_token=' + token } });
  const reportsBody = hasDb ? await r.json().catch(() => null) : null;
  check(hasDb ? 'authed /api/reports with DB -> 200 []' : 'authed /api/reports without DB -> 503', hasDb ? (r.status === 200 && Array.isArray(reportsBody)) : r.status === 503, r.status);
  r = await realFetch(base + '/api/catalog');
  const cat = await r.json();
  check('catalog hides personas', !JSON.stringify(cat).includes('persona') && cat.moods.length === 6 && cat.scenarios.length === 10);

  // Security headers + CSP hygiene
  r = await realFetch(base + '/login');
  const csp = r.headers.get('content-security-policy') || '';
  check('CSP header present, no unsafe-inline scripts', /script-src 'self'/.test(csp) && !/script-src[^;]*unsafe-inline/.test(csp), csp.slice(0, 60));
  const fs = require('fs');
  const inline = fs.readdirSync(path.join(__dirname, '..', 'public')).filter(f => f.endsWith('.html')).filter(f => /<script(?![^>]*\bsrc=)/.test(fs.readFileSync(path.join(__dirname, '..', 'public', f), 'utf8')));
  check('no inline <script> blocks in pages', inline.length === 0, inline.join(','));
  check('X-Frame-Options DENY', r.headers.get('x-frame-options') === 'DENY');

  // OTP helpers
  const otp = auth.newOtp(7, 'login');
  check('OTP is 6 digits', /^\d{6}$/.test(otp.code), otp.code);
  check('OTP hash matches with formatting noise', auth.hashOtp(7, 'login', otp.code.slice(0, 3) + ' ' + otp.code.slice(3)) === otp.codeHash);
  check('OTP hash differs per purpose', auth.hashOtp(7, 'reset', otp.code) !== otp.codeHash);
  const ch = auth.signChallenge({ uid: 7, otp: 1, purpose: 'login' });
  check('challenge round-trips', auth.readChallenge(ch, 'login') && auth.readChallenge(ch, 'login').uid === 7);
  check('challenge rejects wrong purpose', auth.readChallenge(ch, 'reset') === null);
  check('challenge rejects session token', auth.readChallenge(token, 'login') === null);
  const t0 = Date.now(); await auth.verifyPassword('whatever1', null); const dt = Date.now() - t0;
  check('unknown-user login still runs bcrypt (>20ms)', dt > 20, dt + 'ms');
  // forgot for unknown email must still hand back a challenge (decoy) - route needs DB for known users, but unknown path only reads
  r = await post('/api/auth/forgot', { email: 'nobody@example.com' }, {});
  const fj = r.status === 200 ? await r.json() : null;
  check('forgot(unknown email) -> 200 with decoy challenge (or 503 no DB)', (fj && fj.challenge) || r.status === 503, r.status);

  // --- security fixes ---
  // JWT algorithm pinning: a token signed with alg:none must be rejected outright.
  // Hits /api/session/turn (not /api/me) because that route is explicitly exempt from
  // the DB-readiness gate, so the check isolates pure JWT verification either way.
  const forgedHeader = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  const forgedPayload = Buffer.from(JSON.stringify({ sub: 1, role: 'admin', name: 'x', ep: 1 })).toString('base64url');
  r = await realFetch(base + '/api/session/turn', { method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: 'sdt_token=' + forgedHeader + '.' + forgedPayload + '.' }, body: '{}' });
  check('alg:none forged token is rejected', r.status === 401, r.status);

  // Signup reclaim: an unverified signup must not permanently block the real owner.
  r = await post('/api/auth/signup', { name: 'First Try', email: 'reclaim@example.com', sapId: 'RCL-1', project: 'P', lob: 'L', password: 'abc12345', confirmPassword: 'abc12345' }, {});
  const firstSignup = r.status === 201 ? await r.json() : null;
  r = await post('/api/auth/signup', { name: 'Real Owner', email: 'reclaim@example.com', sapId: 'RCL-2', project: 'P', lob: 'L', password: 'def12345', confirmPassword: 'def12345' }, {});
  const secondSignup = r.status === 201 ? await r.json() : null;
  check(hasDb ? 'unverified signup is reclaimed by the real owner (not stuck at 409)' : 'signup route reachable (503 without DB)', hasDb ? r.status === 201 : r.status === 503, r.status);
  if (hasDb) check('reclaim issues a fresh challenge (old one invalidated)', firstSignup && secondSignup && firstSignup.challenge !== secondSignup.challenge);
  if (hasDb) {
    r = await post('/api/auth/signup', { name: 'Squatter', email: 'reclaim@example.com', sapId: 'RCL-2', project: 'P', lob: 'L', password: 'zzz12345', confirmPassword: 'zzz12345' }, {});
    check('repeated reclaim of the same still-unverified row keeps working', r.status === 201, r.status);
  }

  // Excel formula injection is neutralised end to end.
  const excel = require(path.join(__dirname, '..', 'lib', 'excel.js'));
  const ExcelJS = require('exceljs');
  const wb = await excel.buildAllSessionsWorkbook([{
    id: 1, user_id: 1, user_name: "=cmd|'/c calc'!A0", user_email: 'a@x.com', user_sap_id: '1',
    user_project: '+SUM(1,1)', user_lob: '-1+1', ticket_id: 'SD-10000', scenario: 'Network issue', mood: 'Furious',
    final_status: 'resolved', overall_score: 80, empathy: 80, technical_accuracy: 80, resolution: 80, communication: 80,
    verdict: '@HYPERLINK("http://evil")', created_at: new Date().toISOString()
  }]);
  const tmpXlsx = path.join(require('os').tmpdir(), 'sdt-formula-test.xlsx');
  await wb.xlsx.writeFile(tmpXlsx);
  const wbCheck = new ExcelJS.Workbook(); await wbCheck.xlsx.readFile(tmpXlsx);
  const cell = wbCheck.worksheets[0].getRow(2).getCell(2);
  check('Excel formula payload stored as inert text', cell.type === ExcelJS.ValueType.String && String(cell.value).startsWith("'="), cell.type + ' ' + cell.value);
  fs.unlinkSync(tmpXlsx);

  // Admin :id routes reject non-numeric ids cleanly instead of passing NaN to the DB.
  // (Authenticated admin routes sit behind the schema-readiness gate, so without a DB
  // this correctly 503s before ever reaching the id check - tested for real above under hasDb.)
  r = await realFetch(base + '/api/admin/users/not-a-number/reports', { headers: { Cookie: 'sdt_token=' + adminToken } });
  check(hasDb ? 'admin route rejects non-numeric id -> 400' : 'admin route unreachable without DB -> 503', hasDb ? r.status === 400 : r.status === 503, r.status);

  if (hasDb) {
    // Verify a genuinely verified account is never reclaimable (the reclaim fix must not
    // reopen the account-takeover hole it was meant to close).
    r = await post('/api/auth/signup', { name: 'Attacker', email: 'agent@example.com', sapId: 'RCL-9', project: 'P', lob: 'L', password: 'hax12345', confirmPassword: 'hax12345' }, {});
    check('signup against an already-verified email is still rejected 409', r.status === 409, r.status);
  }

  // --- voice gateway over a real WebSocket ---
  const wsMsgs = [], wsBin = [];
  await new Promise((resolve) => {
    const sock = new WebSocket('ws://localhost:' + PORT + '/ws/voice', { headers: { Cookie: 'sdt_token=' + token, Origin: base } });
    sock.on('message', (d, isBinary) => {
      if (isBinary) { wsBin.push(d); return; }
      const m = JSON.parse(d.toString()); wsMsgs.push(m);
      if (m.type === 'ready') sock.send(Buffer.alloc(3200), { binary: true });
      if (m.type === 'transcript' && m.role === 'agent') setTimeout(() => sock.send(JSON.stringify({ type: 'end' })), 1700);
      if (m.type === 'ended') resolve();
    });
    sock.on('open', () => sock.send(JSON.stringify({ type: 'start', moodId: 'furious', scenarioId: 'network' })));
    sock.on('error', () => resolve());
    setTimeout(resolve, 6000);
  });
  const wsTypes = wsMsgs.map(m => m.type);
  check('ws: ready after start', wsTypes[0] === 'ready', wsTypes.join(','));
  check('ws: client + agent transcript relayed', wsMsgs.some(m => m.type === 'transcript' && m.role === 'client' && m.final) && wsMsgs.some(m => m.type === 'transcript' && m.role === 'agent'));
  check('ws: audio relayed as binary PCM', wsBin.length === 1 && wsBin[0].length === 480, wsBin.map(b => b.length).join(','));
  check('ws: live satisfaction estimate delivered', wsMsgs.some(m => m.type === 'satisfaction' && m.value === 41), JSON.stringify(wsMsgs.find(m => m.type === 'satisfaction')));
  const ended = wsMsgs.find(m => m.type === 'ended');
  check('ws: ended carries merged transcript + duration', ended && ended.history.length === 2 && ended.history[0].role === 'client' && ended.history[1].role === 'agent' && typeof ended.durationSec === 'number', ended && JSON.stringify(ended.history.map(h => h.role)));

  // Voice transcript scores through the same endpoint with mode=voice.
  if (hasDb && ended) {
    r = await post('/api/session/score', { moodId: 'furious', scenarioId: 'network', ticketId: 'SD-12345', finalStatus: 'ended_by_agent', history: ended.history, durationSec: ended.durationSec, mode: 'voice' }, { Origin: base });
    const scoredVoice = r.status === 200 ? await r.json() : null;
    check('voice transcript scored and saved with mode=voice', scoredVoice && scoredVoice.mode === 'voice' && scoredVoice.overall_score === 72 && scoredVoice.reportId, r.status);
    if (scoredVoice) {
      r = await realFetch(base + '/api/reports/' + scoredVoice.reportId, { headers: { Cookie: 'sdt_token=' + token } });
      const saved = await r.json();
      check('saved report keeps mode=voice', saved.mode === 'voice', saved.mode);
    }
  }

  // Gateway rejects unauthenticated and cross-origin upgrades.
  const tryWs = (headers) => new Promise((resolve) => { const s2 = new WebSocket('ws://localhost:' + PORT + '/ws/voice', { headers }); s2.on('unexpected-response', (req, res) => resolve(res.statusCode)); s2.on('open', () => { s2.close(); resolve(101); }); s2.on('error', () => resolve('err')); });
  check('ws: no cookie -> 401', await tryWs({}) === 401);
  check('ws: cross-origin -> 403', await tryWs({ Cookie: 'sdt_token=' + token, Origin: 'https://evil.example' }) === 403);

  console.log(failures ? '\n' + failures + ' FAILURE(S)' : '\nALL HTTP TESTS PASS');
  server.close(() => process.exit(failures ? 1 : 0));
});
