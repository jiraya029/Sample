// Deployment config for the static frontend. `infra/deploy.sh` rewrites this
// file with the real API Gateway URL after each deploy; edit by hand if you
// deploy manually. Leave apiBase empty to call the same origin (local dev with
// `npm start` serving the API on the same host).
window.SDT_CONFIG = {
  apiBase: '',          // e.g. 'https://abc123.execute-api.us-east-1.amazonaws.com'
};
