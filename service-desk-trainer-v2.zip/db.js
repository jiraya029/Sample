// db.js
// Postgres access layer (Neon-friendly, works with any standard connection
// string). Everything goes through one pool. Schema is created on first use.

const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.warn('[db] DATABASE_URL is not set. Auth, reports and the admin portal will not work until it is configured.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined,
  // Fail fast if the database is unreachable instead of hanging every request.
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000,
  max: 5
});

pool.on('error', (err) => console.error('[db] pool error:', err.message));

async function query(text, params) {
  return pool.query(text, params);
}

const REPORT_SUMMARY_COLS = `
  id, user_id, ticket_id, scenario, mood, final_status, overall_score, empathy,
  technical_accuracy, resolution, communication, verdict, duration_sec, created_at
`;

/* ---------------- schema ---------------- */

let schemaReady = null;

/** Idempotent. Safe to call on every boot / cold start; only runs once per process. */
function initSchema() {
  if (!schemaReady) {
    schemaReady = (async () => {
      await query(`
        CREATE TABLE IF NOT EXISTS users (
          id            SERIAL PRIMARY KEY,
          name          TEXT NOT NULL,
          email         TEXT NOT NULL UNIQUE,
          sap_id        TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          project       TEXT NOT NULL DEFAULT '',
          lob           TEXT NOT NULL DEFAULT '',
          role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
          created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS project TEXT NOT NULL DEFAULT ''`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS lob TEXT NOT NULL DEFAULT ''`);

      await query(`
        CREATE TABLE IF NOT EXISTS reports (
          id                  SERIAL PRIMARY KEY,
          user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          ticket_id           TEXT NOT NULL,
          scenario            TEXT NOT NULL,
          mood                TEXT NOT NULL,
          final_status        TEXT NOT NULL,
          overall_score       NUMERIC NOT NULL,
          empathy             NUMERIC NOT NULL,
          technical_accuracy  NUMERIC NOT NULL,
          resolution          NUMERIC NOT NULL,
          communication       NUMERIC NOT NULL,
          verdict             TEXT NOT NULL,
          strengths           JSONB NOT NULL DEFAULT '[]',
          improvements        JSONB NOT NULL DEFAULT '[]',
          transcript          JSONB NOT NULL DEFAULT '[]',
          duration_sec        INTEGER,
          created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`ALTER TABLE reports ADD COLUMN IF NOT EXISTS duration_sec INTEGER`);
      await query(`CREATE INDEX IF NOT EXISTS idx_reports_user_id ON reports(user_id);`);
      await query(`CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at DESC);`);

      await query(`
        CREATE TABLE IF NOT EXISTS password_resets (
          id          SERIAL PRIMARY KEY,
          user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          token_hash  TEXT NOT NULL UNIQUE,
          expires_at  TIMESTAMPTZ NOT NULL,
          used_at     TIMESTAMPTZ,
          created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`CREATE INDEX IF NOT EXISTS idx_password_resets_user ON password_resets(user_id);`);

      // One-time admin bootstrap so there is always a way into the admin portal.
      if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
        const email = process.env.ADMIN_EMAIL.toLowerCase();
        const existing = await query('SELECT id FROM users WHERE email = $1', [email]);
        if (existing.rows.length === 0) {
          const bcrypt = require('bcryptjs');
          const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
          await query(
            `INSERT INTO users (name, email, sap_id, password_hash, project, lob, role) VALUES ($1,$2,$3,$4,'','','admin')`,
            [process.env.ADMIN_NAME || 'Administrator', email, process.env.ADMIN_SAP_ID || 'ADMIN-0001', hash]
          );
          console.log('[db] Seeded initial admin account for', email);
        }
      }
    })().catch(err => { schemaReady = null; throw err; });
  }
  return schemaReady;
}

/* ---------------- users ---------------- */

async function createUser({ name, email, sapId, passwordHash, project, lob }) {
  const r = await query(
    `INSERT INTO users (name, email, sap_id, password_hash, project, lob)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, name, email, sap_id, project, lob, role, created_at`,
    [name, email.toLowerCase(), sapId, passwordHash, project || '', lob || '']
  );
  return r.rows[0];
}

async function findUserByEmail(email) {
  const r = await query('SELECT * FROM users WHERE email = $1', [String(email).toLowerCase()]);
  return r.rows[0] || null;
}

async function findUserBySapId(sapId) {
  const r = await query('SELECT * FROM users WHERE sap_id = $1', [sapId]);
  return r.rows[0] || null;
}

async function findUserById(id) {
  const r = await query('SELECT id, name, email, sap_id, project, lob, role, created_at FROM users WHERE id = $1', [id]);
  return r.rows[0] || null;
}

async function setUserPassword(userId, passwordHash) {
  await query('UPDATE users SET password_hash = $1 WHERE id = $2', [passwordHash, userId]);
}

async function listUsersWithStats() {
  const r = await query(`
    SELECT
      u.id, u.name, u.email, u.sap_id, u.project, u.lob, u.role, u.created_at,
      COUNT(r.id)::int                                AS report_count,
      COALESCE(ROUND(AVG(r.overall_score)), 0)::int   AS avg_score,
      MAX(r.created_at)                               AS last_session_at
    FROM users u
    LEFT JOIN reports r ON r.user_id = u.id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY u.created_at DESC
  `);
  return r.rows;
}

/* ---------------- password resets ---------------- */

async function createPasswordReset(userId, tokenHash, expiresAt) {
  // Invalidate any outstanding tokens for this user first.
  await query('UPDATE password_resets SET used_at = now() WHERE user_id = $1 AND used_at IS NULL', [userId]);
  await query('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES ($1,$2,$3)', [userId, tokenHash, expiresAt]);
}

async function findValidPasswordReset(tokenHash) {
  const r = await query(
    `SELECT pr.id, pr.user_id FROM password_resets pr
     WHERE pr.token_hash = $1 AND pr.used_at IS NULL AND pr.expires_at > now()`,
    [tokenHash]
  );
  return r.rows[0] || null;
}

async function consumePasswordReset(id) {
  await query('UPDATE password_resets SET used_at = now() WHERE id = $1', [id]);
}

/* ---------------- reports ---------------- */

async function createReport(userId, r) {
  const res = await query(
    `INSERT INTO reports
      (user_id, ticket_id, scenario, mood, final_status, overall_score, empathy,
       technical_accuracy, resolution, communication, verdict, strengths, improvements, transcript, duration_sec)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
     RETURNING *`,
    [
      userId, r.ticketId, r.scenario, r.mood, r.finalStatus, r.overallScore, r.empathy,
      r.technicalAccuracy, r.resolution, r.communication, r.verdict,
      JSON.stringify(r.strengths || []), JSON.stringify(r.improvements || []), JSON.stringify(r.transcript || []),
      r.durationSec == null ? null : r.durationSec
    ]
  );
  return res.rows[0];
}

/** Summary rows (no transcript/strengths) for list views. */
async function listReportSummariesByUser(userId) {
  const r = await query(`SELECT ${REPORT_SUMMARY_COLS} FROM reports WHERE user_id = $1 ORDER BY created_at DESC`, [userId]);
  return r.rows;
}

async function getReportById(reportId) {
  const r = await query('SELECT * FROM reports WHERE id = $1', [reportId]);
  return r.rows[0] || null;
}

/** All sessions with the owning agent's details, for the admin portal. */
async function listAllReportsWithUsers({ limit = 500 } = {}) {
  const r = await query(
    `SELECT r.id, r.user_id, r.ticket_id, r.scenario, r.mood, r.final_status, r.overall_score, r.empathy,
            r.technical_accuracy, r.resolution, r.communication, r.verdict, r.duration_sec, r.created_at,
            u.name AS user_name, u.email AS user_email, u.sap_id AS user_sap_id, u.project AS user_project, u.lob AS user_lob
     FROM reports r
     JOIN users u ON u.id = r.user_id
     ORDER BY r.created_at DESC
     LIMIT $1`,
    [limit]
  );
  return r.rows;
}

async function adminOverview() {
  const totals = await query(`
    SELECT COUNT(*)::int AS total_reports,
           COUNT(DISTINCT user_id)::int AS active_agents,
           COALESCE(ROUND(AVG(overall_score)), 0)::int AS avg_score,
           COUNT(*) FILTER (WHERE created_at > now() - interval '7 days')::int AS reports_7d,
           COUNT(*) FILTER (WHERE final_status = 'resolved')::int AS resolved_count
    FROM reports
  `);
  const top = await query(`
    SELECT u.id, u.name, ROUND(AVG(r.overall_score))::int AS avg_score, COUNT(r.id)::int AS report_count
    FROM reports r JOIN users u ON u.id = r.user_id
    GROUP BY u.id HAVING COUNT(r.id) >= 1
    ORDER BY AVG(r.overall_score) DESC, COUNT(r.id) DESC
    LIMIT 1
  `);
  const trend = await query(`
    SELECT date_trunc('day', created_at)::date AS day, ROUND(AVG(overall_score))::int AS avg_score, COUNT(*)::int AS sessions
    FROM reports WHERE created_at > now() - interval '30 days'
    GROUP BY 1 ORDER BY 1
  `);
  return { ...totals.rows[0], top_agent: top.rows[0] || null, trend: trend.rows };
}

module.exports = {
  pool, query, initSchema,
  createUser, findUserByEmail, findUserBySapId, findUserById, setUserPassword, listUsersWithStats,
  createPasswordReset, findValidPasswordReset, consumePasswordReset,
  createReport, listReportSummariesByUser, getReportById, listAllReportsWithUsers, adminOverview
};
