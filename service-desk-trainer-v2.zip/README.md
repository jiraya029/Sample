# Service Desk Trainer

A training simulator for IT / DevOps service desk agents. The trainee picks a client mood and a scenario, handles the ticket in a live chat with an AI-played client, and gets a scored report (empathy, technical accuracy, resolution, communication) with concrete strengths and improvements. Reports are saved per user and exportable as TXT or Excel. An admin portal shows global metrics, every session, and per-agent records.

Powered by CareerShaper.

## What's in v2

**Rebuilt end to end.** The frontend is now served from `public/` only, the server assembles all AI prompts itself, and the API contract matches what the pages call.

New in this version:

- **Streaming client replies.** The simulated client's message appears word by word (Gemini `streamGenerateContent` → server-sent events → the chat bubble), with a typing indicator before the first token.
- **Session persistence.** Refreshing or navigating away mid-ticket no longer loses the conversation. The setup page offers to resume or discard an open ticket.
- **Dashboard analytics.** Score trend chart, category averages, resolution rate, and a comparison of your latest five sessions against the five before. Session history is searchable, filterable by outcome and date range, and sortable by any column.
- **Working admin portal.** Overview stats, 30-day daily-average trend, all sessions with search/filter/sort, an Agents tab with per-agent stats and drill-down, password reset via an in-app dialog, and a one-click Excel export of every session.
- **Self-service password reset.** "Forgot password?" emails a single-use, 30-minute link (or logs it to the console when SMTP is not configured).
- **Form validation.** Inline field errors on blur, password strength meter, show/hide password, server-side field errors mapped back onto the form.
- **Toasts, skeleton loaders, and an in-app modal** replace `alert()` / `confirm()` / `prompt()` and blank loading states.
- **Light and dark themes** with a persisted preference, full keyboard navigation, `prefers-reduced-motion` support, and a responsive layout down to 320px.

Bugs fixed from v1:

| Bug | Fix |
| --- | --- |
| Admin page called `/api/admin/reports` and `/api/admin/reports/download-excel`, which did not exist; the admin portal never loaded | Both endpoints (plus `/api/admin/overview`) now exist |
| `express.static(__dirname)` served `server.js`, `db.js`, `package.json` to anyone | Only `public/` is served |
| `/login`, `/dashboard` etc. returned 404 when run locally (no `extensions: ['html']`) | Clean URLs work everywhere |
| Browser built the Gemini system prompt and sent it to the server, making `/api/turn` an open LLM proxy for any signed-in user | Prompts, personas, and schemas live in `lib/catalog.js`; the client sends only ids and the transcript |
| JWT fell back to a hard-coded dev secret in production if `JWT_SECRET` was missing | Server refuses to start in production without it |
| Chat state lived only in memory | Saved to `sessionStorage`, resumable |
| `app.listen()` at module scope; not safe for serverless | App is exported; listens only when run directly |
| Rate limiter ignored `X-Forwarded-For` behind Vercel | `trust proxy` enabled |
| Unused `xlsx` dependency | Removed (`exceljs` does the exports) |
| No CSRF defence beyond `SameSite=Lax` | Origin check on all state-changing requests |

## Project layout

```
server.js            Express app and all routes (exported; listens when run directly)
db.js                Postgres access layer and schema (users, reports, password_resets)
auth.js              Password hashing, JWT cookies, guards, reset-token helpers
lib/catalog.js       Moods, scenarios, response schemas, prompt builders
lib/gemini.js        Gemini client: one-shot JSON and SSE streaming
lib/excel.js         Excel report builders
lib/mailer.js        Password-reset email (nodemailer or console fallback)
public/              Everything the browser gets
  assets/app.css     Design tokens and components
  assets/app.js      Shared runtime: API client, SSE reader, toasts, modal, forms, theme, tables, charts
  login.html  setup.html  chat.html  dashboard.html  report.html  admin.html  reset-password.html  404.html
test/                Streaming and HTTP tests, Playwright visual check
```

## Running locally

```bash
npm install
cp .env.example .env     # fill in GEMINI_API_KEY, DATABASE_URL, JWT_SECRET
npm start                # http://localhost:3000
```

The schema is created automatically on first use. To seed an admin account, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before the first run.

### Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `GEMINI_API_KEY` | yes | Google AI Studio key |
| `DATABASE_URL` | yes | Postgres connection string (Neon works) |
| `JWT_SECRET` | yes in production | Long random string for session cookies |
| `GEMINI_MODEL` | no | Defaults to `gemini-3.1-flash-lite` |
| `PGSSL` | no | `true` for hosted Postgres that requires SSL |
| `APP_URL` | no | Public URL used in reset-password links (inferred from the request otherwise) |
| `SMTP_URL`, `MAIL_FROM` | no | Enable real reset emails. Without them the link is printed to the server log |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`, `ADMIN_SAP_ID` | no | One-time admin bootstrap |

## Deploying to Vercel

`vercel.json` builds `server.js` as a Node function, bundles `public/` and `lib/`, and routes every path to it. Set the environment variables above in Project Settings. Streaming responses work on Vercel's Node runtime.

## API

All JSON, cookie-authenticated. State-changing requests must be same-origin.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/health` | Config sanity check (no secrets) |
| GET | `/api/catalog` | Moods and scenarios (public fields only) |
| POST | `/api/auth/signup` `/login` `/logout` `/forgot` `/reset` | Auth. Validation errors return `{ error, fields }` |
| GET | `/api/me` | Current user |
| POST | `/api/session/turn` | `{ moodId, scenarioId, history }` → SSE: `partial` (reply so far), `done` (`reply, satisfaction, status`), `error` |
| POST | `/api/session/score` | `{ moodId, scenarioId, ticketId, finalStatus, history, durationSec }` → report with `reportId` |
| GET | `/api/reports` | Own sessions (summaries) |
| GET | `/api/reports/:id` `/download` `/download-excel` | Owner or admin |
| GET | `/api/admin/overview` `/reports` `/reports/download-excel` `/users` `/users/:id/reports` | Admin |
| POST | `/api/admin/users/:id/reset-password` | Admin |

## Tests

```bash
node test/http_stream_test.js          # boots the app with a mocked Gemini; SSE + guards
PORT=4100 node server.js &  python3 test/visual_check.py   # screenshots every page (needs Playwright)
```

## Migrating from v1

- Frontend files moved from the repo root into `public/` (`shared.css`/`shared.js` → `public/assets/app.css`/`app.js`).
- Existing databases are migrated automatically (`duration_sec` column and `password_resets` table are added on first run).
- `JWT_SECRET` is now mandatory in production. Existing sessions stay valid if the secret is unchanged.
- The `garak_*` scanner config files were removed from the repo. **They contained a live session cookie.** Rotate `JWT_SECRET` (which invalidates all sessions) and purge those files from git history.
