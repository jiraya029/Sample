document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, toast, banner, skeleton, icon, escapeHtml, outcomeLabel, fmtDateTime, fmtDuration, reducedMotion } = SDT;
  const user = await requireAuth();
  if (!user) return;
  ['#back-icon', 'arrowLeft', '#ic-good', 'thumbUp', '#ic-fix', 'wrench', '#ic-chev', 'chevron', '#ic-dl1', 'download', '#ic-dl2', 'download'].forEach((v, i, a) => { if (i % 2 === 0) $(v).outerHTML = icon(a[i + 1]); });

  const params = new URLSearchParams(location.search);
  const id = params.get('id');
  const from = params.get('from') === 'admin' && user.role === 'admin' ? '/admin' : (user.role === 'admin' && !params.get('from') ? '/admin' : '/dashboard');
  $('#back-btn').href = from;
  if (params.get('fresh')) toast.success('Report ready', 'Your session has been scored and saved.');

  skeleton('#cat-list', 'lines', 4); skeleton('#strengths', 'lines', 2); skeleton('#improvements', 'lines', 2);

  if (!id) { banner('#report-banner', 'error', 'No report was specified.'); $('#report').hidden = true; return; }
  let r;
  try { r = await api('/api/reports/' + encodeURIComponent(id)); }
  catch (err) { banner('#report-banner', 'error', err.status === 404 ? 'That report does not exist.' : err.message); $('#report').hidden = true; return; }

  const score = Math.round(Math.max(0, Math.min(100, Number(r.overall_score) || 0)));
  const ringColor = score >= 70 ? 'var(--green)' : score >= 40 ? 'var(--amber)' : 'var(--red)';
  const numEl = $('#score-num'); numEl.classList.remove('skel');
  const ring = $('#ring'); ring.setAttribute('stroke', ringColor);
  // Count up + draw the ring together.
  if (reducedMotion()) { numEl.textContent = score; ring.setAttribute('stroke-dashoffset', (326.7 - score / 100 * 326.7).toFixed(1)); }
  else {
    const start = performance.now();
    const step = (t) => { const p = Math.min(1, (t - start) / 900); const e = 1 - Math.pow(1 - p, 3); numEl.textContent = Math.round(score * e); if (p < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
    requestAnimationFrame(() => requestAnimationFrame(() => ring.setAttribute('stroke-dashoffset', (326.7 - score / 100 * 326.7).toFixed(1))));
  }
  numEl.style.color = ringColor;

  $('#report-title').textContent = 'Session report' + (user.role === 'admin' && r.user_id !== user.id ? ' (agent #' + r.user_id + ')' : '');
  const v = $('#verdict'); v.classList.remove('skel'); v.textContent = r.verdict || 'No verdict was produced for this session.';
  $('#meta').innerHTML = '<span class="mono">' + escapeHtml(r.ticket_id) + '</span><span>' + escapeHtml(r.scenario) + '</span><span>' + escapeHtml(r.mood) + ' client</span>' +
    '<span class="pill ' + escapeHtml(r.final_status) + '">' + escapeHtml(outcomeLabel(r.final_status)) + '</span>' +
        '<span class="pill neutral">' + (r.mode === 'voice' ? 'Voice call' : 'Chat') + '</span>' +
    (r.duration_sec != null ? '<span>' + fmtDuration(r.duration_sec) + '</span>' : '') + '<span>' + escapeHtml(fmtDateTime(r.created_at)) + '</span>';
  document.title = r.ticket_id + ' report · Service Desk Trainer';

  const cats = [['Empathy', r.empathy], ['Technical accuracy', r.technical_accuracy], ['Resolution', r.resolution], ['Communication', r.communication]];
  const list = $('#cat-list'); list.innerHTML = ''; list.removeAttribute('aria-busy');
  cats.forEach(([label, val]) => {
    val = Math.round(Math.max(0, Math.min(100, Number(val) || 0)));
    const row = el('div', 'cat-row');
    row.innerHTML = '<div class="cat-row-top"><span>' + label + '</span><span class="val">' + val + '</span></div><div class="bar-track"><div class="bar-fill" role="progressbar" aria-valuenow="' + val + '" aria-valuemin="0" aria-valuemax="100" aria-label="' + label + '"></div></div>';
    list.appendChild(row);
    requestAnimationFrame(() => requestAnimationFrame(() => { row.querySelector('.bar-fill').style.width = val + '%'; }));
  });

  const fill = (sel, items, empty) => { const ul = $(sel); ul.innerHTML = ''; ul.removeAttribute('aria-busy'); if (!items || !items.length) return ul.appendChild(el('li', null, empty)); items.forEach(s => ul.appendChild(el('li', null, s))); };
  fill('#strengths', r.strengths, 'No specific strengths were recorded.');
  fill('#improvements', r.improvements, 'No specific improvements were recorded.');

  const box = $('#transcript-box'); box.innerHTML = '';
  (r.transcript || []).forEach(m => { const p = el('p'); p.innerHTML = '<b>' + (m.role === 'agent' ? 'Agent' : 'Client') + '</b>' + escapeHtml(m.text); box.appendChild(p); });
  if (!(r.transcript || []).length) $('#transcript').hidden = true;

  $('#dl-txt').href = SDT.apiUrl('/api/reports/' + encodeURIComponent(r.id) + '/download');
  $('#dl-xlsx').href = SDT.apiUrl('/api/reports/' + encodeURIComponent(r.id) + '/download-excel');
  $('#actions').hidden = false;
});
