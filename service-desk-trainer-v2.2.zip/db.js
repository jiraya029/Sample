// db.js
// Postgres access layer (Neon-friendly, works with any standard connection
// string). Everything goes through one pool. Schema is created on first use.

const { Pool } = require('pg');

if (!process.env.DATABASE_URL) {
  console.warn('[db] DATABASE_URL is not set. Auth, reports and the admin portal will not work until it is configured.');
}

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined,
  // Fail fast if the database is unreachable instead of hanging every request.
  connectionTimeoutMillis: 5000,
  idleTimeoutMillis: 30000,
  max: 5
});

pool.on('error', (err) => console.error('[db] pool error:', err.message));

async function query(text, params) {
  return pool.query(text, params);
}

const REPORT_SUMMARY_COLS = `
  id, user_id, ticket_id, scenario, mood, final_status, overall_score, empathy,
  technical_accuracy, resolution, communication, verdict, duration_sec, created_at
`;

/* ---------------- schema ---------------- */

let schemaReady = null;

/** Idempotent. Safe to call on every boot / cold start; only runs once per process. */
function initSchema() {
  if (!schemaReady) {
    schemaReady = (async () => {
      await query(`
        CREATE TABLE IF NOT EXISTS users (
          id            SERIAL PRIMARY KEY,
          name          TEXT NOT NULL,
          email         TEXT NOT NULL UNIQUE,
          sap_id        TEXT NOT NULL UNIQUE,
          password_hash TEXT NOT NULL,
          project       TEXT NOT NULL DEFAULT '',
          lob           TEXT NOT NULL DEFAULT '',
          role          TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
          created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS project TEXT NOT NULL DEFAULT ''`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS lob TEXT NOT NULL DEFAULT ''`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified_at TIMESTAMPTZ`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS session_epoch INTEGER NOT NULL DEFAULT 1`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_logins INTEGER NOT NULL DEFAULT 0`);
      await query(`ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_until TIMESTAMPTZ`);

      await query(`
        CREATE TABLE IF NOT EXISTS reports (
          id                  SERIAL PRIMARY KEY,
          user_id             INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          ticket_id           TEXT NOT NULL,
          scenario            TEXT NOT NULL,
          mood                TEXT NOT NULL,
          final_status        TEXT NOT NULL,
          overall_score       NUMERIC NOT NULL,
          empathy             NUMERIC NOT NULL,
          technical_accuracy  NUMERIC NOT NULL,
          resolution          NUMERIC NOT NULL,
          communication       NUMERIC NOT NULL,
          verdict             TEXT NOT NULL,
          strengths           JSONB NOT NULL DEFAULT '[]',
          improvements        JSONB NOT NULL DEFAULT '[]',
          transcript          JSONB NOT NULL DEFAULT '[]',
          duration_sec        INTEGER,
          created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`ALTER TABLE reports ADD COLUMN IF NOT EXISTS duration_sec INTEGER`);
      await query(`CREATE INDEX IF NOT EXISTS idx_reports_user_id ON reports(user_id);`);
      await query(`CREATE INDEX IF NOT EXISTS idx_reports_created_at ON reports(created_at DESC);`);

      await query(`
        CREATE TABLE IF NOT EXISTS otp_codes (
          id          SERIAL PRIMARY KEY,
          user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
          purpose     TEXT NOT NULL CHECK (purpose IN ('login', 'reset')),
          code_hash   TEXT NOT NULL,
          attempts    INTEGER NOT NULL DEFAULT 0,
          expires_at  TIMESTAMPTZ NOT NULL,
          used_at     TIMESTAMPTZ,
          created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
        );
      `);
      await query(`CREATE INDEX IF NOT EXISTS idx_otp_codes_user ON otp_codes(user_id, purpose);`);
      await query(`DROP TABLE IF EXISTS password_resets`);

      // One-time admin bootstrap so there is always a way into the admin portal.
      if (process.env.ADMIN_EMAIL && process.env.ADMIN_PASSWORD) {
        const email = process.env.ADMIN_EMAIL.toLowerCase();
        const existing = await query('SELECT id FROM users WHERE email = $1', [email]);
        if (existing.rows.length === 0) {
          const bcrypt = require('bcryptjs');
          const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD, 10);
          await query(
            `INSERT INTO users (name, email, sap_id, password_hash, project, lob, role, email_verified_at) VALUES ($1,$2,$3,$4,'','','admin', now())`,
            [process.env.ADMIN_NAME || 'Administrator', email, process.env.ADMIN_SAP_ID || 'ADMIN-0001', hash]
          );
          console.log('[db] Seeded initial admin account for', email);
        }
      }
    })().catch(err => { schemaReady = null; throw err; });
  }
  return schemaReady;
}

/* ---------------- users ---------------- */

async function createUser({ name, email, sapId, passwordHash, project, lob }) {
  const r = await query(
    `INSERT INTO users (name, email, sap_id, password_hash, project, lob)
     VALUES ($1,$2,$3,$4,$5,$6)
     RETURNING id, name, email, sap_id, project, lob, role, created_at`,
    [name, email.toLowerCase(), sapId, passwordHash, project || '', lob || '']
  );
  return r.rows[0];
}

async function findUserByEmail(email) {
  const r = await query('SELECT * FROM users WHERE email = $1', [String(email).toLowerCase()]);
  return r.rows[0] || null;
}

async function findUserBySapId(sapId) {
  const r = await query('SELECT * FROM users WHERE sap_id = $1', [sapId]);
  return r.rows[0] || null;
}

async function findUserById(id) {
  const r = await query('SELECT id, name, email, sap_id, project, lob, role, created_at, email_verified_at, session_epoch FROM users WHERE id = $1', [id]);
  return r.rows[0] || null;
}

/** Changing the password also bumps session_epoch, which invalidates every existing session. */
async function setUserPassword(userId, passwordHash) {
  await query('UPDATE users SET password_hash = $1, session_epoch = session_epoch + 1, failed_logins = 0, locked_until = NULL WHERE id = $2', [passwordHash, userId]);
}

async function getSessionEpoch(userId) {
  const r = await query('SELECT session_epoch FROM users WHERE id = $1', [userId]);
  return r.rows[0] ? r.rows[0].session_epoch : null;
}

async function markEmailVerified(userId) {
  await query('UPDATE users SET email_verified_at = COALESCE(email_verified_at, now()) WHERE id = $1', [userId]);
}

/* ---------------- login lockout ---------------- */

const LOCK_AFTER = 10;
const LOCK_MINUTES = 15;

async function recordFailedLogin(userId) {
  const r = await query(
    `UPDATE users SET failed_logins = failed_logins + 1,
       locked_until = CASE WHEN failed_logins + 1 >= $2 THEN now() + ($3 || ' minutes')::interval ELSE locked_until END
     WHERE id = $1 RETURNING failed_logins, locked_until`,
    [userId, LOCK_AFTER, String(LOCK_MINUTES)]
  );
  return r.rows[0];
}

async function clearFailedLogins(userId) {
  await query('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = $1', [userId]);
}

async function listUsersWithStats() {
  const r = await query(`
    SELECT
      u.id, u.name, u.email, u.sap_id, u.project, u.lob, u.role, u.created_at,
      COUNT(r.id)::int                                AS report_count,
      COALESCE(ROUND(AVG(r.overall_score)), 0)::int   AS avg_score,
      MAX(r.created_at)                               AS last_session_at
    FROM users u
    LEFT JOIN reports r ON r.user_id = u.id
    WHERE u.role = 'user'
    GROUP BY u.id
    ORDER BY u.created_at DESC
  `);
  return r.rows;
}

/* ---------------- one-time codes ---------------- */

const OTP_MAX_ATTEMPTS = 5;

async function createOtp(userId, purpose, codeHash, expiresAt) {
  // Only one live code per user+purpose.
  await query('UPDATE otp_codes SET used_at = now() WHERE user_id = $1 AND purpose = $2 AND used_at IS NULL', [userId, purpose]);
  const r = await query('INSERT INTO otp_codes (user_id, purpose, code_hash, expires_at) VALUES ($1,$2,$3,$4) RETURNING id', [userId, purpose, codeHash, expiresAt]);
  return r.rows[0].id;
}

/** Counts codes issued recently, to throttle resend abuse per account. */
async function countRecentOtps(userId, purpose, minutes) {
  const r = await query(`SELECT COUNT(*)::int AS n FROM otp_codes WHERE user_id = $1 AND purpose = $2 AND created_at > now() - ($3 || ' minutes')::interval`, [userId, purpose, String(minutes)]);
  return r.rows[0].n;
}

/**
 * Atomically checks a code. Returns 'ok' | 'wrong' | 'expired' | 'locked'.
 * Wrong guesses are counted; after OTP_MAX_ATTEMPTS the code is burned.
 */
async function verifyOtp(otpId, userId, purpose, codeHash) {
  const r = await query('SELECT * FROM otp_codes WHERE id = $1 AND user_id = $2 AND purpose = $3', [otpId, userId, purpose]);
  const row = r.rows[0];
  if (!row || row.used_at) return 'expired';
  if (new Date(row.expires_at) < new Date()) return 'expired';
  if (row.attempts >= OTP_MAX_ATTEMPTS) return 'locked';
  if (row.code_hash !== codeHash) {
    const u = await query('UPDATE otp_codes SET attempts = attempts + 1 RETURNING attempts', [otpId]);
    return u.rows[0].attempts >= OTP_MAX_ATTEMPTS ? 'locked' : 'wrong';
  }
  await query('UPDATE otp_codes SET used_at = now() WHERE id = $1', [otpId]);
  return 'ok';
}

/* ---------------- reports ---------------- */

async function createReport(userId, r) {
  const res = await query(
    `INSERT INTO reports
      (user_id, ticket_id, scenario, mood, final_status, overall_score, empathy,
       technical_accuracy, resolution, communication, verdict, strengths, improvements, transcript, duration_sec)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
     RETURNING *`,
    [
      userId, r.ticketId, r.scenario, r.mood, r.finalStatus, r.overallScore, r.empathy,
      r.technicalAccuracy, r.resolution, r.communication, r.verdict,
      JSON.stringify(r.strengths || []), JSON.stringify(r.improvements || []), JSON.stringify(r.transcript || []),
      r.durationSec == null ? null : r.durationSec
    ]
  );
  return res.rows[0];
}

/** Summary rows (no transcript/strengths) for list views. */
async function listReportSummariesByUser(userId) {
  const r = await query(`SELECT ${REPORT_SUMMARY_COLS} FROM reports WHERE user_id = $1 ORDER BY created_at DESC`, [userId]);
  return r.rows;
}

async function getReportById(reportId) {
  const r = await query('SELECT * FROM reports WHERE id = $1', [reportId]);
  return r.rows[0] || null;
}

/** All sessions with the owning agent's details, for the admin portal. */
async function listAllReportsWithUsers({ limit = 500 } = {}) {
  const r = await query(
    `SELECT r.id, r.user_id, r.ticket_id, r.scenario, r.mood, r.final_status, r.overall_score, r.empathy,
            r.technical_accuracy, r.resolution, r.communication, r.verdict, r.duration_sec, r.created_at,
            u.name AS user_name, u.email AS user_email, u.sap_id AS user_sap_id, u.project AS user_project, u.lob AS user_lob
     FROM reports r
     JOIN users u ON u.id = r.user_id
     ORDER BY r.created_at DESC
     LIMIT $1`,
    [limit]
  );
  return r.rows;
}

async function adminOverview() {
  const totals = await query(`
    SELECT COUNT(*)::int AS total_reports,
           COUNT(DISTINCT user_id)::int AS active_agents,
           COALESCE(ROUND(AVG(overall_score)), 0)::int AS avg_score,
           COUNT(*) FILTER (WHERE created_at > now() - interval '7 days')::int AS reports_7d,
           COUNT(*) FILTER (WHERE final_status = 'resolved')::int AS resolved_count
    FROM reports
  `);
  const top = await query(`
    SELECT u.id, u.name, ROUND(AVG(r.overall_score))::int AS avg_score, COUNT(r.id)::int AS report_count
    FROM reports r JOIN users u ON u.id = r.user_id
    GROUP BY u.id HAVING COUNT(r.id) >= 1
    ORDER BY AVG(r.overall_score) DESC, COUNT(r.id) DESC
    LIMIT 1
  `);
  const trend = await query(`
    SELECT date_trunc('day', created_at)::date AS day, ROUND(AVG(overall_score))::int AS avg_score, COUNT(*)::int AS sessions
    FROM reports WHERE created_at > now() - interval '30 days'
    GROUP BY 1 ORDER BY 1
  `);
  return { ...totals.rows[0], top_agent: top.rows[0] || null, trend: trend.rows };
}

module.exports = {
  pool, query, initSchema,
  createUser, findUserByEmail, findUserBySapId, findUserById, setUserPassword, getSessionEpoch, markEmailVerified, listUsersWithStats,
  recordFailedLogin, clearFailedLogins, LOCK_MINUTES,
  createOtp, countRecentOtps, verifyOtp, OTP_MAX_ATTEMPTS,
  createReport, listReportSummariesByUser, getReportById, listAllReportsWithUsers, adminOverview
};
