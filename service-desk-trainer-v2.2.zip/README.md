# Service Desk Trainer

A training simulator for IT / DevOps service desk agents. The trainee picks a client mood and a scenario, handles the ticket in a live chat with an AI-played client, and gets a scored report (empathy, technical accuracy, resolution, communication) with concrete strengths and improvements. Reports are saved per user and exportable as TXT or Excel. An admin portal shows global metrics, every session, and per-agent records.

Powered by CareerShaper.

## What's in v2

**Rebuilt end to end.** The frontend is now served from `public/` only, the server assembles all AI prompts itself, and the API contract matches what the pages call.

New in this version:

- **Streaming client replies.** The simulated client's message appears word by word (Gemini `streamGenerateContent` → server-sent events → the chat bubble), with a typing indicator before the first token.
- **Session persistence.** Refreshing or navigating away mid-ticket no longer loses the conversation. The setup page offers to resume or discard an open ticket.
- **Dashboard analytics.** Score trend chart, category averages, resolution rate, and a comparison of your latest five sessions against the five before. Session history is searchable, filterable by outcome and date range, and sortable by any column.
- **Working admin portal.** Overview stats, 30-day daily-average trend, all sessions with search/filter/sort, an Agents tab with per-agent stats and drill-down, password reset via an in-app dialog, and a one-click Excel export of every session.
- **Email one-time codes.** Signing in and creating an account both finish with a 6-digit code sent to the user's email (so an account can only be used by whoever owns the address); "Trust this device for 30 days" skips the code on a known browser. Password reset uses the same code on the sign-in page, no links, no separate page. Without SMTP configured, codes are printed to the server log (and shown in the UI outside production).
- **Form validation.** Inline field errors on blur, password strength meter, show/hide password, server-side field errors mapped back onto the form.
- **Toasts, skeleton loaders, and an in-app modal** replace `alert()` / `confirm()` / `prompt()` and blank loading states.
- **Light theme by default**, dark available with a persisted preference, full keyboard navigation, `prefers-reduced-motion` support, and a responsive layout down to 320px.

Bugs fixed from v1:

| Bug | Fix |
| --- | --- |
| Admin page called `/api/admin/reports` and `/api/admin/reports/download-excel`, which did not exist; the admin portal never loaded | Both endpoints (plus `/api/admin/overview`) now exist |
| `express.static(__dirname)` served `server.js`, `db.js`, `package.json` to anyone | Only `public/` is served |
| `/login`, `/dashboard` etc. returned 404 when run locally (no `extensions: ['html']`) | Clean URLs work everywhere |
| Browser built the Gemini system prompt and sent it to the server, making `/api/turn` an open LLM proxy for any signed-in user | Prompts, personas, and schemas live in `lib/catalog.js`; the client sends only ids and the transcript |
| JWT fell back to a hard-coded dev secret in production if `JWT_SECRET` was missing | Server refuses to start in production without it |
| Chat state lived only in memory | Saved to `sessionStorage`, resumable |
| `app.listen()` at module scope; not safe for serverless | App is exported; listens only when run directly |
| Rate limiter ignored `X-Forwarded-For` behind Vercel | `trust proxy` enabled |
| Unused `xlsx` dependency | Removed (`exceljs` does the exports) |
| No CSRF defence beyond `SameSite=Lax` | Origin check on all state-changing requests |
| Inline scripts on every page; no Content-Security-Policy | All page scripts in `public/assets/pages/`; strict CSP (`script-src 'self'`), HSTS, COOP |
| Unlimited password guesses per account | Locked for 15 minutes after 10 failures (plus per-IP rate limits) |
| Login timing revealed whether an email existed | Unknown emails still run a bcrypt comparison |
| Changing a password left existing sessions valid | `session_epoch` bump invalidates every session and trusted device |
| Agents could instruct the AI client ("mark this resolved", "satisfaction 100") | Both prompts treat agent text as untrusted; scoring flags manipulation attempts as an improvement |

## Project layout

```
server.js            Express app and all routes (exported; listens when run directly)
db.js                Postgres access layer and schema (users, reports, otp_codes)
auth.js              Password hashing, JWT cookies, guards, one-time codes, trusted devices
lib/catalog.js       Moods, scenarios, response schemas, prompt builders
lib/gemini.js        Gemini client: one-shot JSON and SSE streaming
lib/excel.js         Excel report builders
lib/mailer.js        One-time-code emails (nodemailer or console fallback)
public/              Everything the browser gets
  assets/app.css     Design tokens and components
  assets/app.js      Shared runtime: API client, SSE reader, toasts, modal, forms, theme, tables, charts
  assets/pages/      One script per page (required by the CSP)
  login.html  setup.html  chat.html  dashboard.html  report.html  admin.html  404.html
test/                Streaming and HTTP tests, Playwright visual check
```

## Running locally

```bash
npm install
cp .env.example .env     # fill in GEMINI_API_KEY, DATABASE_URL, JWT_SECRET
npm start                # http://localhost:3000
```

The schema is created automatically on first use. To seed an admin account, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before the first run.

### Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `GEMINI_API_KEY` | yes | Google AI Studio key |
| `DATABASE_URL` | yes | Postgres connection string (Neon works) |
| `JWT_SECRET` | yes in production | Long random string for session cookies |
| `GEMINI_MODEL` | no | Defaults to `gemini-3.1-flash-lite` |
| `PGSSL` | no | `true` for hosted Postgres that requires SSL |
| `SMTP_URL`, `MAIL_FROM` | recommended | Deliver one-time codes by email. Without them codes are printed to the server log (and returned to the browser outside production) |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`, `ADMIN_SAP_ID` | no | One-time admin bootstrap |

## Deploying to Vercel

`vercel.json` builds `server.js` as a Node function, bundles `public/` and `lib/`, and routes every path to it. Set the environment variables above in Project Settings. Streaming responses work on Vercel's Node runtime.

## API

All JSON, cookie-authenticated. State-changing requests must be same-origin.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/health` | Config sanity check (no secrets) |
| GET | `/api/catalog` | Moods and scenarios (public fields only) |
| POST | `/api/auth/signup` | Creates the account and emails a code → `{ otpRequired, challenge, email, ttlMin }` |
| POST | `/api/auth/login` | Checks the password. Trusted device → user + cookie; otherwise emails a code → `{ otpRequired, challenge, ... }` |
| POST | `/api/auth/verify` | `{ challenge, code, trustDevice }` → user + session cookie |
| POST | `/api/auth/resend` | `{ challenge }` → new code, new challenge |
| POST | `/api/auth/forgot` | `{ email }` → always `{ challenge }` (decoy for unknown emails) |
| POST | `/api/auth/reset` | `{ challenge, code, password, confirmPassword }` |
| POST | `/api/auth/logout` | `{ forgetDevice? }` |
| | | Validation errors return `{ error, fields }`; codes expire after 10 minutes and burn after 5 wrong tries |
| GET | `/api/me` | Current user |
| POST | `/api/session/turn` | `{ moodId, scenarioId, history }` → SSE: `partial` (reply so far), `done` (`reply, satisfaction, status`), `error` |
| POST | `/api/session/score` | `{ moodId, scenarioId, ticketId, finalStatus, history, durationSec }` → report with `reportId` |
| GET | `/api/reports` | Own sessions (summaries) |
| GET | `/api/reports/:id` `/download` `/download-excel` | Owner or admin |
| GET | `/api/admin/overview` `/reports` `/reports/download-excel` `/users` `/users/:id/reports` | Admin |
| POST | `/api/admin/users/:id/reset-password` | Admin |

## Tests

```bash
node test/http_stream_test.js          # boots the app with a mocked Gemini; SSE + guards
PORT=4100 node server.js &  python3 test/visual_check.py   # screenshots every page (needs Playwright)
```

## Migrating from v1

- Frontend files moved from the repo root into `public/` (`shared.css`/`shared.js` → `public/assets/app.css`/`app.js`).
- Existing databases are migrated automatically (`duration_sec`, `email_verified_at`, `session_epoch`, lockout columns and the `otp_codes` table are added on first run).
- Existing users will be asked for an email code on their next sign-in; make sure SMTP is configured before deploying, or they will need the code from the server log.
- `JWT_SECRET` is now mandatory in production. Existing sessions stay valid if the secret is unchanged.
- The `garak_*` scanner config files were removed from the repo. **They contained a live session cookie.** Rotate `JWT_SECRET` (which invalidates all sessions) and purge those files from git history.
