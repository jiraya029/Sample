# Service Desk Trainer

A training simulator for IT / DevOps service desk agents. The trainee picks a client mood and a scenario, then handles the ticket either in a **text chat** or on a **live voice call** with an AI-played client, and gets a scored report (empathy, technical accuracy, resolution, communication) with concrete strengths and improvements. Both modes are scored by the same model on the same scale. Reports are saved per user and exportable as TXT or Excel. An admin portal shows global metrics, every session, and per-agent records.

All AI runs on **Amazon Bedrock** with a single API key:

| Purpose | Model | Why |
| --- | --- | --- |
| Chat client + report scoring | Claude Sonnet (`BEDROCK_TEXT_MODEL`) | Holds a persona under pressure, returns reliable structured output, strongest rubric-based evaluator available on Bedrock. One model for both keeps chat and voice on an identical grading scale. |
| Live voice client | Amazon Nova Sonic (`BEDROCK_VOICE_MODEL`) | Speech-to-speech in one bidirectional stream: mood carries in the voice, low latency, emits both sides' transcript as it goes. |

## v3: live voice calls

- **Voice mode** on the setup page. The browser captures the microphone (AudioWorklet, downsampled to 16 kHz PCM), streams it over a WebSocket to `/ws/voice`, and plays back the client's 24 kHz speech gaplessly. The client speaks first. Barge-in works: if the agent talks over the client, playback is flushed.
- **Live transcript** with the client's in-progress sentence shown as it's spoken, then committed when Nova finalises it.
- **Live gauge** in voice mode is estimated by the text model from the transcript after each client turn (Nova Sonic doesn't produce a satisfaction number). Resolved / escalated is surfaced as a prompt to end the call rather than cutting the audio.
- **Same report** for both modes; voice reports carry `mode = 'voice'`, shown as a pill on dashboard/admin/report and as a column in Excel. The scoring prompt is told the transcript came from speech recognition so it ignores transcription slips.
- **Per-mood voices** (matthew / tiffany / amy) so calls don't all sound the same.
- **Limits**: one live call per user, `VOICE_MAX_SESSIONS` per instance, `VOICE_MAX_CALL_MINUTES` per call.

### Why the app moved off Vercel

A live call is one long-lived WebSocket per user relaying audio both ways. Serverless functions can't hold that open, so the app is now a plain Node server (`server.createServer()` = Express + WebSocket on one port). Deploy it anywhere that runs a persistent Node process: Railway, Render, Fly.io, an EC2/VM with a reverse proxy, or the included `Dockerfile`. Everything else is unchanged.



Powered by CareerShaper.

## What's in v2

**Rebuilt end to end.** The frontend is now served from `public/` only, the server assembles all AI prompts itself, and the API contract matches what the pages call.

New in this version:

- **Streaming client replies.** The simulated client's message appears word by word (Bedrock `ConverseStream` → server-sent events → the chat bubble), with a typing indicator before the first token.
- **Session persistence.** Refreshing or navigating away mid-ticket no longer loses the conversation. The setup page offers to resume or discard an open ticket.
- **Dashboard analytics.** Score trend chart, category averages, resolution rate, and a comparison of your latest five sessions against the five before. Session history is searchable, filterable by outcome and date range, and sortable by any column.
- **Working admin portal.** Overview stats, 30-day daily-average trend, all sessions with search/filter/sort, an Agents tab with per-agent stats and drill-down, password reset via an in-app dialog, and a one-click Excel export of every session.
- **Email one-time codes.** Signing in and creating an account both finish with a 6-digit code sent to the user's email (so an account can only be used by whoever owns the address); "Trust this device for 30 days" skips the code on a known browser. Password reset uses the same code on the sign-in page, no links, no separate page. Without SMTP configured, codes are printed to the server log (and shown in the UI outside production).
- **Form validation.** Inline field errors on blur, password strength meter, show/hide password, server-side field errors mapped back onto the form.
- **Toasts, skeleton loaders, and an in-app modal** replace `alert()` / `confirm()` / `prompt()` and blank loading states.
- **Light theme by default**, dark available with a persisted preference, full keyboard navigation, `prefers-reduced-motion` support, and a responsive layout down to 320px.

Security audit (this pass):

| Issue | Severity | Fix |
| --- | --- | --- |
| `nodemailer` pinned to a version with 12 published advisories (SMTP/header injection, SSRF) | High | Bumped to `^10.0.10`, same API |
| JWT `verify()` didn't pin an algorithm allow-list | Low (defense-in-depth) | All sign/verify calls now pin `HS256` explicitly |
| Open redirect via `/login?next=` (`/\evil.com` parses as `//evil.com`) | Medium | `next` is now checked against a strict allow-list of internal pages |
| Spreadsheet formula injection: names, projects, verdicts and raw transcript text went into Excel exports unsanitized | Medium | Every free-text cell is neutralised (leading `=+-@` forces text) before being written |
| OTP timing side-channel: checking a code for an unknown account was faster than for a real one | Low | The decoy path now runs an equivalent-cost dummy query |
| Sign-in codes were printed to production logs whenever SMTP wasn't configured | Medium | Only logged in development; production gets a codeless warning instead |
| Signing up with someone else's email permanently blocked them from ever registering (the row was reserved before the email was verified) | Medium | An unverified signup can be reclaimed by a fresh signup attempt; a *verified* account is never touched |
| `admin/users/:id/...` passed unvalidated `:id` straight to the database | Low | Strict integer parsing, matching the pattern already used for report ids |
| **Git history still contains three live-looking session cookies** (`garak_config.json` etc. in commit `e16ed8e`) | **High - unresolved** | Requires the repo owner to run `git filter-repo`/BFG and rotate `JWT_SECRET`; this cannot be fixed from inside the app |

All of the above except the git-history item (which needs your action, not code) are covered by `test/http_stream_test.js`, run twice - once against a real Postgres instance seeded with real users, once with no database configured - so both the fixed logic and its fallback behavior are exercised.

Bugs fixed from v1:

| Bug | Fix |
| --- | --- |
| Admin page called `/api/admin/reports` and `/api/admin/reports/download-excel`, which did not exist; the admin portal never loaded | Both endpoints (plus `/api/admin/overview`) now exist |
| `express.static(__dirname)` served `server.js`, `db.js`, `package.json` to anyone | Only `public/` is served |
| `/login`, `/dashboard` etc. returned 404 when run locally (no `extensions: ['html']`) | Clean URLs work everywhere |
| Browser built the Gemini system prompt and sent it to the server, making `/api/turn` an open LLM proxy for any signed-in user | Prompts, personas, and schemas live in `lib/catalog.js`; the client sends only ids and the transcript |
| JWT fell back to a hard-coded dev secret in production if `JWT_SECRET` was missing | Server refuses to start in production without it |
| Chat state lived only in memory | Saved to `sessionStorage`, resumable |
| `app.listen()` at module scope; not safe for serverless | App is exported; listens only when run directly |
| Rate limiter ignored `X-Forwarded-For` behind Vercel | `trust proxy` enabled |
| Unused `xlsx` dependency | Removed (`exceljs` does the exports) |
| No CSRF defence beyond `SameSite=Lax` | Origin check on all state-changing requests |
| Inline scripts on every page; no Content-Security-Policy | All page scripts in `public/assets/pages/`; strict CSP (`script-src 'self'`), HSTS, COOP |
| Unlimited password guesses per account | Locked for 15 minutes after 10 failures (plus per-IP rate limits) |
| Login timing revealed whether an email existed | Unknown emails still run a bcrypt comparison |
| Changing a password left existing sessions valid | `session_epoch` bump invalidates every session and trusted device |
| Agents could instruct the AI client ("mark this resolved", "satisfaction 100") | Both prompts treat agent text as untrusted; scoring flags manipulation attempts as an improvement |

## Project layout

```
server.js            Express app and all routes (exported; listens when run directly)
db.js                Postgres access layer and schema (users, reports, otp_codes)
auth.js              Password hashing, JWT cookies, guards, one-time codes, trusted devices
lib/catalog.js       Moods, scenarios, response schemas, prompt builders
lib/bedrock.js       Bedrock text model (Claude Sonnet): Converse / ConverseStream with forced tool-use for structured output
lib/voice.js         Nova Sonic bidirectional-stream session (event protocol, audio in/out, transcripts, barge-in)
lib/voiceGateway.js  WebSocket endpoint /ws/voice: auth on upgrade, relay, live gauge, transcript hand-off
lib/excel.js         Excel report builders
lib/mailer.js        One-time-code emails (nodemailer or console fallback)
public/              Everything the browser gets
  assets/app.css     Design tokens and components
  assets/app.js      Shared runtime: API client, SSE reader, toasts, modal, forms, theme, tables, charts
  assets/pages/      One script per page (required by the CSP)
  assets/pcm-capture.worklet.js   AudioWorklet: mic -> 16 kHz PCM16 frames
  login.html  setup.html  chat.html  voice.html  dashboard.html  report.html  admin.html  404.html
Dockerfile           Production image (node:22-alpine)
test/                Streaming and HTTP tests, Playwright visual check
```

## Running locally

```bash
npm install
cp .env.example .env     # fill in AWS_BEARER_TOKEN_BEDROCK, AWS_REGION, DATABASE_URL, JWT_SECRET
npm start                # http://localhost:3000
```

The schema is created automatically on first use. To seed an admin account, set `ADMIN_EMAIL` and `ADMIN_PASSWORD` before the first run.

### Environment variables

| Variable | Required | Purpose |
| --- | --- | --- |
| `AWS_BEARER_TOKEN_BEDROCK` | yes | Bedrock API key; the AWS SDK reads it natively |
| `AWS_REGION` | yes | Region where the models are enabled |
| `DATABASE_URL` | yes | Postgres connection string (Neon works) |
| `JWT_SECRET` | yes in production | Long random string for session cookies |
| `BEDROCK_TEXT_MODEL` | no | Claude Sonnet id / inference profile for chat + scoring |
| `BEDROCK_VOICE_MODEL` | no | Defaults to `amazon.nova-sonic-v1:0` |
| `VOICE_MAX_SESSIONS`, `VOICE_MAX_CALL_MINUTES` | no | Concurrency and duration caps for live calls |
| `PGSSL` | no | `true` for hosted Postgres that requires SSL |
| `SMTP_URL`, `MAIL_FROM` | recommended | Deliver one-time codes by email. Without them codes are printed to the server log (and returned to the browser outside production) |
| `ADMIN_EMAIL`, `ADMIN_PASSWORD`, `ADMIN_NAME`, `ADMIN_SAP_ID` | no | One-time admin bootstrap |

## Deploying

Any persistent Node 18+ host works. The included `Dockerfile` is the simplest route:

```bash
docker build -t service-desk-trainer .
docker run -p 3000:3000 --env-file .env service-desk-trainer
```

- **Railway / Render / Fly.io**: point them at the repo; they detect the Dockerfile (or use `npm start`). Set the environment variables from `.env.example` in the dashboard. Health check path: `/api/health`.
- **Behind nginx/Caddy**: proxy `/` to the Node port **with WebSocket upgrade enabled** (nginx: `proxy_http_version 1.1; proxy_set_header Upgrade $http_upgrade; proxy_set_header Connection "upgrade";`). Voice calls will not connect without it. Also forward `X-Forwarded-Proto` and `X-Forwarded-Host`; the app has `trust proxy` on.
- **Bedrock access**: create an API key in the AWS console (Bedrock -> API keys) and set `AWS_BEARER_TOKEN_BEDROCK` + `AWS_REGION`. Enable model access for Claude Sonnet and Nova Sonic in that region. Verify the exact model ids in the model catalog and set `BEDROCK_TEXT_MODEL` / `BEDROCK_VOICE_MODEL` if they differ from the defaults in `.env.example`.
- Voice requires HTTPS in production (browsers only allow microphone access on secure origins). Any of the hosts above provide TLS.

## API

All JSON, cookie-authenticated. State-changing requests must be same-origin.

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/health` | Config sanity check (no secrets) |
| GET | `/api/catalog` | Moods and scenarios (public fields only) |
| POST | `/api/auth/signup` | Creates the account and emails a code → `{ otpRequired, challenge, email, ttlMin }` |
| POST | `/api/auth/login` | Checks the password. Trusted device → user + cookie; otherwise emails a code → `{ otpRequired, challenge, ... }` |
| POST | `/api/auth/verify` | `{ challenge, code, trustDevice }` → user + session cookie |
| POST | `/api/auth/resend` | `{ challenge }` → new code, new challenge |
| POST | `/api/auth/forgot` | `{ email }` → always `{ challenge }` (decoy for unknown emails) |
| POST | `/api/auth/reset` | `{ challenge, code, password, confirmPassword }` |
| POST | `/api/auth/logout` | `{ forgetDevice? }` |
| | | Validation errors return `{ error, fields }`; codes expire after 10 minutes and burn after 5 wrong tries |
| GET | `/api/me` | Current user |
| POST | `/api/session/turn` | `{ moodId, scenarioId, history }` → SSE: `partial` (reply so far), `done` (`reply, satisfaction, status`), `error` |
| WS | `/ws/voice` | Live call. Send `{type:'start', moodId, scenarioId}`, then binary PCM16 16 kHz; receive `ready`, `transcript`, binary PCM16 24 kHz, `interrupted`, `satisfaction`, `ended {history, durationSec}`. Authenticated by the session cookie on the upgrade. |
| POST | `/api/session/score` | `{ moodId, scenarioId, ticketId, finalStatus, history, durationSec, mode }` → report with `reportId` (`mode` is `chat` or `voice`) |
| GET | `/api/reports` | Own sessions (summaries) |
| GET | `/api/reports/:id` `/download` `/download-excel` | Owner or admin |
| GET | `/api/admin/overview` `/reports` `/reports/download-excel` `/users` `/users/:id/reports` | Admin |
| POST | `/api/admin/users/:id/reset-password` | Admin |

## Tests

```bash
npm test                               # provider + Nova protocol unit tests, then HTTP + WebSocket tests (all against fakes, no AWS calls)
DATABASE_URL=postgres://... npm test   # same, but the auth/signup/scoring paths run against a real scratch database
PORT=4100 node server.js &  python3 test/visual_check.py   # screenshots every page (needs Playwright)
```

The tests never call AWS. `lib/bedrock.js` and `lib/voice.js` expose a `_setClient()` hook that the tests use to inject fakes that speak the real Converse / Nova Sonic event shapes. **The Nova Sonic event protocol was written from the published documentation and cannot be verified against the live service from this environment** - run one real call after deploying and check the server log; if event names have shifted, they're all in `lib/voice.js`.

## Migrating from v1

- **v3**: Gemini is gone. Set `AWS_BEARER_TOKEN_BEDROCK` and `AWS_REGION`; remove `GEMINI_API_KEY`. `vercel.json` is removed; deploy as a persistent Node process (see Deploying). Existing reports are treated as `mode = 'chat'`.
- Frontend files moved from the repo root into `public/` (`shared.css`/`shared.js` → `public/assets/app.css`/`app.js`).
- Existing databases are migrated automatically (`duration_sec`, `email_verified_at`, `session_epoch`, lockout columns and the `otp_codes` table are added on first run).
- Existing users will be asked for an email code on their next sign-in; make sure SMTP is configured before deploying, or they will need the code from the server log.
- `JWT_SECRET` is now mandatory in production. Existing sessions stay valid if the secret is unchanged.
- The `garak_*` scanner config files were removed from the repo. **They contained a live session cookie.** Rotate `JWT_SECRET` (which invalidates all sessions) and purge those files from git history.
