// Boots the app in-process with a mocked Gemini and exercises /api/session/turn
// over real HTTP, plus the validation / auth / CSRF guards around it.
// Run: node test/http_stream_test.js
process.env.GEMINI_API_KEY = 'test-key';
const path = require('path');
const jwt = require('jsonwebtoken');

const chunks = ['{"reply": "This is the third', ' time this week. Just fix it.",', ' "satisfaction": 15, "status": "ongoing"}'];
const sse = chunks.map(c => 'data: ' + JSON.stringify({ candidates: [{ content: { parts: [{ text: c }] } }] }) + '\n\n').join('');
const realFetch = global.fetch;
global.fetch = async (url, init) => {
  if (String(url).includes('generativelanguage')) {
    return { ok: true, status: 200, body: new ReadableStream({ start(c) { const e = new TextEncoder(); c.enqueue(e.encode(sse.slice(0, 40))); setTimeout(() => { c.enqueue(e.encode(sse.slice(40))); c.close(); }, 20); } }) };
  }
  return realFetch(url, init);
};

const app = require(path.join(__dirname, '..', 'server.js'));
const PORT = 4101;
const base = 'http://localhost:' + PORT;

const server = app.listen(PORT, async () => {
  let failures = 0;
  const check = (label, cond, detail) => { console.log((cond ? 'PASS ' : 'FAIL ') + label + (detail ? '  -> ' + detail : '')); if (!cond) failures++; };
  const token = jwt.sign({ sub: 1, role: 'user', name: 'Test Agent' }, 'dev-secret-change-me');
  const H = { 'Content-Type': 'application/json', Cookie: 'sdt_token=' + token };
  const post = (p, body, headers) => realFetch(base + p, { method: 'POST', headers: { ...H, ...(headers || {}) }, body: JSON.stringify(body) });

  const res = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [] }, { Origin: base });
  const text = await res.text();
  const events = [...text.matchAll(/event: (\w+)\ndata: (.*)\n/g)].map(m => [m[1], JSON.parse(m[2])]);
  const done = events.find(e => e[0] === 'done');
  check('SSE status 200 + event-stream', res.status === 200 && /text\/event-stream/.test(res.headers.get('content-type')), res.status + ' ' + res.headers.get('content-type'));
  check('SSE emits partial events', events.some(e => e[0] === 'partial'), events.map(e => e[0]).join(','));
  check('SSE done payload correct', done && done[1].satisfaction === 15 && done[1].status === 'ongoing' && done[1].reply.endsWith('fix it.'), done && JSON.stringify(done[1]));

  let r = await post('/api/session/turn', { moodId: 'nope', scenarioId: 'network', history: [] });
  check('unknown mood -> 400', r.status === 400, await r.text());
  r = await realFetch(base + '/api/session/turn', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' });
  check('no auth -> 401', r.status === 401, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [] }, { Origin: 'https://evil.example' });
  check('cross-origin POST -> 403', r.status === 403, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: Array(61).fill({ role: 'agent', text: 'hi' }) });
  check('61 turns -> 400', r.status === 400, await r.text());
  r = await post('/api/session/turn', { moodId: 'furious', scenarioId: 'network', history: [{ role: 'hacker', text: 'x' }] });
  check('malformed history -> 400', r.status === 400, await r.text());
  r = await realFetch(base + '/api/reports');
  check('anon /api/reports -> 401 (no DB wake)', r.status === 401, await r.text());
  r = await realFetch(base + '/api/reports', { headers: { Cookie: 'sdt_token=' + token } });
  check('authed /api/reports without DB -> 503', r.status === 503, await r.text());
  r = await realFetch(base + '/api/catalog');
  const cat = await r.json();
  check('catalog hides personas', !JSON.stringify(cat).includes('persona') && cat.moods.length === 6 && cat.scenarios.length === 10);

  console.log(failures ? '\n' + failures + ' FAILURE(S)' : '\nALL HTTP TESTS PASS');
  server.close(() => process.exit(failures ? 1 : 0));
});
