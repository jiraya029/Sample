document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, toast, modal, busy, escapeHtml } = SDT;
  const user = await requireAuth();
  if (!user) return;

  let session = null;
  try { session = JSON.parse(sessionStorage.getItem('sdt_session') || 'null'); } catch (e) { session = null; }
  if (!session || !session.moodId || !session.scenarioId) { window.location.replace('/setup'); return; }
  if (session.mode === 'voice') { window.location.replace('/voice'); return; }
  if (session.ended) { window.location.replace('/dashboard'); return; }

  const save = () => sessionStorage.setItem('sdt_session', JSON.stringify(session));
  const thread = $('#thread'), input = $('#agent-input'), sendBtn = $('#send-btn'), endBtn = $('#end-btn');
  let busyTurn = false;

  /* ---- header ---- */
  $('#ticket-id').textContent = session.ticketId;
  $('#ticket-scenario').textContent = session.scenarioLabel;
  $('#ticket-mood').textContent = session.moodLabel + ' client';
  document.documentElement.style.setProperty('--mood-color', 'var(--' + (session.moodTone === 'accent' ? 'accent' : (session.moodTone || 'muted')) + ')');
  document.title = session.ticketId + ' · Service Desk Trainer';

  /* ---- timer ---- */
  const tick = () => {
    const s = Math.floor((Date.now() - session.startedAt) / 1000);
    $('#timer').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  };
  tick(); const timer = setInterval(tick, 1000);

  /* ---- gauge ---- */
  const ARC = 251.3;
  function updateGauge(v) {
    v = Math.max(0, Math.min(100, Number(v) || 0));
    $('#gauge-needle').style.transform = 'rotate(' + (-90 + (v / 100) * 180) + 'deg)';
    $('#gauge-fg').setAttribute('stroke-dashoffset', (ARC - (v / 100) * ARC).toFixed(1));
    const [color, label] = v < 30 ? ['var(--red)', 'Critical'] : v < 55 ? ['var(--amber)', 'Tense'] : v < 80 ? ['var(--accent)', 'Cooling'] : ['var(--green)', 'Satisfied'];
    $('#gauge-fg').setAttribute('stroke', color);
    $('#gauge-state').textContent = label + ' \u00b7 ' + Math.round(v);
    $('#gauge-state').style.color = color;
  }
  updateGauge(session.satisfaction);

  /* ---- thread rendering ---- */
  const scrollDown = () => { thread.scrollTop = thread.scrollHeight; };
  function bubble(role, text) {
    const wrap = el('div', 'bubble-wrap ' + role);
    wrap.appendChild(el('div', 'bubble-sender', role === 'agent' ? user.name : 'Client'));
    const b = el('div', 'bubble ' + role, text); wrap.appendChild(b);
    thread.appendChild(wrap); scrollDown();
    return b;
  }
  function systemLine(text, cls) { const s = el('div', 'system-line' + (cls ? ' ' + cls : ''), text); thread.appendChild(s); scrollDown(); return s; }
  let typingEl = null;
  const showTyping = () => { if (typingEl) return; typingEl = el('div', 'typing'); typingEl.setAttribute('aria-label', 'Client is typing'); typingEl.innerHTML = '<span></span><span></span><span></span>'; thread.appendChild(typingEl); scrollDown(); };
  const hideTyping = () => { if (typingEl) { typingEl.remove(); typingEl = null; } };
  // Download the conversation so far (before scoring).
  const dlBtns = [$('#dl-txt'), $('#dl-xlsx')];
  const refreshDl = () => dlBtns.forEach(b => { b.disabled = !session.history.length; });
  const exportTranscript = async (format, btn) => {
    busy(btn, true);
    try {
      await SDT.downloadFile('/api/session/export', {
        format, moodId: session.moodId, scenarioId: session.scenarioId, ticketId: session.ticketId,
        history: session.history, mode: 'chat', durationSec: Math.floor((Date.now() - session.startedAt) / 1000)
      }, session.ticketId + '-transcript.' + format);
    } catch (err) { toast.error('Download failed', err.message); }
    finally { busy(btn, false); }
  };
  $('#dl-txt').addEventListener('click', () => exportTranscript('txt', $('#dl-txt')));
  $('#dl-xlsx').addEventListener('click', () => exportTranscript('xlsx', $('#dl-xlsx')));

  const updateReplyCount = () => { $('#reply-count').textContent = session.history.filter(m => m.role === 'agent').length; refreshDl(); };

  // Rehydrate an existing conversation (refresh / navigation).
  if (session.history.length) {
    session.history.forEach(m => bubble(m.role, m.text));
    systemLine('Resumed your open ticket.');
    updateReplyCount();
  }

  /* ---- composer behaviour ---- */
  const autosize = () => { input.style.height = 'auto'; input.style.height = Math.min(160, input.scrollHeight) + 'px'; $('#char-count').textContent = input.value.length > 1500 ? input.value.length + ' / 2000' : ''; };
  input.addEventListener('input', autosize);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendAgentMessage(); } });
  sendBtn.addEventListener('click', sendAgentMessage);
  const setBusy = (on) => { busyTurn = on; sendBtn.disabled = on; input.disabled = on; if (!on) input.focus(); };

  /* ---- one client turn, streamed ---- */
  /**
   * One client turn. The serverless API returns the whole reply at once (API
   * Gateway can't stream a Lambda response), so the "live typing" is a
   * client-side reveal over text we already have - same feel, no streaming.
   */
  async function clientTurn() {
    setBusy(true); showTyping();
    try {
      const turn = await api('/api/session/turn', { method: 'POST', body: { moodId: session.moodId, scenarioId: session.scenarioId, history: session.history } });
      hideTyping();
      const b = bubble('client', ''); b.classList.add('streaming');
      await typewrite(b, turn.reply);
      b.classList.remove('streaming');
      session.history.push({ role: 'client', text: turn.reply }); refreshDl();
      session.satisfaction = turn.satisfaction; save();
      updateGauge(turn.satisfaction);
      setBusy(false);
      return turn;
    } catch (err) {
      hideTyping();
      const line = systemLine('', 'error');
      line.innerHTML = escapeHtml(err.message) + ' <button type="button" class="link-btn" id="retry-turn">Try again</button>';
      $('#retry-turn').addEventListener('click', () => { line.remove(); clientTurn().then(handleTurn); });
      setBusy(false);
      return null;
    }
  }
  /** Reveals text word by word (~55 wpm feel); instant under reduced-motion. */
  function typewrite(el, text) {
    return new Promise((resolve) => {
      if (SDT.reducedMotion() || !text) { el.textContent = text; return resolve(); }
      const words = text.split(/(\s+)/); let i = 0;
      const step = () => {
        el.textContent += words[i++]; scrollDown();
        if (i < words.length) setTimeout(step, /\s/.test(words[i - 1]) ? 0 : 45 + Math.random() * 40); else resolve();
      };
      step();
    });
  }
  function handleTurn(turn) {
    if (turn && turn.status !== 'ongoing') {
      session.ended = true; save();
      systemLine(turn.status === 'resolved' ? 'Client considers this resolved.' : 'Client has escalated away from this chat.');
      setBusy(true); endBtn.disabled = true;
      setTimeout(() => finish(turn.status), 900);
    }
  }

  async function sendAgentMessage() {
    if (busyTurn || session.ended) return;
    const text = input.value.trim();
    if (!text) return;
    if (text.length > 2000) return toast.warn('Message too long', 'Keep replies under 2000 characters.');
    input.value = ''; autosize();
    session.history.push({ role: 'agent', text }); save();
    bubble('agent', text); updateReplyCount();
    handleTurn(await clientTurn());
  }

  // First turn: the client opens.
  if (!session.history.length) handleTurn(await clientTurn());

  /* ---- ending ---- */
  endBtn.addEventListener('click', async () => {
    if (session.ended) return;
    if (!session.history.some(m => m.role === 'agent')) return toast.warn('Nothing to score yet', 'Send at least one reply before ending the test.');
    const ok = await modal({ title: 'End the test now?', body: 'Your report will be generated from the conversation so far. You cannot return to this ticket afterwards.', confirmText: 'End and score', danger: true });
    if (ok) { session.ended = true; save(); finish('ended_by_agent'); }
  });

  async function finish(finalStatus) {
    clearInterval(timer);
    setBusy(true); endBtn.disabled = true; busy(endBtn, true);
    const line = systemLine('Generating your report...');
    const durationSec = Math.round((Date.now() - session.startedAt) / 1000);
    try {
      const report = await api('/api/session/score', { method: 'POST', body: { moodId: session.moodId, scenarioId: session.scenarioId, ticketId: session.ticketId, finalStatus, history: session.history, durationSec } });
      sessionStorage.removeItem('sdt_session');
      window.location.replace('/report?id=' + encodeURIComponent(report.reportId) + '&fresh=1');
    } catch (err) {
      line.remove();
      session.ended = false; save();
      const l = systemLine('', 'error');
      l.innerHTML = 'Could not generate your report: ' + escapeHtml(err.message) + ' <button type="button" class="link-btn" id="retry-score">Try again</button>';
      $('#retry-score').addEventListener('click', () => { l.remove(); session.ended = true; save(); finish(finalStatus); });
      busy(endBtn, false); endBtn.disabled = false;
    }
  }

  // Warn before leaving mid-conversation (state is saved, but be explicit).
  window.addEventListener('beforeunload', (e) => { if (!session.ended && busyTurn) { e.preventDefault(); e.returnValue = ''; } });
  input.focus();
});
