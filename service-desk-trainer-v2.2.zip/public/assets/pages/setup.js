document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, banner, busy, toast, escapeHtml, setFieldError, icon } = SDT;
  const user = await requireAuth();
  if (!user) return;

  // An unfinished session from a refresh/navigation? Offer to resume.
  try {
    const saved = JSON.parse(sessionStorage.getItem('sdt_session') || 'null');
    if (saved && !saved.ended && Array.isArray(saved.history) && saved.history.length) {
      const b = el('div', 'banner info');
      b.innerHTML = icon('info') + '<div>You have an open ticket <span class="mono">' + escapeHtml(saved.ticketId) + '</span> (' + escapeHtml(saved.scenarioLabel) + '). ' +
        '<a href="/chat">Resume it</a> or <button type="button" class="link-btn" id="discard-session">discard it</button>.</div>';
      $('#resume-slot').appendChild(b);
      $('#discard-session').addEventListener('click', () => { sessionStorage.removeItem('sdt_session'); b.remove(); toast.info('Ticket discarded'); });
    }
  } catch (e) { /* ignore */ }

  const moodSel = $('#mood-select'), scenSel = $('#scenario-select'), startBtn = $('#start-btn');
  let catalog;
  try { catalog = await api('/api/catalog'); }
  catch (err) { banner('#setup-banner', 'error', 'Could not load the scenario list: ' + err.message); return; }

  const fill = (sel, items, placeholder, label) => {
    sel.innerHTML = '';
    const ph = el('option', null, placeholder); ph.value = ''; ph.disabled = true; ph.selected = true; sel.appendChild(ph);
    items.forEach(it => { const o = el('option', null, label(it)); o.value = it.id; sel.appendChild(o); });
    sel.disabled = false;
  };
  fill(moodSel, catalog.moods, 'Choose a mood', m => m.label + (m.desc ? ' - ' + m.desc : ''));
  fill(scenSel, catalog.scenarios, 'Choose a scenario', s => s.label);

  const refresh = () => {
    startBtn.disabled = !(moodSel.value && scenSel.value);
    const m = catalog.moods.find(x => x.id === moodSel.value);
    $('#mood-hint').textContent = m ? 'Starts at ' + m.start + '/100 satisfaction. ' + (m.start < 30 ? 'Expect a rough opening.' : m.start < 40 ? 'Guarded, but workable.' : 'Cooperative if you are clear.') : 'How the client feels when they open the chat.';
    setFieldError(moodSel, ''); setFieldError(scenSel, '');
  };
  moodSel.addEventListener('change', refresh); scenSel.addEventListener('change', refresh);

  startBtn.addEventListener('click', () => {
    let bad = false;
    if (!moodSel.value) { setFieldError(moodSel, "Pick the client's mood."); bad = true; }
    if (!scenSel.value) { setFieldError(scenSel, 'Pick what the issue is.'); bad = true; }
    if (bad) return;
    const mood = catalog.moods.find(m => m.id === moodSel.value), scenario = catalog.scenarios.find(s => s.id === scenSel.value);
    sessionStorage.setItem('sdt_session', JSON.stringify({
      ticketId: 'SD-' + Math.floor(10000 + Math.random() * 89999),
      moodId: mood.id, scenarioId: scenario.id, moodLabel: mood.label, moodTone: mood.tone, scenarioLabel: scenario.label,
      satisfaction: mood.start, history: [], startedAt: Date.now(), ended: false
    }));
    busy(startBtn, true);
    window.location.href = '/chat';
  });
});
