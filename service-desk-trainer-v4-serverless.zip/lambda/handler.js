// lambda/handler.js
// API Gateway (HTTP API, payload v2.0) -> Express via serverless-http.
//
// One normalisation on the way out: API Gateway v2 expects Set-Cookie values
// in the response's `cookies` array. serverless-http only uses that array
// when Express produced *multiple* Set-Cookie headers; a single one (e.g.
// login without "trust this device") is left in `headers['set-cookie']`,
// which API Gateway handles inconsistently. Always move them to `cookies`.
const serverless = require('serverless-http');
const app = require('../server');

const inner = serverless(app, {
  // Excel/TXT downloads are the only non-JSON bodies; API Gateway needs them base64'd.
  binary: ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'application/octet-stream']
});

module.exports.handler = async (event, context) => {
  const res = await inner(event, context);
  if (res && res.headers) {
    const key = Object.keys(res.headers).find(k => k.toLowerCase() === 'set-cookie');
    if (key) {
      const v = res.headers[key];
      res.cookies = [...(res.cookies || []), ...(Array.isArray(v) ? v : [v])];
      delete res.headers[key];
    }
  }
  return res;
};
