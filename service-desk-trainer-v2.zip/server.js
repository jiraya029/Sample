/**
 * Service Desk Trainer - backend
 * ------------------------------
 * Express app. Serves the frontend from /public, keeps the Gemini API key on
 * the server, and exposes a small JSON API:
 *
 *   GET  /api/health
 *   GET  /api/catalog                     moods + scenarios for the setup screen
 *   POST /api/auth/signup|login|logout    session cookie auth
 *   POST /api/auth/forgot                 start password reset (never leaks account existence)
 *   POST /api/auth/reset                  finish password reset with token
 *   GET  /api/me
 *   POST /api/session/turn                one client turn, streamed as SSE
 *   POST /api/session/score               end-of-session scoring; saves the report
 *   GET  /api/reports                     my sessions (summaries)
 *   GET  /api/reports/:id                 one full report (owner or admin)
 *   GET  /api/reports/:id/download        TXT
 *   GET  /api/reports/:id/download-excel  XLSX
 *   GET  /api/admin/overview              aggregate stats
 *   GET  /api/admin/reports               all sessions
 *   GET  /api/admin/reports/download-excel
 *   GET  /api/admin/users                 agents with stats
 *   GET  /api/admin/users/:id/reports
 *   POST /api/admin/users/:id/reset-password
 *
 * Run locally:  npm install && npm start  ->  http://localhost:3000
 * On Vercel the app is exported and not listened on (see bottom of file).
 */

const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const db = require('./db');
const auth = require('./auth');
const gemini = require('./lib/gemini');
const catalog = require('./lib/catalog');
const mailer = require('./lib/mailer');
const excel = require('./lib/excel');

const app = express();
const PUBLIC_DIR = path.join(__dirname, 'public');
const IS_PROD = process.env.NODE_ENV === 'production';

// Behind Vercel / any reverse proxy: needed for correct client IPs in the rate
// limiter and for `secure` cookies to be recognised.
app.set('trust proxy', 1);
app.disable('x-powered-by');

/* ------------------------------------------------------------------ */
/* Global middleware                                                   */
/* ------------------------------------------------------------------ */

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
});

app.use(express.json({ limit: '1mb' }));
app.use((err, req, res, next) => {
  // Malformed JSON would otherwise fall through to Express's HTML error page.
  if (err && (err.type === 'entity.parse.failed' || err instanceof SyntaxError)) {
    return res.status(400).json({ error: 'Invalid request body.' });
  }
  next(err);
});
app.use(cookieParser());
app.use(auth.attachUser);

// Make sure the schema exists before any DB-backed route runs. initSchema is
// memoised, so this is a no-op after the first request per process.
app.use('/api', async (req, res, next) => {
  if (req.path === '/health' || req.path === '/catalog' || req.path === '/session/turn') return next();
  // Anonymous requests to protected routes will 401 anyway; don't wake the DB for them.
  if (!req.user && !req.path.startsWith('/auth/') && req.path !== '/me') return next();
  try { await db.initSchema(); next(); }
  catch (err) {
    console.error('[db] schema init failed:', err.message);
    res.status(503).json({ error: 'The database is not available right now.' });
  }
});

/* ------------------------------------------------------------------ */
/* Rate limits                                                         */
/* ------------------------------------------------------------------ */

const aiLimiter = rateLimit({
  windowMs: 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many requests. Slow down and try again shortly.' }
});
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, max: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again later.' }
});
const forgotLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, max: 5, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many reset requests. Please try again later.' }
});

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const str = (v, max = 200) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, sap_id: u.sap_id, project: u.project, lob: u.lob, role: u.role });
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, Number(n) || 0));

function fail(res, err, fallback = 'Something went wrong.') {
  const status = err && err.status && err.status >= 400 && err.status < 600 ? err.status : 500;
  if (status >= 500) console.error(err);
  res.status(status).json({ error: status >= 500 && !(err instanceof gemini.GeminiError) ? fallback : err.message });
}

function sendXlsx(res, wb, filename) {
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="' + filename + '"');
  return wb.xlsx.write(res).then(() => res.end());
}

async function loadReportForViewer(req, res) {
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) { res.status(400).json({ error: 'Invalid report id.' }); return null; }
  const report = await db.getReportById(id);
  if (!report) { res.status(404).json({ error: 'Report not found.' }); return null; }
  if (report.user_id !== req.user.sub && req.user.role !== 'admin') { res.status(403).json({ error: 'Access denied.' }); return null; }
  return report;
}

/* ------------------------------------------------------------------ */
/* Public                                                              */
/* ------------------------------------------------------------------ */

app.get('/api/health', (req, res) => {
  res.json({ ok: true, model: gemini.MODEL, ai: Boolean(process.env.GEMINI_API_KEY), db: Boolean(process.env.DATABASE_URL), mail: mailer.isConfigured() });
});

app.get('/api/catalog', (req, res) => {
  res.setHeader('Cache-Control', 'public, max-age=300');
  res.json(catalog.publicCatalog());
});

/* ------------------------------------------------------------------ */
/* Auth                                                                */
/* ------------------------------------------------------------------ */

app.post('/api/auth/signup', authLimiter, auth.sameOrigin, async (req, res) => {
  try {
    const b = req.body || {};
    const name = str(b.name, 80), email = str(b.email, 160).toLowerCase(), sapId = str(b.sapId, 40);
    const project = str(b.project, 80), lob = str(b.lob, 80);
    const { password, confirmPassword } = b;

    const fields = {};
    if (!name) fields.name = 'Enter your full name.';
    if (!email) fields.email = 'Enter your work email.'; else if (!EMAIL_RE.test(email)) fields.email = 'That email address does not look right.';
    if (!sapId) fields.sapId = 'Enter your SAP ID.';
    if (!project) fields.project = 'Project is required.';
    if (!lob) fields.lob = 'Line of Business is required.';
    const pwErr = auth.passwordProblem(password);
    if (pwErr) fields.password = pwErr;
    if (password !== confirmPassword) fields.confirmPassword = 'Passwords do not match.';
    if (Object.keys(fields).length) return res.status(400).json({ error: 'Please fix the highlighted fields.', fields });

    if (await db.findUserByEmail(email)) return res.status(409).json({ error: 'An account with this email already exists.', fields: { email: 'Already registered. Try signing in.' } });
    if (await db.findUserBySapId(sapId)) return res.status(409).json({ error: 'An account with this SAP ID already exists.', fields: { sapId: 'Already registered.' } });

    const passwordHash = await auth.hashPassword(password);
    const user = await db.createUser({ name, email, sapId, passwordHash, project, lob });
    auth.setAuthCookie(res, auth.issueToken(user));
    res.status(201).json(publicUser(user));
  } catch (err) { fail(res, err); }
});

app.post('/api/auth/login', authLimiter, auth.sameOrigin, async (req, res) => {
  try {
    const email = str((req.body || {}).email, 160).toLowerCase();
    const password = (req.body || {}).password;
    if (!email || !password) return res.status(400).json({ error: 'Enter your email and password.' });

    const user = await db.findUserByEmail(email);
    const ok = user && await auth.verifyPassword(password, user.password_hash);
    if (!ok) return res.status(401).json({ error: 'Invalid email or password.' });

    auth.setAuthCookie(res, auth.issueToken(user));
    res.json(publicUser(user));
  } catch (err) { fail(res, err); }
});

app.post('/api/auth/logout', auth.sameOrigin, (req, res) => {
  auth.clearAuthCookie(res);
  res.json({ ok: true });
});

app.get('/api/me', async (req, res) => {
  if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
  try {
    const user = await db.findUserById(req.user.sub);
    if (!user) { auth.clearAuthCookie(res); return res.status(401).json({ error: 'Session expired.' }); }
    res.json(publicUser(user));
  } catch (err) { fail(res, err); }
});

// Always answers the same way so it cannot be used to enumerate accounts.
app.post('/api/auth/forgot', forgotLimiter, auth.sameOrigin, async (req, res) => {
  const generic = { ok: true, message: 'If an account exists for that email, a reset link is on its way. It expires in ' + auth.RESET_TTL_MIN + ' minutes.' };
  try {
    const email = str((req.body || {}).email, 160).toLowerCase();
    if (!email || !EMAIL_RE.test(email)) return res.status(400).json({ error: 'Enter a valid email address.' });

    const user = await db.findUserByEmail(email);
    if (user) {
      const { token, tokenHash, expiresAt } = auth.newResetToken();
      await db.createPasswordReset(user.id, tokenHash, expiresAt);
      const result = await mailer.sendPasswordReset(req, { to: user.email, name: user.name, token });
      // In development with no SMTP, hand the link back so the flow can be tested end to end.
      if (!result.delivered && !IS_PROD) return res.json({ ...generic, devResetUrl: result.link });
    }
    res.json(generic);
  } catch (err) {
    console.error('[forgot]', err);
    res.json(generic);
  }
});

app.post('/api/auth/reset', authLimiter, auth.sameOrigin, async (req, res) => {
  try {
    const { token, password, confirmPassword } = req.body || {};
    if (!token || typeof token !== 'string') return res.status(400).json({ error: 'This reset link is invalid.' });
    const fields = {};
    const pwErr = auth.passwordProblem(password);
    if (pwErr) fields.password = pwErr;
    if (password !== confirmPassword) fields.confirmPassword = 'Passwords do not match.';
    if (Object.keys(fields).length) return res.status(400).json({ error: 'Please fix the highlighted fields.', fields });

    const reset = await db.findValidPasswordReset(auth.hashResetToken(token));
    if (!reset) return res.status(400).json({ error: 'This reset link is invalid or has expired. Request a new one.' });

    await db.setUserPassword(reset.user_id, await auth.hashPassword(password));
    await db.consumePasswordReset(reset.id);
    auth.clearAuthCookie(res);
    res.json({ ok: true });
  } catch (err) { fail(res, err); }
});

/* ------------------------------------------------------------------ */
/* Training session                                                    */
/* ------------------------------------------------------------------ */

function resolveSession(body, res) {
  const mood = catalog.findMood(body.moodId);
  const scenario = catalog.findScenario(body.scenarioId);
  if (!mood || !scenario) { res.status(400).json({ error: 'Unknown mood or scenario.' }); return null; }
  const h = catalog.sanitizeHistory(body.history || []);
  if (!h.ok) { res.status(400).json({ error: h.error }); return null; }
  return { mood, scenario, history: h.history };
}

// Streams `event: partial` (reply-so-far) then `event: done` (full turn), or `event: error`.
app.post('/api/session/turn', aiLimiter, auth.requireAuth, auth.sameOrigin, async (req, res) => {
  const s = resolveSession(req.body || {}, res);
  if (!s) return;

  res.status(200);
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  if (typeof res.flushHeaders === 'function') res.flushHeaders();

  const send = (event, data) => { if (!res.writableEnded) res.write('event: ' + event + '\ndata: ' + JSON.stringify(data) + '\n\n'); };
  const abort = new AbortController();
  req.on('close', () => abort.abort());
  const heartbeat = setInterval(() => { if (!res.writableEnded) res.write(': ping\n\n'); }, 15000);

  try {
    const turn = await gemini.streamJson(
      catalog.clientSystemPrompt(s.mood, s.scenario), catalog.clientContents(s.history), catalog.TURN_SCHEMA,
      (partial) => send('partial', { reply: partial }), abort.signal
    );
    const status = ['ongoing', 'resolved', 'escalated'].includes(turn.status) ? turn.status : 'ongoing';
    send('done', { reply: String(turn.reply || '').trim(), satisfaction: Math.round(clamp(turn.satisfaction, 0, 100)), status });
  } catch (err) {
    if (!abort.signal.aborted) {
      if (!(err instanceof gemini.GeminiError)) console.error('[turn]', err);
      send('error', { error: err instanceof gemini.GeminiError ? err.message : 'The client simulator failed. Try sending again.' });
    }
  } finally {
    clearInterval(heartbeat);
    res.end();
  }
});

app.post('/api/session/score', aiLimiter, auth.requireAuth, auth.sameOrigin, async (req, res) => {
  const b = req.body || {};
  const s = resolveSession(b, res);
  if (!s) return;
  const finalStatus = ['resolved', 'escalated', 'ended_by_agent'].includes(b.finalStatus) ? b.finalStatus : 'ended_by_agent';
  if (!s.history.some(m => m.role === 'agent')) return res.status(400).json({ error: 'Send at least one reply before ending the test.' });

  try {
    const data = await gemini.generateJson(
      catalog.scoringPrompt(s.mood, s.scenario, finalStatus, s.history),
      [{ role: 'user', parts: [{ text: 'Score this session now.' }] }],
      catalog.SCORE_SCHEMA
    );

    const report = {
      overall_score: Math.round(clamp(data.overall_score, 0, 100)),
      empathy: Math.round(clamp(data.empathy, 0, 100)),
      technical_accuracy: Math.round(clamp(data.technical_accuracy, 0, 100)),
      resolution: Math.round(clamp(data.resolution, 0, 100)),
      communication: Math.round(clamp(data.communication, 0, 100)),
      verdict: str(data.verdict, 600) || 'No verdict was produced.',
      strengths: Array.isArray(data.strengths) ? data.strengths.slice(0, 6).map(x => str(x, 300)).filter(Boolean) : [],
      improvements: Array.isArray(data.improvements) ? data.improvements.slice(0, 6).map(x => str(x, 300)).filter(Boolean) : []
    };

    const ticketId = /^SD-\d{5,6}$/.test(String(b.ticketId)) ? b.ticketId : 'SD-' + Math.floor(10000 + Math.random() * 89999);
    const saved = await db.createReport(req.user.sub, {
      ticketId, scenario: s.scenario.label, mood: s.mood.label, finalStatus,
      overallScore: report.overall_score, empathy: report.empathy, technicalAccuracy: report.technical_accuracy,
      resolution: report.resolution, communication: report.communication, verdict: report.verdict,
      strengths: report.strengths, improvements: report.improvements, transcript: s.history,
      durationSec: Number.isFinite(Number(b.durationSec)) ? Math.round(clamp(b.durationSec, 0, 86400)) : null
    });
    res.json({ ...report, reportId: saved.id, ticketId, finalStatus, created_at: saved.created_at });
  } catch (err) { fail(res, err, 'Could not generate your report.'); }
});

/* ------------------------------------------------------------------ */
/* Reports (own)                                                       */
/* ------------------------------------------------------------------ */

app.get('/api/reports', auth.requireAuth, async (req, res) => {
  try { res.json(await db.listReportSummariesByUser(req.user.sub)); }
  catch (err) { fail(res, err); }
});

app.get('/api/reports/:id', auth.requireAuth, async (req, res) => {
  try {
    const report = await loadReportForViewer(req, res);
    if (report) res.json(report);
  } catch (err) { fail(res, err); }
});

app.get('/api/reports/:id/download', auth.requireAuth, async (req, res) => {
  try {
    const r = await loadReportForViewer(req, res);
    if (!r) return;
    const outcome = { resolved: 'Resolved', escalated: 'Escalated', ended_by_agent: 'Ended by agent' }[r.final_status] || r.final_status;
    const lines = [
      'SERVICE DESK TRAINING REPORT', '============================', '',
      'Ticket:     ' + r.ticket_id, 'Scenario:   ' + r.scenario, 'Mood:       ' + r.mood, 'Outcome:    ' + outcome,
      'Date:       ' + new Date(r.created_at).toLocaleString(), '',
      'SCORES', '------',
      'Overall:              ' + r.overall_score, 'Empathy:              ' + r.empathy, 'Technical accuracy:   ' + r.technical_accuracy,
      'Resolution:           ' + r.resolution, 'Communication:        ' + r.communication, '',
      'Verdict: ' + r.verdict, '',
      'STRENGTHS', '---------', ...(r.strengths || []).map((s, i) => (i + 1) + '. ' + s), '',
      'IMPROVEMENTS', '------------', ...(r.improvements || []).map((s, i) => (i + 1) + '. ' + s), '',
      'TRANSCRIPT', '----------', ...(r.transcript || []).map(m => (m.role === 'agent' ? 'Agent: ' : 'Client: ') + m.text), ''
    ];
    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="' + r.ticket_id + '-report.txt"');
    res.send(lines.join('\n'));
  } catch (err) { fail(res, err); }
});

app.get('/api/reports/:id/download-excel', auth.requireAuth, async (req, res) => {
  try {
    const r = await loadReportForViewer(req, res);
    if (!r) return;
    const user = await db.findUserById(r.user_id);
    await sendXlsx(res, await excel.buildReportWorkbook(r, user), r.ticket_id + '-report.xlsx');
  } catch (err) { fail(res, err); }
});

/* ------------------------------------------------------------------ */
/* Admin                                                               */
/* ------------------------------------------------------------------ */

app.get('/api/admin/overview', auth.requireAdmin, async (req, res) => {
  try { res.json(await db.adminOverview()); } catch (err) { fail(res, err); }
});

app.get('/api/admin/reports', auth.requireAdmin, async (req, res) => {
  try { res.json(await db.listAllReportsWithUsers({ limit: 1000 })); } catch (err) { fail(res, err); }
});

app.get('/api/admin/reports/download-excel', auth.requireAdmin, async (req, res) => {
  try {
    const rows = await db.listAllReportsWithUsers({ limit: 5000 });
    await sendXlsx(res, await excel.buildAllSessionsWorkbook(rows), 'service-desk-sessions-' + new Date().toISOString().slice(0, 10) + '.xlsx');
  } catch (err) { fail(res, err); }
});

app.get('/api/admin/users', auth.requireAdmin, async (req, res) => {
  try { res.json(await db.listUsersWithStats()); } catch (err) { fail(res, err); }
});

app.get('/api/admin/users/:id/reports', auth.requireAdmin, async (req, res) => {
  try {
    const user = await db.findUserById(parseInt(req.params.id, 10));
    if (!user) return res.status(404).json({ error: 'User not found.' });
    res.json({ user, reports: await db.listReportSummariesByUser(user.id) });
  } catch (err) { fail(res, err); }
});

app.post('/api/admin/users/:id/reset-password', auth.requireAdmin, auth.sameOrigin, async (req, res) => {
  try {
    const { newPassword } = req.body || {};
    const pwErr = auth.passwordProblem(newPassword);
    if (pwErr) return res.status(400).json({ error: pwErr });
    const user = await db.findUserById(parseInt(req.params.id, 10));
    if (!user) return res.status(404).json({ error: 'User not found.' });
    await db.setUserPassword(user.id, await auth.hashPassword(newPassword));
    res.json({ ok: true });
  } catch (err) { fail(res, err); }
});

app.all('/api/*', (req, res) => res.status(404).json({ error: 'Not found.' }));

/* ------------------------------------------------------------------ */
/* Frontend                                                            */
/* ------------------------------------------------------------------ */

// Only /public is exposed. The old setup served the repo root, which made
// server.js, db.js and package.json publicly downloadable.
app.use(express.static(PUBLIC_DIR, { extensions: ['html'], index: 'index.html', maxAge: IS_PROD ? '1h' : 0 }));
app.use((req, res) => res.status(404).sendFile(path.join(PUBLIC_DIR, '404.html')));

/* ------------------------------------------------------------------ */
/* Start                                                               */
/* ------------------------------------------------------------------ */

if (require.main === module) {
  const PORT = process.env.PORT || 3000;
  db.initSchema()
    .then(() => console.log('[db] schema ready'))
    .catch(err => console.warn('[db] schema init failed (' + err.message + '). DB-backed routes will return 503 until it is reachable.'))
    .finally(() => app.listen(PORT, () => console.log('Service Desk Trainer running at http://localhost:' + PORT)));
}

module.exports = app;
