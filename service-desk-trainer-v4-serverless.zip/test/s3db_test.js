// Run: node test/s3db_test.js
// No AWS calls: a fake S3 backend enforces real conditional-write (ETag)
// semantics so the optimistic-concurrency logic in lib/s3db.js is genuinely
// exercised, including races between concurrent "Lambda invocations".
const path = require('path');
process.env.DATA_BUCKET = 'test-bucket';

let failures = 0;
const check = (label, cond, detail) => { console.log((cond ? 'PASS ' : 'FAIL ') + label + (detail ? '  -> ' + detail : '')); if (!cond) failures++; };

/* ---------------- fake S3 with real conditional-write semantics ---------------- */
function makeFakeS3() {
  const store = new Map(); // key -> { body, etag }
  let etagSeq = 0;
  const newEtag = () => '"etag-' + (++etagSeq) + '"';
  return {
    store,
    send: async (cmd) => {
      const name = cmd.constructor.name;
      const input = cmd.input;
      if (name === 'HeadBucketCommand') return {};
      if (name === 'GetObjectCommand') {
        const obj = store.get(input.Key);
        if (!obj) { const e = new Error('NoSuchKey'); e.name = 'NoSuchKey'; throw e; }
        return { ETag: obj.etag, Body: { transformToString: async () => obj.body } };
      }
      if (name === 'PutObjectCommand') {
        const existing = store.get(input.Key);
        if (input.IfNoneMatch === '*' && existing) { const e = new Error('PreconditionFailed'); e.name = 'PreconditionFailed'; throw e; }
        if (input.IfMatch && (!existing || existing.etag !== input.IfMatch)) { const e = new Error('PreconditionFailed'); e.name = 'PreconditionFailed'; throw e; }
        const etag = newEtag();
        store.set(input.Key, { body: input.Body, etag });
        return { ETag: etag };
      }
      if (name === 'DeleteObjectCommand') { store.delete(input.Key); return {}; }
      throw new Error('unhandled command ' + name);
    }
  };
}

(async () => {
  const s3db = require(path.join(__dirname, '..', 'lib', 's3db.js'));
  s3db._setClient(makeFakeS3());
  await s3db.initSchema();

  /* ---------------- basic user lifecycle ---------------- */
  const alice = await s3db.createUser({ name: 'Alice Agent', email: 'alice@example.com', sapId: 'SAP-1', passwordHash: 'h1', project: 'P', lob: 'L' });
  check('createUser assigns an incrementing id', Number.isInteger(alice.id));
  check('findUserByEmail is case-insensitive', (await s3db.findUserByEmail('ALICE@example.com')).id === alice.id);
  check('findUserBySapId finds the same row', (await s3db.findUserBySapId('SAP-1')).id === alice.id);
  check('new user starts unverified with session_epoch 1', alice.email_verified_at === null && alice.session_epoch === 1);

  let err = null;
  try { await s3db.createUser({ name: 'Dup', email: 'alice@example.com', sapId: 'SAP-2', passwordHash: 'h', project: '', lob: '' }); }
  catch (e) { err = e; }
  check('duplicate verified-path email is rejected', err && err.code === 'EMAIL_TAKEN', err && err.message);

  /* ---------------- password change bumps session epoch ---------------- */
  await s3db.setUserPassword(alice.id, 'h2');
  check('setUserPassword bumps session_epoch', (await s3db.getSessionEpoch(alice.id)) === 2);

  /* ---------------- account-squatting reclaim ---------------- */
  const squat = await s3db.createUser({ name: 'Squatter', email: 'victim@example.com', sapId: 'SAP-V1', passwordHash: 'hx', project: '', lob: '' });
  check('unverified squat account created', squat.email_verified_at === null);
  const reclaimed = await s3db.reclaimUnverifiedUser(squat.id, { name: 'Real Owner', sapId: 'SAP-V2', passwordHash: 'hy', project: 'P', lob: 'L' });
  check('reclaim overwrites an unverified row in place (same id)', reclaimed && reclaimed.id === squat.id && reclaimed.name === 'Real Owner');
  check('reclaim frees the old SAP id index and claims the new one', (await s3db.findUserBySapId('SAP-V1')) === null && (await s3db.findUserBySapId('SAP-V2')).id === squat.id);

  await s3db.markEmailVerified(squat.id);
  const blocked = await s3db.reclaimUnverifiedUser(squat.id, { name: 'Attacker', sapId: 'SAP-V3', passwordHash: 'hz', project: '', lob: '' });
  check('a verified account can never be reclaimed', blocked === null);

  /* ---------------- login lockout ---------------- */
  const bob = await s3db.createUser({ name: 'Bob', email: 'bob@example.com', sapId: 'SAP-B', passwordHash: 'h', project: '', lob: '' });
  for (let i = 0; i < 9; i++) await s3db.recordFailedLogin(bob.id);
  check('not locked before threshold', (await s3db.findUserById(bob.id)).locked_until === null);
  const tenth = await s3db.recordFailedLogin(bob.id);
  check('locked_until set at the 10th failure', tenth.failed_logins === 10 && tenth.locked_until !== null);
  await s3db.clearFailedLogins(bob.id);
  check('clearFailedLogins resets the lock', (await s3db.findUserById(bob.id)).locked_until === null);

  /* ---------------- OTP: attempts, lockout, timing-parity dummy ---------------- */
  const otpId = await s3db.createOtp(alice.id, 'login', 'correcthash', new Date(Date.now() + 600000));
  check('wrong code increments attempts, returns wrong', (await s3db.verifyOtp(otpId, alice.id, 'login', 'badhash')) === 'wrong');
  for (let i = 0; i < 4; i++) await s3db.verifyOtp(otpId, alice.id, 'login', 'badhash'); // 1 + 4 = 5 = OTP_MAX_ATTEMPTS
  check('locked after OTP_MAX_ATTEMPTS wrong guesses', (await s3db.verifyOtp(otpId, alice.id, 'login', 'correcthash')) === 'locked');
  const otp2 = await s3db.createOtp(alice.id, 'login', 'righthash', new Date(Date.now() + 600000));
  check('correct code succeeds on a fresh otp', (await s3db.verifyOtp(otp2, alice.id, 'login', 'righthash')) === 'ok');
  check('a used code cannot be replayed', (await s3db.verifyOtp(otp2, alice.id, 'login', 'righthash')) === 'expired');
  check('dummyVerifyOtp always returns wrong without throwing', (await s3db.dummyVerifyOtp()) === 'wrong');

  /* ---------------- pending signups (nothing under users/ until verified) ---------------- */
  await s3db.createPendingSignup('pid1', { name: 'Pending P', email: 'pending@example.com', sapId: 'SAP-P', project: '', lob: '', passwordHash: 'h', codeHash: 'right', expiresAt: new Date(Date.now() + 600000).toISOString() });
  check('pending signup does not create a user or reserve the email/SAP id', (await s3db.findUserByEmail('pending@example.com')) === null && (await s3db.findUserBySapId('SAP-P')) === null);
  check('pending signup is readable while unexpired', (await s3db.getPendingSignup('pid1')).email === 'pending@example.com');
  check('wrong code -> wrong', (await s3db.verifyPendingSignup('pid1', 'nope')).status === 'wrong');
  for (let i = 0; i < 4; i++) await s3db.verifyPendingSignup('pid1', 'nope');
  check('5 wrong codes -> locked, even with the right code', (await s3db.verifyPendingSignup('pid1', 'right')).status === 'locked');
  const refreshed = await s3db.refreshPendingSignup('pid1', 'right2', new Date(Date.now() + 600000));
  check('refresh issues a new code and resets attempts', refreshed && refreshed.attempts === 0 && refreshed.resends === 1);
  const okv = await s3db.verifyPendingSignup('pid1', 'right2');
  check('correct code -> ok with the stored record', okv.status === 'ok' && okv.record.sapId === 'SAP-P');
  await s3db.deletePendingSignup('pid1');
  check('deleted pending signup is gone', (await s3db.getPendingSignup('pid1')) === null);
  await s3db.createPendingSignup('pid2', { name: 'X', email: 'x@example.com', sapId: 'SAP-X2', project: '', lob: '', passwordHash: 'h', codeHash: 'c', expiresAt: new Date(Date.now() - 1000).toISOString() });
  check('expired pending signup reads as null and verifies as expired', (await s3db.getPendingSignup('pid2')) === null && (await s3db.verifyPendingSignup('pid2', 'c')).status === 'expired');
  for (let i = 0; i < 6; i++) await s3db.refreshPendingSignup('pid2', 'c', new Date(Date.now() + 600000));
  check('resend limit enforced', (await s3db.refreshPendingSignup('pid2', 'c', new Date(Date.now() + 600000))) === 'limit');

  /* ---------------- reports ---------------- */
  const r1 = await s3db.createReport(alice.id, { ticketId: 'SD-1', scenario: 'Network issue', mood: 'Furious', finalStatus: 'resolved', overallScore: 80, empathy: 70, technicalAccuracy: 85, resolution: 90, communication: 75, verdict: 'Good', strengths: ['a'], improvements: ['b'], transcript: [{ role: 'agent', text: 'hi' }], durationSec: 120, mode: 'chat' });
  const r2 = await s3db.createReport(alice.id, { ticketId: 'SD-2', scenario: 'App down', mood: 'Lost', finalStatus: 'escalated', overallScore: 40, empathy: 30, technicalAccuracy: 45, resolution: 20, communication: 50, verdict: 'Rough', strengths: [], improvements: ['c'], transcript: [], durationSec: 60, mode: 'voice' });
  const list = await s3db.listReportSummariesByUser(alice.id);
  check('own reports listed newest first', list.length === 2 && list[0].id === r2.id && list[1].id === r1.id);
  check('summary omits the transcript', list[0].transcript === undefined);
  const full = await s3db.getReportById(r1.id);
  check('full report keeps the transcript', Array.isArray(full.transcript) && full.transcript[0].text === 'hi');

  const allWithUsers = await s3db.listAllReportsWithUsers({});
  check('admin listing joins the owning agent', allWithUsers.find(r => r.id === r1.id).user_name === 'Alice Agent');

  const overview = await s3db.adminOverview();
  check('adminOverview totals', overview.total_reports === 2 && overview.active_agents === 1 && overview.resolved_count === 1);
  check('adminOverview picks the top agent', overview.top_agent && overview.top_agent.id === alice.id);

  const stats = await s3db.listUsersWithStats();
  const aliceStats = stats.find(u => u.id === alice.id);
  check('listUsersWithStats computes correct report_count and avg_score for role=user accounts', aliceStats.report_count === 2 && aliceStats.avg_score === 60, JSON.stringify(aliceStats));

  /* ---------------- concurrency: parallel signups must not clobber the id counter ---------------- */
  const parallel = await Promise.all(Array.from({ length: 12 }, (_, i) =>
    s3db.createUser({ name: 'Racer ' + i, email: 'racer' + i + '@example.com', sapId: 'SAP-R' + i, passwordHash: 'h', project: '', lob: '' })
  ));
  const ids = parallel.map(u => u.id);
  check('12 concurrent signups all got unique ids', new Set(ids).size === 12, ids.join(','));
  const idxAfter = await s3db._internal.getJson('index/user-ids.json');
  check('user-ids index contains all racers exactly once (no lost updates)', ids.every(id => idxAfter.value.ids.filter(x => x === id).length === 1));

  /* ---------------- concurrency: parallel reports for the same user must not lose any ---------------- */
  const alice2 = parallel[0]; // reuse racer 0 as a second reporter to avoid interfering with alice's own list assertions above
  await Promise.all(Array.from({ length: 8 }, (_, i) =>
    s3db.createReport(alice2.id, { ticketId: 'SD-R' + i, scenario: 'Network issue', mood: 'Lost', finalStatus: 'resolved', overallScore: 50, empathy: 50, technicalAccuracy: 50, resolution: 50, communication: 50, verdict: 'x', strengths: [], improvements: [], transcript: [], durationSec: 10, mode: 'chat' })
  ));
  const alice2Reports = await s3db.listReportSummariesByUser(alice2.id);
  check('8 concurrent report creations for one user all land (no lost updates)', alice2Reports.length === 8, alice2Reports.length);

  console.log(failures ? '\n' + failures + ' FAILURE(S)' : '\nALL S3DB TESTS PASS');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
