// Run: node test/bedrock_voice_test.js
// No network: injects fake SDK clients into lib/bedrock and lib/voice.
process.env.AWS_BEARER_TOKEN_BEDROCK = 'test-key';
const path = require('path');
const bedrock = require(path.join(__dirname, '..', 'lib', 'bedrock.js'));
const voice = require(path.join(__dirname, '..', 'lib', 'voice.js'));
const catalog = require(path.join(__dirname, '..', 'lib', 'catalog.js'));

let failures = 0;
const check = (label, cond, detail) => { console.log((cond ? 'PASS ' : 'FAIL ') + label + (detail ? '  -> ' + detail : '')); if (!cond) failures++; };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));

(async () => {
  /* ---------------- bedrock.js ---------------- */

  check('schema types lowercased and propertyOrdering dropped',
    JSON.stringify(bedrock.toJsonSchema(catalog.TURN_SCHEMA)) === JSON.stringify({ type: 'object', properties: { reply: { type: 'string' }, satisfaction: { type: 'number' }, status: { type: 'string', enum: ['ongoing', 'resolved', 'escalated'] } }, required: ['reply', 'satisfaction', 'status'] }));

  const msgs = bedrock.toMessages(catalog.clientContents([{ role: 'agent', text: 'Hi' }, { role: 'client', text: 'Broken' }, { role: 'agent', text: 'Sorry' }, { role: 'agent', text: 'Again' }]));
  check('messages alternate and merge consecutive same-role parts', msgs.map(m => m.role).join(',') === 'user,user,assistant,user' || msgs.map(m => m.role).join(',') === 'user,assistant,user', msgs.map(m => m.role + ':' + m.content.length).join(' '));

  // Streaming: tool input arrives as JSON fragments across awkward boundaries.
  const frags = ['{"reply": "This is the th', 'ird time this week.\\nJust fix ', 'it.", "satisfaction": 15, "sta', 'tus": "ongoing"}'];
  let captured = null;
  bedrock._setClient({
    send: async (cmd) => {
      captured = cmd.input;
      async function* stream() {
        yield { messageStart: { role: 'assistant' } };
        yield { contentBlockStart: { start: { toolUse: { toolUseId: 't1', name: 'turn' } } } };
        for (const f of frags) { await sleep(1); yield { contentBlockDelta: { delta: { toolUse: { input: f } } } }; }
        yield { contentBlockStop: {} };
        yield { messageStop: { stopReason: 'tool_use' } };
      }
      return { stream: stream() };
    }
  });
  const partials = [];
  const turn = await bedrock.streamJson('sys', catalog.clientContents([]), catalog.TURN_SCHEMA, p => partials.push(p), undefined, { toolName: 'turn' });
  check('streamJson parses final object', turn.satisfaction === 15 && turn.status === 'ongoing' && turn.reply === 'This is the third time this week.\nJust fix it.', JSON.stringify(turn));
  check('streamJson emitted growing partials ending at the full reply', partials.length >= 2 && partials[partials.length - 1] === turn.reply, partials.length + ' partials');
  check('request forces the named tool', captured.toolConfig.toolChoice.tool.name === 'turn' && captured.toolConfig.tools[0].toolSpec.name === 'turn');
  check('request carries system prompt + model id', captured.system[0].text === 'sys' && captured.modelId === bedrock.MODEL);

  // Non-streaming scoring via tool use.
  bedrock._setClient({ send: async () => ({ output: { message: { content: [{ toolUse: { toolUseId: 't2', name: 'score', input: { overall_score: 81, verdict: 'ok' } } }] } } }) });
  const scored = await bedrock.generateJson('sys', [{ role: 'user', parts: [{ text: 'x' }] }], catalog.SCORE_SCHEMA, { toolName: 'score' });
  check('generateJson returns tool input', scored.overall_score === 81, JSON.stringify(scored));

  // Error mapping never leaks internals.
  bedrock._setClient({ send: async () => { throw Object.assign(new Error('Rate exceeded, arn:aws:... secret stuff'), { name: 'ThrottlingException' }); } });
  try { await bedrock.generateJson('s', [], catalog.SCORE_SCHEMA); check('throttling mapped', false); }
  catch (e) { check('throttling -> 429 with safe message', e.status === 429 && !/arn:aws/.test(e.message), e.message); }
  bedrock._setClient({ send: async () => { throw Object.assign(new Error('The security token included in the request is invalid'), { name: 'UnrecognizedClientException' }); } });
  try { await bedrock.generateJson('s', [], catalog.SCORE_SCHEMA); check('bad key mapped', false); }
  catch (e) { check('bad credentials -> 503 misconfigured', e.status === 503, e.message); }

  /* ---------------- voice.js ---------------- */

  // Fake Nova Sonic: records inbound events, emits a scripted response stream.
  const inbound = [];
  const outEvents = [
    { event: { completionStart: { promptName: 'p' } } },
    { event: { contentStart: { contentName: 'u1', role: 'USER', type: 'TEXT' } } },
    { event: { textOutput: { contentName: 'u1', role: 'USER', content: 'Hello, service desk, how can I help?' } } },
    { event: { contentEnd: { contentName: 'u1', type: 'TEXT', stopReason: 'END_TURN' } } },
    { event: { contentStart: { contentName: 'a1', role: 'ASSISTANT', type: 'TEXT', additionalModelFields: '{"generationStage":"SPECULATIVE"}' } } },
    { event: { textOutput: { contentName: 'a1', role: 'ASSISTANT', content: 'My internet keeps' } } },
    { event: { contentEnd: { contentName: 'a1', type: 'TEXT', stopReason: 'PARTIAL_TURN' } } },
    { event: { contentStart: { contentName: 'a2', role: 'ASSISTANT', type: 'AUDIO' } } },
    { event: { audioOutput: { contentName: 'a2', content: Buffer.from([1, 2, 3, 4]).toString('base64') } } },
    { event: { contentEnd: { contentName: 'a2', type: 'AUDIO', stopReason: 'END_TURN' } } },
    { event: { contentStart: { contentName: 'a3', role: 'ASSISTANT', type: 'TEXT', additionalModelFields: '{"generationStage":"FINAL"}' } } },
    { event: { textOutput: { contentName: 'a3', role: 'ASSISTANT', content: 'My internet keeps dropping and I have a demo in ten minutes.' } } },
    { event: { contentEnd: { contentName: 'a3', type: 'TEXT', stopReason: 'END_TURN' } } },
    { event: { contentStart: { contentName: 'a4', role: 'ASSISTANT', type: 'AUDIO' } } },
    { event: { contentEnd: { contentName: 'a4', type: 'AUDIO', stopReason: 'INTERRUPTED' } } },
    { event: { usageEvent: { totalTokens: 123 } } }
  ];
  let release;
  const gate = new Promise(r => { release = r; });
  voice._setClient({
    send: async (cmd) => {
      // Drain what the session queued before the stream opened.
      (async () => { for await (const c of cmd.input.body) inbound.push(JSON.parse(Buffer.from(c.chunk.bytes).toString())); })();
      async function* body() { for (const e of outEvents) { await sleep(1); yield { chunk: { bytes: Buffer.from(JSON.stringify(e)) } }; } await gate; }
      return { body: body() };
    }
  });

  const got = [];
  const session = new voice.VoiceSession({ systemPrompt: catalog.voiceSystemPrompt(catalog.findMood('furious'), catalog.findScenario('network')), moodId: 'furious', onEvent: (t, d) => got.push([t, d]) });
  await session.start();
  session.sendAudio(Buffer.alloc(320));
  // Wait for the scripted stream to fully deliver (its last event is 'usage'),
  // rather than a fixed delay - Windows' setTimeout granularity can round a
  // 1ms sleep up to ~15ms, so 16 sequential awaited sleeps can take well over
  // 80ms there even though the same test finishes in a few ms on Linux/macOS.
  for (let waited = 0; waited < 2000 && !got.some(g => g[0] === 'usage'); waited += 20) await sleep(20);

  const types = got.map(g => g[0]);
  check('voice session emits ready', types[0] === 'ready' && got[0][1].voiceId === 'matthew', types.slice(0, 3).join(','));
  const agentT = got.filter(g => g[0] === 'transcript' && g[1].role === 'agent');
  const clientT = got.filter(g => g[0] === 'transcript' && g[1].role === 'client');
  check('USER text -> agent transcript (final)', agentT.length === 1 && agentT[0][1].final && /service desk/.test(agentT[0][1].text));
  check('ASSISTANT speculative then FINAL -> client transcript with final flags', clientT.length === 2 && clientT[0][1].final === false && clientT[1][1].final === true, JSON.stringify(clientT.map(c => c[1].final)));
  check('audio decoded to PCM bytes', got.some(g => g[0] === 'audio' && Buffer.isBuffer(g[1].pcm) && g[1].pcm.length === 4));
  check('INTERRUPTED -> interrupted event', types.includes('interrupted'));
  check('END_TURN audio -> turn_end', types.includes('turn_end'));
  check('usage relayed', types.includes('usage'));

  const kinds = inbound.map(e => Object.keys(e.event)[0]);
  check('inbound protocol order: sessionStart, promptStart, system text, audio contentStart',
    kinds.slice(0, 6).join(',') === 'sessionStart,promptStart,contentStart,textInput,contentEnd,contentStart', kinds.slice(0, 7).join(','));
  const sysEv = inbound.find(e => e.event.contentStart && e.event.contentStart.role === 'SYSTEM');
  const audEv = inbound.find(e => e.event.contentStart && e.event.contentStart.type === 'AUDIO');
  check('system block is TEXT/SYSTEM, audio block is 16kHz lpcm', sysEv && audEv && audEv.event.contentStart.audioInputConfiguration.sampleRateHertz === 16000 && audEv.event.contentStart.audioInputConfiguration.mediaType === 'audio/lpcm');
  check('promptStart requests 24kHz speech with the mood voice', inbound[1].event.promptStart.audioOutputConfiguration.sampleRateHertz === 24000 && inbound[1].event.promptStart.audioOutputConfiguration.voiceId === 'matthew');
  check('audio chunk forwarded as base64 audioInput', inbound.some(e => e.event.audioInput && e.event.audioInput.content === Buffer.alloc(320).toString('base64')));
  check('system prompt has no JSON instructions', !/JSON/.test(sysEv.event.textInput ? '' : '') && !/JSON/.test(inbound.find(e => e.event.textInput).event.textInput.content));

  session.close('hangup');
  release();
  await sleep(20);
  const tail = inbound.slice(-3).map(e => Object.keys(e.event)[0]);
  check('hang-up sends contentEnd, promptEnd, sessionEnd', tail.join(',') === 'contentEnd,promptEnd,sessionEnd', tail.join(','));
  check('closed event emitted once', got.filter(g => g[0] === 'closed').length === 1);
  session.sendAudio(Buffer.alloc(10));
  check('audio after close is dropped', !inbound.slice(-1)[0].event.audioInput);

  console.log(failures ? '\n' + failures + ' FAILURE(S)' : '\nALL BEDROCK/VOICE TESTS PASS');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
