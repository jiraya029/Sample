// voice-server.js
// The one piece that is not serverless: an always-on Node process holding a
// WebSocket per live call and a bidirectional Bedrock stream behind it.
// Runs as a single small Fargate task (see infra/template.yaml). It shares
// lib/voiceGateway.js and lib/s3db.js with the Lambda API, and authenticates
// callers with the 60-second token the API issues at GET /api/voice/token.
require('dotenv').config();
const http = require('http');
const db = require('./lib/s3db');
const auth = require('./auth');
const { attachVoiceGateway } = require('./lib/voiceGateway');
const voice = require('./lib/voice');

const PORT = process.env.PORT || 8080;
let gateway = null;

const server = http.createServer((req, res) => {
  if (req.url === '/health') {
    res.setHeader('Content-Type', 'application/json');
    return res.end(JSON.stringify({ ok: true, voiceModel: voice.MODEL, activeCalls: gateway ? gateway.activeCalls() : 0 }));
  }
  res.statusCode = 404; res.end('Not found');
});
gateway = attachVoiceGateway(server, { db, auth });
server.listen(PORT, () => console.log('Voice service on :' + PORT + ' (model ' + voice.MODEL + ')'));
