document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, banner, busy, toast, escapeHtml, setFieldError, icon } = SDT;
  const user = await requireAuth();
  if (!user) return;

  // An unfinished session from a refresh/navigation? Offer to resume.
  try {
    const saved = JSON.parse(sessionStorage.getItem('sdt_session') || 'null');
    if (saved && !saved.ended && Array.isArray(saved.history) && saved.history.length) {
      const b = el('div', 'banner info');
      b.innerHTML = icon('info') + '<div>You have an open ticket <span class="mono">' + escapeHtml(saved.ticketId) + '</span> (' + escapeHtml(saved.scenarioLabel) + '). ' +
        '<a href="' + (saved.mode === 'voice' ? '/voice' : '/chat') + '">Resume it</a> or <button type="button" class="link-btn" id="discard-session">discard it</button>.</div>';
      $('#resume-slot').appendChild(b);
      $('#discard-session').addEventListener('click', () => { sessionStorage.removeItem('sdt_session'); b.remove(); toast.info('Ticket discarded'); });
    }
  } catch (e) { /* ignore */ }

  const moodSel = $('#mood-select'), scenSel = $('#scenario-select'), startBtn = $('#start-btn');

  // Mode picker (chat / voice). Voice is only offered when the server reports it configured.
  let mode = 'chat';
  const modeGrid = $('#mode-grid');
  const setMode = (m) => {
    mode = m;
    modeGrid.querySelectorAll('.option').forEach(o => o.setAttribute('aria-checked', String(o.dataset.mode === m)));
    $('#mode-picked').textContent = m === 'voice' ? 'Voice call' : 'Chat';
    $('#mode-hint').textContent = m === 'voice' ? 'You will need a microphone. The call is scored on the same scale as a chat.' : '';
    startBtn.textContent = m === 'voice' ? 'Start the call' : 'Open the ticket';
  };
  modeGrid.addEventListener('click', (e) => { const o = e.target.closest('.option'); if (o && !o.disabled) setMode(o.dataset.mode); });
  api('/api/health').then(h => {
    if (!h.voice) { const v = $('#mode-voice'); v.disabled = true; v.querySelector('small').textContent = 'Not available: voice is not configured on this server.'; }
    if (!navigator.mediaDevices || !window.AudioWorkletNode) { const v = $('#mode-voice'); v.disabled = true; v.querySelector('small').textContent = 'Your browser does not support live audio capture.'; }
  }).catch(() => {});
  let catalog;
  try { catalog = await api('/api/catalog'); }
  catch (err) { banner('#setup-banner', 'error', 'Could not load the scenario list: ' + err.message); return; }

  const fill = (sel, items, placeholder, label) => {
    sel.innerHTML = '';
    const ph = el('option', null, placeholder); ph.value = ''; ph.disabled = true; ph.selected = true; sel.appendChild(ph);
    items.forEach(it => { const o = el('option', null, label(it)); o.value = it.id; sel.appendChild(o); });
    sel.disabled = false;
  };
  fill(moodSel, catalog.moods, 'Choose a mood', m => m.label + (m.desc ? ' - ' + m.desc : ''));
  fill(scenSel, catalog.scenarios, 'Choose a scenario', s => s.label);

  const refresh = () => {
    startBtn.disabled = !(moodSel.value && scenSel.value);
    const m = catalog.moods.find(x => x.id === moodSel.value);
    $('#mood-hint').textContent = m ? 'Starts at ' + m.start + '/100 satisfaction. ' + (m.start < 30 ? 'Expect a rough opening.' : m.start < 40 ? 'Guarded, but workable.' : 'Cooperative if you are clear.') : 'How the client feels when they open the chat.';
    setFieldError(moodSel, ''); setFieldError(scenSel, '');
  };
  moodSel.addEventListener('change', refresh); scenSel.addEventListener('change', refresh);

  startBtn.addEventListener('click', () => {
    let bad = false;
    if (!moodSel.value) { setFieldError(moodSel, "Pick the client's mood."); bad = true; }
    if (!scenSel.value) { setFieldError(scenSel, 'Pick what the issue is.'); bad = true; }
    if (bad) return;
    const mood = catalog.moods.find(m => m.id === moodSel.value), scenario = catalog.scenarios.find(s => s.id === scenSel.value);
    sessionStorage.setItem('sdt_session', JSON.stringify({
      ticketId: 'SD-' + Math.floor(10000 + Math.random() * 89999),
      moodId: mood.id, scenarioId: scenario.id, moodLabel: mood.label, moodTone: mood.tone, scenarioLabel: scenario.label,
      satisfaction: mood.start, history: [], startedAt: Date.now(), ended: false, mode
    }));
    busy(startBtn, true);
    window.location.href = mode === 'voice' ? '/voice' : '/chat';
  });
});
