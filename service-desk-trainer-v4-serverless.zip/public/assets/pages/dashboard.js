document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, toast, skeleton, unskeleton, setStatSkeleton, renderTrend, reportRowHtml, makeSortable, fmtDate, escapeHtml, icon } = SDT;
  $('#dl-txt').href = SDT.apiUrl('/api/reports/download');
  $('#dl-xlsx').href = SDT.apiUrl('/api/reports/download-excel');
  const user = await requireAuth();
  if (!user) return;
  $('#dash-welcome').textContent = 'Welcome, ' + user.name.split(' ')[0];
  $('#search-icon').outerHTML = icon('search');
  if (user.activeSession) {
    const dc = $('#device-card');
    dc.innerHTML = icon('user') + '<div class="device-text">Signed in on <strong>' + escapeHtml(user.activeSession.device) +
      '</strong> since ' + escapeHtml(new Date(user.activeSession.loginAt).toLocaleString()) +
      '. Only one device can be signed in at a time - signing in elsewhere will end this session here.</div>';
    dc.hidden = false;
  }

  setStatSkeleton(true); skeleton('#trend', 'block'); skeleton('#cat-list', 'lines', 4); skeleton('#history', 'rows', 5);

  let reports = [];
  try { reports = await api('/api/reports'); }
  catch (err) { toast.error('Could not load your sessions', err.message); }
  reports.forEach(r => { r.overall_score = Number(r.overall_score); ['empathy', 'technical_accuracy', 'resolution', 'communication'].forEach(k => { r[k] = Number(r[k]); }); });

  /* ---- stats ---- */
  setStatSkeleton(false);
  const total = reports.length;
  $('#stat-count').textContent = total;
  const last7 = reports.filter(r => Date.now() - new Date(r.created_at) < 7 * 864e5).length;
  $('#stat-count-sub').textContent = total ? last7 + ' in the last 7 days' : 'No sessions yet';
  if (total) {
    const avg = (arr) => Math.round(arr.reduce((s, r) => s + r.overall_score, 0) / arr.length);
    const overall = avg(reports);
    $('#stat-avg').textContent = overall;
    // Compare the most recent five with the five before them.
    if (total >= 6) {
      const recent = avg(reports.slice(0, 5)), prior = avg(reports.slice(5, 10));
      const d = recent - prior;
      const sub = $('#stat-avg-sub'); sub.textContent = (d > 0 ? '+' : '') + d + ' vs previous 5 sessions'; sub.className = 'stat-sub ' + (d > 0 ? 'up' : d < 0 ? 'down' : '');
    } else $('#stat-avg-sub').textContent = 'Across ' + total + ' session' + (total === 1 ? '' : 's');

    const cats = { empathy: 'Empathy', technical_accuracy: 'Technical accuracy', resolution: 'Resolution', communication: 'Communication' };
    const catAvg = Object.keys(cats).map(k => ({ k, v: Math.round(reports.reduce((s, r) => s + r[k], 0) / total) })).sort((a, b) => b.v - a.v);
    $('#stat-best').textContent = cats[catAvg[0].k]; $('#stat-best').classList.add('is-text');
    $('#stat-best-sub').textContent = 'avg ' + catAvg[0].v + ' \u00b7 weakest: ' + cats[catAvg[catAvg.length - 1].k] + ' (' + catAvg[catAvg.length - 1].v + ')';
    const resolved = reports.filter(r => r.final_status === 'resolved').length;
    $('#stat-resolved').textContent = Math.round(resolved / total * 100) + '%';
    $('#stat-resolved-sub').textContent = resolved + ' of ' + total + ' tickets resolved';

    // Category bars
    const list = $('#cat-list'); list.innerHTML = ''; unskeleton(list);
    Object.keys(cats).forEach(k => {
      const v = catAvg.find(c => c.k === k).v;
      const row = el('div', 'cat-row');
      row.innerHTML = '<div class="cat-row-top"><span>' + cats[k] + '</span><span class="val">' + v + '</span></div><div class="bar-track"><div class="bar-fill" role="progressbar" aria-valuenow="' + v + '" aria-valuemin="0" aria-valuemax="100" aria-label="' + cats[k] + '"></div></div>';
      list.appendChild(row);
      requestAnimationFrame(() => requestAnimationFrame(() => { row.querySelector('.bar-fill').style.width = v + '%'; }));
    });
  } else {
    ['#stat-avg', '#stat-best', '#stat-resolved'].forEach(s => { $(s).textContent = '-'; });
    $('#cat-list').innerHTML = '<div class="empty"><strong>Nothing to show yet</strong>Category averages appear after your first session.</div>';
  }

  /* ---- trend ---- */
  renderTrend('#trend', reports.slice(0, 20).reverse().map(r => ({ x: fmtDate(r.created_at, { month: 'short', day: 'numeric' }), y: Math.round(r.overall_score), meta: r.scenario })));

  /* ---- history ---- */
  const histWrap = $('#history');
  const q = $('#q'), fOut = $('#f-outcome'), fRange = $('#f-range'), fMode = $('#f-mode');
  let sorter = null;

  function filtered() {
    const term = q.value.trim().toLowerCase(), out = fOut.value, days = Number(fRange.value);
    return reports.filter(r =>
      (!term || (r.ticket_id + ' ' + r.scenario + ' ' + r.mood).toLowerCase().includes(term)) &&
      (!out || r.final_status === out) &&
      (!days || Date.now() - new Date(r.created_at) < days * 864e5));
  }
  function renderRows(rows) {
    const tbody = histWrap.querySelector('tbody');
    if (!tbody) return;
    if (!rows.length) { tbody.innerHTML = '<tr><td colspan="7"><div class="empty"><strong>No matching sessions</strong>Try a different search or clear the filters.</div></td></tr>'; return; }
    tbody.innerHTML = rows.map(r => '<tr>' + reportRowHtml(r, { context: 'dashboard' }) + '</tr>').join('');
  }
  function draw() {
    const rows = filtered();
    $('#count').textContent = rows.length === reports.length ? reports.length + ' session' + (reports.length === 1 ? '' : 's') : rows.length + ' of ' + reports.length;
    if (sorter) sorter.redraw(rows); else renderRows(rows);
  }

  unskeleton(histWrap);
  if (!reports.length) {
    histWrap.innerHTML = '<div class="empty"><strong>No sessions recorded yet</strong>Start a ticket to see your history here.</div>';
    $('#count').textContent = '';
  } else {
    histWrap.innerHTML = '<div class="table-wrap"><table class="table"><thead><tr>' +
      '<th class="sortable" data-key="ticket_id">Ticket <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="scenario">Scenario <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="mood">Mood <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="overall_score">Score <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="final_status">Outcome <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="created_at">When <span class="sort-ind"></span></th>' +
      '<th><span class="visually-hidden">Actions</span></th></tr></thead><tbody></tbody></table></div>';
    sorter = makeSortable(histWrap.querySelector('table'), reports, renderRows, 'created_at', 'desc');
    draw();
  }
  let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(draw, 120); });
  fOut.addEventListener('change', draw); fRange.addEventListener('change', draw); fMode.addEventListener('change', draw);
});
