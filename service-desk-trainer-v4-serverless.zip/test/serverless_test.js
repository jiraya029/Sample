// Run: node test/serverless_test.js
// Exercises the deployed shape without AWS: the real lambda/handler.js is
// invoked with API Gateway HTTP API (payload v2.0) events; S3 and Bedrock are
// fakes with real semantics (ETag conditional writes, tool-use streaming).
process.env.DATA_BUCKET = 'test-bucket';
process.env.JWT_SECRET = 'test-secret-that-is-long-enough';
process.env.FRONTEND_ORIGIN = 'https://d111.cloudfront.net';
process.env.VOICE_WS_URL = 'wss://voice.test/ws/voice';
process.env.AWS_LAMBDA_FUNCTION_NAME = 'sdt-api'; // makes /api/health report ai:true
const path = require('path');

let failures = 0;
const check = (label, cond, detail) => { console.log((cond ? 'PASS ' : 'FAIL ') + label + (detail ? '  -> ' + detail : '')); if (!cond) failures++; };

/* ---------------- fakes ---------------- */
function makeFakeS3() {
  const store = new Map(); let seq = 0;
  return { store, send: async (cmd) => {
    const n = cmd.constructor.name, i = cmd.input;
    if (n === 'HeadBucketCommand') return {};
    if (n === 'GetObjectCommand') { const o = store.get(i.Key); if (!o) { const e = new Error('NoSuchKey'); e.name = 'NoSuchKey'; throw e; } return { ETag: o.etag, Body: { transformToString: async () => o.body } }; }
    if (n === 'PutObjectCommand') {
      const ex = store.get(i.Key);
      if ((i.IfNoneMatch === '*' && ex) || (i.IfMatch && (!ex || ex.etag !== i.IfMatch))) { const e = new Error('PreconditionFailed'); e.name = 'PreconditionFailed'; throw e; }
      const etag = '"e' + (++seq) + '"'; store.set(i.Key, { body: i.Body, etag }); return { ETag: etag };
    }
    if (n === 'DeleteObjectCommand') { store.delete(i.Key); return {}; }
    throw new Error('unhandled ' + n);
  } };
}
const s3db = require(path.join(__dirname, '..', 'lib', 's3db.js'));
s3db._setClient(makeFakeS3());

const bedrock = require(path.join(__dirname, '..', 'lib', 'bedrock.js'));
bedrock._setClient({ send: async (cmd) => {
  const name = cmd.input.toolConfig.toolChoice.tool.name;
  const input = name === 'turn' ? { reply: 'My laptop will not boot and I have a client call in ten minutes.', satisfaction: 28, status: 'ongoing' }
    : name === 'gauge' ? { satisfaction: 41, status: 'ongoing' }
    : { overall_score: 77, empathy: 80, technical_accuracy: 70, resolution: 75, communication: 82, verdict: 'Calm and clear; confirm the fix sooner.', strengths: ['Acknowledged the deadline immediately'], improvements: ['Confirm the fix before closing'] };
  return { output: { message: { content: [{ toolUse: { toolUseId: 't', name, input } }] } } };
} });

const voiceLib = require(path.join(__dirname, '..', 'lib', 'voice.js'));
voiceLib._setClient({ send: async (cmd) => {
  (async () => { for await (const c of cmd.input.body) { /* drain */ } })();
  async function* body() {
    const ev = (e) => ({ chunk: { bytes: Buffer.from(JSON.stringify({ event: e })) } });
    await new Promise(r => setTimeout(r, 5));
    yield ev({ contentStart: { contentName: 'a1', role: 'ASSISTANT', type: 'TEXT', additionalModelFields: '{"generationStage":"FINAL"}' } });
    yield ev({ textOutput: { contentName: 'a1', role: 'ASSISTANT', content: 'Hi, my laptop is dead.' } });
    yield ev({ contentEnd: { contentName: 'a1', type: 'TEXT', stopReason: 'END_TURN' } });
    await new Promise(r => setTimeout(r, 4000));
  }
  return { body: body() };
} });

/* ---------------- Lambda invoker ---------------- */
const { handler } = require(path.join(__dirname, '..', 'lambda', 'handler.js'));
let cookieJar = [];
function jarHeader() { return cookieJar.map(c => c.split(';')[0]).join('; '); }
function absorb(res) { (res.cookies || []).forEach(c => { const name = c.split('=')[0]; cookieJar = cookieJar.filter(x => !x.startsWith(name + '=')); if (!/Max-Age=0|Expires=Thu, 01 Jan 1970/.test(c)) cookieJar.push(c); }); }

async function invoke(method, rawPath, body, extra) {
  const headers = Object.assign({ host: 'api.test', origin: process.env.FRONTEND_ORIGIN, 'content-type': 'application/json' }, extra || {});
  if (cookieJar.length && !('cookie' in headers)) headers.cookie = jarHeader();
  const event = {
    version: '2.0', routeKey: 'ANY /{proxy+}', rawPath, rawQueryString: '', headers,
    requestContext: { http: { method, path: rawPath, sourceIp: '203.0.113.9', userAgent: 'test' }, domainName: 'api.test', stage: '$default', requestId: 'r' + Math.random() },
    body: body == null ? undefined : (typeof body === 'string' ? body : JSON.stringify(body)), isBase64Encoded: false
  };
  const res = await handler(event, { awsRequestId: 'x' });
  absorb(res);
  let json = null; try { json = JSON.parse(res.body); } catch (e) { /* not json */ }
  return { status: res.statusCode, headers: res.headers, cookies: res.cookies || [], json, body: res.body, isBase64Encoded: res.isBase64Encoded };
}

(async () => {
  // health + CORS
  let r = await invoke('GET', '/api/health');
  check('health via Lambda -> 200, storage s3, serverless', r.status === 200 && r.json.storage === 's3' && r.json.serverless === true, JSON.stringify(r.json));
  check('CORS echoes the allowed origin with credentials', r.headers['access-control-allow-origin'] === process.env.FRONTEND_ORIGIN && r.headers['access-control-allow-credentials'] === 'true');
  r = await invoke('GET', '/api/health', null, { origin: 'https://evil.example' });
  check('CORS does not echo an unknown origin', !r.headers['access-control-allow-origin']);
  r = await invoke('OPTIONS', '/api/auth/login');
  check('preflight -> 204 with methods', r.status === 204 && /POST/.test(r.headers['access-control-allow-methods'] || ''));

  // signup -> otp -> cookies
  r = await invoke('POST', '/api/auth/signup', { name: 'Priya Nair', email: 'priya@example.com', sapId: 'SAP-9', project: 'Helios', lob: 'Infra', password: 'agentpass1', confirmPassword: 'agentpass1' });
  check('signup -> 201 otpRequired + challenge (no cookie yet)', r.status === 201 && r.json.otpRequired && r.json.challenge && r.cookies.length === 0, r.status);
  const devCode = r.json.devCode;
  check('dev mode returns the code (no SMTP configured)', /^\d{6}$/.test(devCode || ''), devCode);
  r = await invoke('POST', '/api/auth/verify', { challenge: r.json.challenge, code: devCode, trustDevice: true });
  check('verify -> 200 user + TWO cookies via API Gateway cookies[] (session + device)', r.status === 200 && r.json.email === 'priya@example.com' && r.cookies.length === 2, r.cookies.map(c => c.split('=')[0]).join(','));
  check('cross-origin cookies are SameSite=None; Secure; HttpOnly', r.cookies.every(c => /SameSite=None/i.test(c) && /Secure/.test(c) && /HttpOnly/.test(c)), r.cookies[0]);

  // trusted device skips OTP on next login
  r = await invoke('POST', '/api/auth/login', { email: 'priya@example.com', password: 'agentpass1' });
  check('login on trusted device -> straight to session (no otpRequired)', r.status === 200 && !r.json.otpRequired && r.json.id, JSON.stringify(r.json).slice(0, 80));

  // me + catalog
  r = await invoke('GET', '/api/me');
  check('/api/me with cookie -> user', r.status === 200 && r.json.name === 'Priya Nair');
  r = await invoke('GET', '/api/catalog');
  check('catalog lists moods/scenarios, hides personas', r.json.moods.length === 6 && !JSON.stringify(r.json).includes('persona'));

  // chat turn: plain JSON now, not SSE
  r = await invoke('POST', '/api/session/turn', { moodId: 'furious', scenarioId: 'hardware', history: [] });
  check('chat turn -> single JSON object (no SSE through API Gateway)', r.status === 200 && /application\/json/.test(r.headers['content-type']) && r.json.reply && r.json.satisfaction === 28 && r.json.status === 'ongoing', r.headers['content-type']);
  r = await invoke('POST', '/api/session/turn', { moodId: 'nope', scenarioId: 'hardware', history: [] });
  check('unknown mood -> 400', r.status === 400);
  r = await invoke('POST', '/api/session/turn', { moodId: 'furious', scenarioId: 'hardware', history: [] }, { origin: 'https://evil.example' });
  check('cross-origin POST with cookie but bad Origin -> 403', r.status === 403);

  // score -> report persisted in S3 -> list/get/excel
  const history = [{ role: 'client', text: 'My laptop will not boot.' }, { role: 'agent', text: 'Let us get you a loaner within the hour and image your drive.' }];
  r = await invoke('POST', '/api/session/score', { moodId: 'furious', scenarioId: 'hardware', ticketId: 'SD-12345', finalStatus: 'resolved', history, durationSec: 240, mode: 'chat' });
  check('score -> saved report with id', r.status === 200 && r.json.reportId && r.json.overall_score === 77, r.status);
  const reportId = r.json.reportId;
  r = await invoke('GET', '/api/reports');
  check('list own reports from S3 (summary, no transcript)', r.status === 200 && r.json.length === 1 && r.json[0].id === reportId && r.json[0].transcript === undefined);
  r = await invoke('GET', '/api/reports/' + reportId);
  check('full report keeps transcript + mode', r.json.transcript.length === 2 && r.json.mode === 'chat');
  r = await invoke('GET', '/api/reports/' + reportId + '/download-excel');
  check('Excel download is base64-encoded binary via API Gateway', r.status === 200 && r.isBase64Encoded === true && Buffer.from(r.body, 'base64').slice(0, 2).toString() === 'PK', r.isBase64Encoded);
  r = await invoke('GET', '/api/reports/999');
  check('missing report -> 404', r.status === 404);

  // voice token
  r = await invoke('GET', '/api/voice/token');
  check('voice token issued with URL', r.status === 200 && r.json.token && r.json.url === process.env.VOICE_WS_URL);
  const voiceToken = r.json.token;

  // admin: promote via S3 directly (no API for that, by design), then overview
  const priya = await s3db.findUserByEmail('priya@example.com');
  await s3db._internal.withRmw('users/by-id/' + priya.id + '.json', (u) => ({ ...u, role: 'admin' }));
  cookieJar = []; // old session token has role=user baked in; log in again
  r = await invoke('POST', '/api/auth/login', { email: 'priya@example.com', password: 'agentpass1' });
  r = await invoke('POST', '/api/auth/verify', { challenge: r.json.challenge, code: r.json.devCode });
  check('verify without trustDevice -> exactly ONE cookie, still delivered via cookies[] (single Set-Cookie normalised)', r.status === 200 && r.cookies.length === 1 && /^sdt_token=/.test(r.cookies[0]) && !r.headers['set-cookie'], r.cookies.length);
  r = await invoke('GET', '/api/admin/overview');
  check('admin overview computed from S3 objects', r.status === 200 && r.json.total_reports === 1 && r.json.active_agents === 1, JSON.stringify(r.json).slice(0, 100));
  r = await invoke('GET', '/api/admin/reports');
  check('admin sessions list joins the agent', r.json[0].user_name === 'Priya Nair');
  r = await invoke('GET', '/api/admin/users/abc/reports');
  check('admin route rejects non-numeric id -> 400', r.status === 400);

  // no-cookie access
  cookieJar = [];
  r = await invoke('GET', '/api/reports');
  check('no cookie -> 401', r.status === 401);

  /* ---------------- voice service over a real WebSocket ---------------- */
  const http = require('http');
  const WebSocket = require('ws');
  const auth = require(path.join(__dirname, '..', 'auth.js'));
  const { attachVoiceGateway } = require(path.join(__dirname, '..', 'lib', 'voiceGateway.js'));
  const server = http.createServer((q, s) => { s.end('ok'); });
  attachVoiceGateway(server, { db: s3db, auth });
  await new Promise(r => server.listen(4102, r));

  const tryWs = (url, headers) => new Promise((resolve) => {
    const s = new WebSocket(url, { headers }); const msgs = [];
    s.on('unexpected-response', (req, res) => resolve({ status: res.statusCode }));
    s.on('error', () => resolve({ status: 'err', msgs }));
    s.on('open', () => s.send(JSON.stringify({ type: 'start', moodId: 'furious', scenarioId: 'hardware' })));
    s.on('message', (d, bin) => { if (!bin) { const m = JSON.parse(d.toString()); msgs.push(m); if (m.type === 'transcript') { s.send(JSON.stringify({ type: 'end' })); } if (m.type === 'ended') { s.close(); resolve({ status: 101, msgs }); } } });
    setTimeout(() => resolve({ status: 'timeout', msgs }), 5000);
  });
  const fresh = auth.signVoiceToken({ sub: priya.id, role: 'admin', name: 'Priya Nair', ep: priya.session_epoch });
  let w = await tryWs('ws://localhost:4102/ws/voice?token=' + fresh, { Origin: process.env.FRONTEND_ORIGIN });
  check('voice: allowed cross-origin + valid token -> call runs to "ended"', w.status === 101 && w.msgs.some(m => m.type === 'ready') && w.msgs.some(m => m.type === 'ended'), w.status + ' ' + (w.msgs || []).map(m => m.type).join(','));
  w = await tryWs('ws://localhost:4102/ws/voice', { Origin: process.env.FRONTEND_ORIGIN });
  check('voice: no token, no cookie -> 401', w.status === 401, w.status);
  w = await tryWs('ws://localhost:4102/ws/voice?token=' + fresh, { Origin: 'https://evil.example' });
  check('voice: origin not in allow-list -> 403', w.status === 403, w.status);
  const sessionTok = auth.issueToken({ id: priya.id, role: 'admin', name: 'Priya', session_epoch: 1 });
  w = await tryWs('ws://localhost:4102/ws/voice?token=' + sessionTok, { Origin: process.env.FRONTEND_ORIGIN });
  check('voice: a session cookie token is not accepted as a voice token', w.status === 401, w.status);
  server.close();

  console.log(failures ? '\n' + failures + ' FAILURE(S)' : '\nALL SERVERLESS TESTS PASS');
  process.exit(failures ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
