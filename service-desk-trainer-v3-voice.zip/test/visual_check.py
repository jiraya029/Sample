"""Renders every page against a mocked API and saves screenshots.
Run the server first:  PORT=4100 node server.js
Then:                  python3 test/visual_check.py
"""
import json, random, datetime, sys
from playwright.sync_api import sync_playwright

BASE = "http://localhost:4100"
OUT = sys.argv[1] if len(sys.argv) > 1 else "/tmp/shots"
import os; os.makedirs(OUT, exist_ok=True)

random.seed(7)
scen = ["Network issue", "App down", "Access / password request", "Email / mailbox issue", "Database issue", "Printer / peripheral issue"]
moods = ["Furious", "Worried", "Lost", "In a rush", "Doubtful", "On edge"]
outs = ["resolved", "resolved", "escalated", "ended_by_agent", "resolved"]
now = datetime.datetime.utcnow()
reports = []
for i in range(14):
    base = 48 + i * 2.5 + random.randint(-8, 8)
    reports.append({
        "id": 100 + i, "user_id": 1, "ticket_id": f"SD-{random.randint(10000, 99999)}", "scenario": random.choice(scen), "mood": random.choice(moods),
        "final_status": random.choice(outs), "overall_score": str(max(20, min(96, round(base)))), "empathy": str(random.randint(40, 95)),
        "technical_accuracy": str(random.randint(40, 95)), "resolution": str(random.randint(30, 95)), "communication": str(random.randint(45, 95)),
        "verdict": "Handled the client's frustration well but took too long to confirm the fix.", "duration_sec": random.randint(180, 900),
        "created_at": (now - datetime.timedelta(days=(13 - i) * 2, hours=random.randint(0, 9))).isoformat() + "Z",
    })
reports.sort(key=lambda r: r["created_at"], reverse=True)
full = dict(reports[0], strengths=["Acknowledged the client's deadline in the first reply.", "Gave a clear time estimate before starting the fix.", "Confirmed the fix with the client before closing."],
            improvements=["Asked the client to repeat the error message twice.", "Used 'DNS propagation' without explaining it."],
            transcript=[{"role": "client", "text": "My internet keeps dropping every few minutes and I have a demo in ten. Can someone actually fix this?"},
                        {"role": "agent", "text": "I'm sorry, that's the worst timing. Let's get you stable before your demo. Are you on Wi-Fi or a cable right now?"},
                        {"role": "client", "text": "Wi-Fi. It's been like this since this morning."},
                        {"role": "agent", "text": "Thanks. Please plug in the cable on your desk if you have one; that takes Wi-Fi out of the equation immediately. I'll open a ticket with network in parallel."}])
user = {"id": 1, "name": "Priya Nair", "email": "priya.nair@example.com", "sap_id": "10482913", "project": "Helios", "lob": "Infrastructure Services", "role": "user"}
admin = dict(user, role="admin", name="Marcus Bell")
agents = [{"id": i + 1, "name": n, "email": n.lower().replace(" ", ".") + "@example.com", "sap_id": str(10480000 + i), "project": random.choice(["Helios", "Atlas", "Nimbus"]), "lob": "Infrastructure Services",
           "report_count": random.randint(0, 12), "avg_score": random.randint(50, 90), "last_session_at": (now - datetime.timedelta(days=random.randint(0, 20))).isoformat() + "Z"}
          for i, n in enumerate(["Priya Nair", "Tom Okafor", "Lena Fischer", "Daniel Reyes", "Aisha Khan"])]
admin_reports = [dict(r, user_id=(k % 5) + 1, user_name=agents[k % 5]["name"], user_email=agents[k % 5]["email"]) for k, r in enumerate(reports)]
overview = {"total_reports": 63, "active_agents": 5, "avg_score": 68, "reports_7d": 9, "resolved_count": 41,
            "top_agent": {"id": 3, "name": "Lena Fischer", "avg_score": 84, "report_count": 11},
            "trend": [{"day": (now - datetime.timedelta(days=d)).date().isoformat(), "avg_score": random.randint(55, 85), "sessions": random.randint(1, 5)} for d in range(20, -1, -2)]}

SSE = ("event: partial\ndata: {\"reply\": \"Wi-Fi. It's been like this since this\"}\n\n")  # leave it mid-stream for the screenshot

def mock(page, who):
    def handle(route, request):
        p = request.url.replace(BASE, "").split("?")[0]
        j = lambda body, status=200: route.fulfill(status=status, content_type="application/json", body=json.dumps(body))
        if p == "/api/me": return j(who) if who else j({"error": "Not signed in."}, 401)
        if p == "/api/reports": return j(reports)
        if p.startswith("/api/reports/"): return j(full)
        if p == "/api/admin/overview": return j(overview)
        if p == "/api/admin/reports": return j(admin_reports)
        if p == "/api/admin/users": return j(agents)
        if p == "/api/session/turn": return route.fulfill(status=200, content_type="text/event-stream", body=SSE)
        if p == "/api/auth/login": return j({"otpRequired": True, "challenge": "x", "email": "pr******@example.com", "ttlMin": 10, "devCode": "482913"})
        return route.continue_()
    page.route(f"{BASE}/api/**", handle)

errors = []
with sync_playwright() as pw:
    b = pw.chromium.launch()
    for theme in ["default", "dark"]:
        for width in [1280, 390]:
            ctx = b.new_context(viewport={"width": width, "height": 860}, device_scale_factor=1)
            if theme != "default": ctx.add_init_script(f"localStorage.setItem('sdt_theme','{theme}')")
            page = ctx.new_page()
            page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e: errors.append(str(e)))
            shots = [("login", None, "/login"), ("dashboard", user, "/dashboard"), ("setup", user, "/setup"), ("report", user, "/report?id=100&fresh=1"), ("admin", admin, "/admin"), ("404", None, "/does-not-exist")]
            for name, who, url in shots:
                page.unroute(f"{BASE}/api/**")
                mock(page, who)
                page.goto(BASE + url, wait_until="networkidle")
                page.wait_for_timeout(1200)
                page.screenshot(path=f"{OUT}/{name}_{theme}_{width}.png", full_page=(name != "login"))
            # chat: needs a session in sessionStorage
            mock(page, user)
            page.goto(BASE + "/setup", wait_until="networkidle")
            page.evaluate("""() => sessionStorage.setItem('sdt_session', JSON.stringify({ticketId:'SD-48213', moodId:'furious', scenarioId:'network', moodLabel:'Furious', moodTone:'red', scenarioLabel:'Network issue', satisfaction:22, startedAt: Date.now()-214000, ended:false,
                history:[{role:'client', text:"My internet keeps dropping every few minutes and I have a demo in ten. Can someone actually fix this?"},{role:'agent', text:"I'm sorry, that's the worst timing. Let's get you stable before your demo. Are you on Wi-Fi or a cable right now?"}]}))""")
            page.goto(BASE + "/chat", wait_until="networkidle")
            page.fill("#agent-input", "Got it. Please plug in the cable on your desk if you have one.")
            page.click("#send-btn")
            page.wait_for_timeout(700)
            page.screenshot(path=f"{OUT}/chat_{theme}_{width}.png", full_page=False)
            if width == 1280 and theme == "default":
                page.click("#end-btn"); page.wait_for_timeout(400)
                page.screenshot(path=f"{OUT}/chat_modal_{theme}_{width}.png")
                page.keyboard.press("Escape")
                page.unroute(f"{BASE}/api/**"); mock(page, None)
                page.goto(BASE + "/login#signup", wait_until="networkidle")
                page.fill("#su-email", "not-an-email"); page.fill("#su-password", "abc"); page.locator("#su-password").blur(); page.locator("#su-email").blur()
                page.wait_for_timeout(300)
                page.screenshot(path=f"{OUT}/signup_validation_{theme}_{width}.png")
                page.goto(BASE + "/login", wait_until="networkidle")
                page.fill("#login-email", "priya.nair@example.com"); page.fill("#login-password", "Secret123")
                page.click("#login-btn"); page.wait_for_timeout(500)
                page.screenshot(path=f"{OUT}/otp_{theme}_{width}.png")
                page.unroute(f"{BASE}/api/**"); mock(page, user)
                page.goto(BASE + "/setup", wait_until="networkidle")
                page.select_option("#mood-select", "furious"); page.select_option("#scenario-select", "network"); page.wait_for_timeout(300)
                page.screenshot(path=f"{OUT}/setup_selected_{theme}_{width}.png")
            ctx.close()
    b.close()

print("screenshots in", OUT)
print("console errors:", len(errors))
for e in errors[:20]: print("  -", e[:200])
