document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, toast, modal, skeleton, unskeleton, setStatSkeleton, renderTrend, reportRowHtml, makeSortable, fmtDate, fmtRelative, escapeHtml, icon, initials, validators, setFieldError, bindPasswordToggle } = SDT;
  const user = await requireAuth({ admin: true });
  if (!user) return;
  $('#ic-dl').outerHTML = icon('download'); $('#ic-search').outerHTML = icon('search'); $('#ic-search2').outerHTML = icon('search');

  setStatSkeleton(true); skeleton('#trend', 'block'); skeleton('#sessions', 'rows', 6); skeleton('#agents', 'rows', 4);

  let overview = null, sessions = [], agents = [];
  const results = await Promise.allSettled([api('/api/admin/overview'), api('/api/admin/reports'), api('/api/admin/users')]);
  if (results[0].status === 'fulfilled') overview = results[0].value; else toast.error('Could not load overview', results[0].reason.message);
  if (results[1].status === 'fulfilled') sessions = results[1].value; else toast.error('Could not load sessions', results[1].reason.message);
  if (results[2].status === 'fulfilled') agents = results[2].value; else toast.error('Could not load agents', results[2].reason.message);
  sessions.forEach(r => { r.overall_score = Number(r.overall_score); });

  /* ---- stats ---- */
  setStatSkeleton(false);
  if (overview) {
    $('#s-total').textContent = overview.total_reports;
    $('#s-total-sub').textContent = overview.reports_7d + ' in the last 7 days';
    $('#s-agents').textContent = overview.active_agents;
    $('#s-agents-sub').textContent = agents.length + ' registered';
    $('#s-avg').textContent = overview.total_reports ? overview.avg_score : '-';
    $('#s-avg-sub').textContent = overview.total_reports ? Math.round(overview.resolved_count / overview.total_reports * 100) + '% resolved' : 'No sessions yet';
    if (overview.top_agent) { $('#s-top').textContent = overview.top_agent.name.split(' ')[0]; $('#s-top-sub').textContent = 'avg ' + overview.top_agent.avg_score + ' over ' + overview.top_agent.report_count + ' session' + (overview.top_agent.report_count === 1 ? '' : 's'); }
    else { $('#s-top').textContent = '-'; }
    renderTrend('#trend', (overview.trend || []).map(t => ({ x: fmtDate(t.day, { month: 'short', day: 'numeric' }), y: Number(t.avg_score), meta: t.sessions + ' session' + (t.sessions === 1 ? '' : 's') })), { label: 'Daily average score' });
  }

  /* ---- tabs ---- */
  const showTab = (which) => {
    ['sessions', 'agents'].forEach(k => { $('#pane-' + k).hidden = k !== which; $('#tab-' + k).setAttribute('aria-selected', String(k === which)); });
  };
  $('#tab-sessions').addEventListener('click', () => showTab('sessions'));
  $('#tab-agents').addEventListener('click', () => showTab('agents'));

  /* ---- sessions table ---- */
  const q = $('#q'), fOut = $('#f-outcome');
  let agentFilter = null, sorter = null;
  const sessWrap = $('#sessions');
  const filtered = () => {
    const term = q.value.trim().toLowerCase(), out = fOut.value;
    return sessions.filter(r => (!agentFilter || r.user_id === agentFilter.id) && (!out || r.final_status === out) &&
      (!term || (r.user_name + ' ' + r.user_email + ' ' + r.ticket_id + ' ' + r.scenario + ' ' + r.mood).toLowerCase().includes(term)));
  };
  const renderRows = (rows) => {
    const tb = sessWrap.querySelector('tbody'); if (!tb) return;
    tb.innerHTML = rows.length ? rows.map(r => '<tr>' + reportRowHtml(r, { agentCell: true, context: 'admin' }) + '</tr>').join('') : '<tr><td colspan="8"><div class="empty"><strong>No matching sessions</strong>Try a different search or clear the filters.</div></td></tr>';
  };
  const drawSessions = () => {
    const rows = filtered();
    $('#count').textContent = rows.length === sessions.length ? sessions.length + ' sessions' : rows.length + ' of ' + sessions.length;
    const chip = $('#agent-chip');
    chip.innerHTML = agentFilter ? '<span class="filter-chip">' + escapeHtml(agentFilter.name) + '<button type="button" aria-label="Clear agent filter">' + icon('x') + '</button></span>' : '';
    if (agentFilter) chip.querySelector('button').addEventListener('click', () => { agentFilter = null; drawSessions(); });
    if (sorter) sorter.redraw(rows); else renderRows(rows);
  };
  unskeleton(sessWrap);
  if (!sessions.length) sessWrap.innerHTML = '<div class="empty"><strong>No sessions recorded yet</strong>Sessions appear here as agents complete tickets.</div>';
  else {
    sessWrap.innerHTML = '<div class="table-wrap"><table class="table wide"><thead><tr>' +
      '<th class="sortable" data-key="user_name">Agent <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="ticket_id">Ticket <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="scenario">Scenario <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="mood">Mood <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="overall_score">Score <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="final_status">Outcome <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="created_at">When <span class="sort-ind"></span></th>' +
      '<th><span class="visually-hidden">Actions</span></th></tr></thead><tbody></tbody></table></div>';
    sorter = makeSortable(sessWrap.querySelector('table'), sessions, renderRows, 'created_at', 'desc');
    drawSessions();
  }
  let t; q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(drawSessions, 120); });
  fOut.addEventListener('change', drawSessions);

  /* ---- agents table ---- */
  const q2 = $('#q2'), agWrap = $('#agents');
  let agentSorter = null;
  agents.forEach(a => { a.avg_score = Number(a.avg_score); a.report_count = Number(a.report_count); a.last_ts = a.last_session_at ? new Date(a.last_session_at).getTime() : 0; });
  const agentsFiltered = () => { const term = q2.value.trim().toLowerCase(); return agents.filter(a => !term || (a.name + ' ' + a.email + ' ' + a.sap_id + ' ' + (a.project || '') + ' ' + (a.lob || '')).toLowerCase().includes(term)); };
  const renderAgentRows = (rows) => {
    const tb = agWrap.querySelector('tbody'); if (!tb) return;
    if (!rows.length) { tb.innerHTML = '<tr><td colspan="7"><div class="empty"><strong>No matching agents</strong></div></td></tr>'; return; }
    tb.innerHTML = rows.map(a => '<tr data-id="' + a.id + '">' +
      '<td><div class="cell-user"><span class="avatar">' + escapeHtml(initials(a.name)) + '</span><div><div>' + escapeHtml(a.name) + '</div><div class="sub">' + escapeHtml(a.email) + '</div></div></div></td>' +
      '<td class="mono">' + escapeHtml(a.sap_id) + '</td>' +
      '<td>' + escapeHtml(a.project || '-') + '<div class="sub muted" style="font-size:12px">' + escapeHtml(a.lob || '') + '</div></td>' +
      '<td>' + a.report_count + '</td>' +
      '<td>' + (a.report_count ? SDT.scoreChip(a.avg_score) : '<span class="muted">-</span>') + '</td>' +
      '<td>' + (a.last_session_at ? escapeHtml(fmtRelative(a.last_session_at)) : '<span class="muted">Never</span>') + '</td>' +
      '<td class="actions"><button class="btn btn-sm" data-act="sessions">Sessions</button><button class="btn btn-sm btn-ghost" data-act="reset">' + icon('key') + ' Reset password</button></td></tr>').join('');
    tb.querySelectorAll('[data-act]').forEach(b => b.addEventListener('click', () => {
      const a = agents.find(x => x.id === Number(b.closest('tr').dataset.id));
      if (b.dataset.act === 'sessions') { agentFilter = a; q.value = ''; fOut.value = ''; drawSessions(); showTab('sessions'); $('#tab-sessions').focus(); }
      else resetPassword(a);
    }));
  };
  const drawAgents = () => { const rows = agentsFiltered(); $('#count2').textContent = rows.length + ' agent' + (rows.length === 1 ? '' : 's'); if (agentSorter) agentSorter.redraw(rows); else renderAgentRows(rows); };
  unskeleton(agWrap);
  if (!agents.length) agWrap.innerHTML = '<div class="empty"><strong>No agents registered yet</strong></div>';
  else {
    agWrap.innerHTML = '<div class="table-wrap"><table class="table"><thead><tr>' +
      '<th class="sortable" data-key="name">Agent <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="sap_id">SAP ID <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="project">Project / LOB <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="report_count">Sessions <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="avg_score">Avg <span class="sort-ind"></span></th>' +
      '<th class="sortable" data-key="last_ts">Last active <span class="sort-ind"></span></th>' +
      '<th><span class="visually-hidden">Actions</span></th></tr></thead><tbody></tbody></table></div>';
    agentSorter = makeSortable(agWrap.querySelector('table'), agents, renderAgentRows, 'last_ts', 'desc');
    drawAgents();
  }
  let t2; q2.addEventListener('input', () => { clearTimeout(t2); t2 = setTimeout(drawAgents, 120); });

  /* ---- reset password modal ---- */
  async function resetPassword(a) {
    const done = await modal({
      title: 'Reset password for ' + a.name, body: 'Set a temporary password and share it with the agent securely. They can change it afterwards via "Forgot password".',
      confirmText: 'Set password',
      render: (body) => {
        body.innerHTML = '<div class="field"><label class="label" for="np">New temporary password</label><div class="input-wrap"><input class="input" id="np" type="password" autocomplete="new-password" placeholder="Enter a temporary password"><button type="button" class="input-affix" id="np-toggle"></button></div><div class="field-error" aria-live="polite"></div></div>';
        bindPasswordToggle(body.querySelector('#np-toggle'), body.querySelector('#np'));
        return { focus: body.querySelector('#np'), input: body.querySelector('#np') };
      },
      onConfirm: async ({ input }) => {
        const err = validators.password(input.value);
        if (err) { setFieldError(input, err); input.focus(); return false; }
        await api('/api/admin/users/' + a.id + '/reset-password', { method: 'POST', body: { newPassword: input.value } });
        return true;
      }
    });
    if (done) toast.success('Password reset', a.name + ' can sign in with the new password.');
  }
});
