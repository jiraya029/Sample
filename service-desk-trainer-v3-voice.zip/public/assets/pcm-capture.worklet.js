/* Microphone capture processor. Runs on the audio thread.
   Takes the context's native sample rate, downsamples to 16 kHz mono, converts
   to 16-bit PCM and posts ~100 ms frames (1600 samples) to the main thread. */
class PcmCaptureProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.target = 16000;
    this.ratio = sampleRate / this.target;
    this.acc = [];
    this.pos = 0;
    this.frameSize = 1600;
    this.out = new Int16Array(this.frameSize);
    this.outLen = 0;
    this.muted = false;
    this.port.onmessage = (e) => { if (e.data && e.data.type === 'mute') this.muted = Boolean(e.data.value); };
  }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0];
    if (!ch) return true;
    // Linear-interpolation downsample.
    let i = this.pos;
    while (i < ch.length) {
      const idx = Math.floor(i), frac = i - idx;
      const a = ch[idx], b = idx + 1 < ch.length ? ch[idx + 1] : a;
      let s = a + (b - a) * frac;
      if (this.muted) s = 0;
      s = Math.max(-1, Math.min(1, s));
      this.out[this.outLen++] = s < 0 ? s * 0x8000 : s * 0x7FFF;
      if (this.outLen === this.frameSize) {
        this.port.postMessage(this.out.buffer.slice(0));
        this.outLen = 0;
      }
      i += this.ratio;
    }
    this.pos = i - ch.length;
    return true;
  }
}
registerProcessor('pcm-capture', PcmCaptureProcessor);
