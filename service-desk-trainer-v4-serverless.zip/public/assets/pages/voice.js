document.addEventListener('DOMContentLoaded', async () => {
  const { $, el, api, requireAuth, toast, modal, busy, escapeHtml } = SDT;
  const user = await requireAuth();
  if (!user) return;

  let session = null;
  try { session = JSON.parse(sessionStorage.getItem('sdt_session') || 'null'); } catch (e) { session = null; }
  if (!session || !session.moodId || !session.scenarioId || session.mode !== 'voice') { window.location.replace('/setup'); return; }
  if (session.ended) { window.location.replace('/dashboard'); return; }
  const save = () => sessionStorage.setItem('sdt_session', JSON.stringify(session));

  const thread = $('#thread'), startBtn = $('#start-call-btn'), muteBtn = $('#mute-btn'), endBtn = $('#end-call-btn');
  const connState = $('#conn-state');

  /* ---- header ---- */
  $('#ticket-id').textContent = session.ticketId;
  $('#ticket-scenario').textContent = session.scenarioLabel;
  $('#ticket-mood').textContent = session.moodLabel + ' client';
  document.documentElement.style.setProperty('--mood-color', 'var(--' + (session.moodTone === 'accent' ? 'accent' : (session.moodTone || 'muted')) + ')');
  document.title = session.ticketId + ' call · Service Desk Trainer';

  /* ---- gauge ---- */
  const ARC = 251.3;
  function updateGauge(v) {
    v = Math.max(0, Math.min(100, Number(v) || 0));
    $('#gauge-needle').style.transform = 'rotate(' + (-90 + (v / 100) * 180) + 'deg)';
    $('#gauge-fg').setAttribute('stroke-dashoffset', (ARC - (v / 100) * ARC).toFixed(1));
    const [color, label] = v < 30 ? ['var(--red)', 'Critical'] : v < 55 ? ['var(--amber)', 'Tense'] : v < 80 ? ['var(--accent)', 'Cooling'] : ['var(--green)', 'Satisfied'];
    $('#gauge-fg').setAttribute('stroke', color);
    $('#gauge-state').textContent = label + ' \u00b7 ' + Math.round(v);
    $('#gauge-state').style.color = color;
  }
  updateGauge(session.satisfaction);

  /* ---- transcript ---- */
  const scrollDown = () => { thread.scrollTop = thread.scrollHeight; };
  const systemLine = (text, cls) => { const s = el('div', 'system-line' + (cls ? ' ' + cls : ''), text); thread.appendChild(s); scrollDown(); return s; };
  let liveClientBubble = null; // speculative text being spoken right now
  function addTranscript(role, text, final) {
    if (role === 'client') {
      if (!final) {
        if (!liveClientBubble) { liveClientBubble = bubble('client', text); liveClientBubble.classList.add('streaming'); }
        else liveClientBubble.textContent = text;
        scrollDown(); return;
      }
      if (liveClientBubble) { liveClientBubble.classList.remove('streaming'); liveClientBubble.textContent = text; liveClientBubble = null; }
      else bubble('client', text);
      return;
    }
    bubble('agent', text);
  }
  function bubble(role, text) {
    const wrap = el('div', 'bubble-wrap ' + role);
    wrap.appendChild(el('div', 'bubble-sender', role === 'agent' ? user.name : 'Client'));
    const b = el('div', 'bubble ' + role, text); wrap.appendChild(b);
    thread.appendChild(wrap); scrollDown();
    return b;
  }

  /* ---- timer ---- */
  let startedAt = null, timer = null;
  const tick = () => { if (!startedAt) return; const s = Math.floor((Date.now() - startedAt) / 1000); $('#timer').textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };

  /* ---- audio: capture ---- */
  let ctx = null, micStream = null, workletNode = null, analyser = null, levelRaf = null, muted = false;
  async function startMic(onFrame) {
    micStream = await navigator.mediaDevices.getUserMedia({ audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
    ctx = ctx || new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') await ctx.resume();
    await ctx.audioWorklet.addModule('/assets/pcm-capture.worklet.js');
    const src = ctx.createMediaStreamSource(micStream);
    workletNode = new AudioWorkletNode(ctx, 'pcm-capture');
    workletNode.port.onmessage = (e) => onFrame(e.data);
    analyser = ctx.createAnalyser(); analyser.fftSize = 512;
    src.connect(analyser); src.connect(workletNode);
    // The worklet has no output; keep it alive through a silent gain node.
    const sink = ctx.createGain(); sink.gain.value = 0; workletNode.connect(sink); sink.connect(ctx.destination);
    const buf = new Uint8Array(analyser.frequencyBinCount);
    const meter = () => { analyser.getByteTimeDomainData(buf); let peak = 0; for (let i = 0; i < buf.length; i++) peak = Math.max(peak, Math.abs(buf[i] - 128)); $('#level-fill').style.width = Math.min(100, (peak / 128) * 160) + '%'; levelRaf = requestAnimationFrame(meter); };
    meter();
  }
  function stopMic() {
    cancelAnimationFrame(levelRaf);
    if (workletNode) { try { workletNode.disconnect(); } catch (e) { /* ignore */ } workletNode = null; }
    if (micStream) { micStream.getTracks().forEach(t => t.stop()); micStream = null; }
    $('#level-fill').style.width = '0%';
  }

  /* ---- audio: playback (24 kHz PCM16, gapless queue) ---- */
  let playHead = 0; const scheduled = new Set();
  function playPcm(arrayBuffer) {
    if (!ctx) return;
    const i16 = new Int16Array(arrayBuffer);
    if (!i16.length) return;
    const f32 = new Float32Array(i16.length);
    for (let i = 0; i < i16.length; i++) f32[i] = i16[i] / 32768;
    const buffer = ctx.createBuffer(1, f32.length, 24000);
    buffer.copyToChannel(f32, 0);
    const src = ctx.createBufferSource(); src.buffer = buffer; src.connect(ctx.destination);
    const now = ctx.currentTime;
    if (playHead < now + 0.02) playHead = now + 0.02; // small lead-in to avoid clicks
    src.start(playHead); playHead += buffer.duration;
    scheduled.add(src); src.onended = () => scheduled.delete(src);
    $('#speaking-hint').textContent = 'Client is speaking...';
    clearTimeout(playPcm._t); playPcm._t = setTimeout(() => { $('#speaking-hint').textContent = 'Your turn.'; }, (playHead - now) * 1000 + 100);
  }
  function flushPlayback() {
    scheduled.forEach(s => { try { s.stop(); } catch (e) { /* ignore */ } }); scheduled.clear();
    playHead = 0; $('#speaking-hint').textContent = 'Your turn.';
  }

  /* ---- websocket ---- */
  let ws = null, ending = false, lastStatus = 'ongoing';
  async function connect() {
    // The voice relay is a separate always-on service (different origin), so the
    // API hands us a 60-second token and the URL instead of relying on the cookie.
    connState.textContent = 'Connecting';
    let target;
    try {
      const t = await api('/api/voice/token');
      target = t.url.replace(/\/$/, '') + '?token=' + encodeURIComponent(t.token);
    } catch (err) {
      connState.textContent = 'Error'; connState.style.color = 'var(--red)';
      systemLine(err.message, 'error'); stopMic();
      startBtn.hidden = false; muteBtn.hidden = true; endBtn.hidden = true;
      return;
    }
    ws = new WebSocket(target);
    ws.binaryType = 'arraybuffer';
    ws.onopen = () => { ws.send(JSON.stringify({ type: 'start', moodId: session.moodId, scenarioId: session.scenarioId })); };
    ws.onmessage = (e) => {
      if (e.data instanceof ArrayBuffer) return playPcm(e.data);
      let msg; try { msg = JSON.parse(e.data); } catch (err) { return; }
      if (msg.type === 'ready') {
        connState.textContent = 'Live'; connState.style.color = 'var(--green)';
        $('#voice-id').textContent = 'Voice: ' + msg.voiceId;
        $('#intro-line').textContent = 'Connected. The client is on the line.';
        startedAt = Date.now(); session.startedAt = startedAt; save(); tick(); timer = setInterval(tick, 1000);
        return;
      }
      if (msg.type === 'transcript') return addTranscript(msg.role, msg.text, msg.final);
      if (msg.type === 'interrupted') return flushPlayback();
      if (msg.type === 'satisfaction') {
        updateGauge(msg.value); session.satisfaction = msg.value; save();
        if (msg.status !== 'ongoing' && lastStatus === 'ongoing') {
          lastStatus = msg.status;
          systemLine(msg.status === 'resolved' ? 'Client sounds satisfied and is wrapping up. End the call when you are ready to get your report.' : 'Client wants to escalate. End the call to get your report.');
        }
        return;
      }
      if (msg.type === 'ended') return onEnded(msg);
      if (msg.type === 'error') { systemLine(msg.error, 'error'); toast.error('Call problem', msg.error); }
    };
    ws.onerror = () => { connState.textContent = 'Error'; connState.style.color = 'var(--red)'; };
    ws.onclose = (ev) => {
      connState.textContent = ending ? 'Ended' : 'Disconnected'; connState.style.color = ending ? '' : 'var(--amber)';
      stopMic(); clearInterval(timer);
      if (!ending && ev.code !== 1000) {
        systemLine(ev.code === 4001 ? 'This call was replaced by a newer call from another tab.' : 'Connection dropped. You can end the call to score what was said so far.', 'error');
        endBtn.hidden = false; muteBtn.hidden = true; startBtn.hidden = true;
      }
    };
  }

  /* ---- controls ---- */
  startBtn.addEventListener('click', async () => {
    busy(startBtn, true);
    try {
      await startMic((frame) => { if (ws && ws.readyState === WebSocket.OPEN && !ending) ws.send(frame); });
    } catch (err) {
      busy(startBtn, false);
      const denied = err && (err.name === 'NotAllowedError' || err.name === 'SecurityError');
      systemLine(denied ? 'Microphone access was blocked. Allow the microphone for this site and try again.' : 'Could not start the microphone: ' + (err.message || err.name), 'error');
      return;
    }
    busy(startBtn, false); startBtn.hidden = true; muteBtn.hidden = false; endBtn.hidden = false;
    await connect();
  });

  muteBtn.addEventListener('click', () => {
    muted = !muted;
    if (workletNode) workletNode.port.postMessage({ type: 'mute', value: muted });
    muteBtn.textContent = muted ? 'Unmute microphone' : 'Mute microphone';
    muteBtn.setAttribute('aria-pressed', String(muted));
  });

  let history = [], durationSec = 0;
  endBtn.addEventListener('click', async () => {
    if (ending) return;
    const ok = await modal({ title: 'End the call?', body: 'Your report will be generated from the call transcript. You cannot rejoin this call afterwards.', confirmText: 'End and score', danger: true });
    if (!ok) return;
    ending = true; busy(endBtn, true); muteBtn.disabled = true;
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'end' }));
      // If the server never answers, score with what we have.
      setTimeout(() => { if (ending && !history.length) onEnded({ history: localHistory(), durationSec: startedAt ? Math.round((Date.now() - startedAt) / 1000) : 0 }); }, 4000);
    } else onEnded({ history: localHistory(), durationSec: startedAt ? Math.round((Date.now() - startedAt) / 1000) : 0 });
  });

  /** Fallback transcript rebuilt from the bubbles if the server didn't send one. */
  function localHistory() {
    return Array.from(thread.querySelectorAll('.bubble-wrap')).map(w => ({ role: w.classList.contains('agent') ? 'agent' : 'client', text: w.querySelector('.bubble').textContent })).filter(m => m.text.trim());
  }

  async function onEnded(msg) {
    if (history.length) return;
    history = (msg.history && msg.history.length ? msg.history : localHistory());
    durationSec = msg.durationSec || 0;
    stopMic(); flushPlayback(); clearInterval(timer);
    ending = true; endBtn.hidden = true; muteBtn.hidden = true;
    if (!history.some(m => m.role === 'agent')) {
      systemLine('Nothing to score: you did not say anything the client could hear. Start a new ticket to try again.', 'error');
      sessionStorage.removeItem('sdt_session');
      const a = el('a', 'btn btn-primary', 'Back to setup'); a.href = '/setup'; a.style.alignSelf = 'center'; thread.appendChild(a);
      return;
    }
    const finalStatus = lastStatus !== 'ongoing' ? lastStatus : 'ended_by_agent';
    const line = systemLine('Generating your report...');
    try {
      const report = await api('/api/session/score', { method: 'POST', body: { moodId: session.moodId, scenarioId: session.scenarioId, ticketId: session.ticketId, finalStatus, history, durationSec, mode: 'voice' } });
      session.ended = true; save(); sessionStorage.removeItem('sdt_session');
      window.location.replace('/report?id=' + encodeURIComponent(report.reportId) + '&fresh=1');
    } catch (err) {
      line.remove();
      const l = systemLine('', 'error');
      l.innerHTML = 'Could not generate your report: ' + escapeHtml(err.message) + ' <button type="button" class="link-btn" id="retry-score">Try again</button>';
      $('#retry-score').addEventListener('click', () => { l.remove(); history = []; onEnded({ history, durationSec }); });
    }
  }

  window.addEventListener('beforeunload', (e) => { if (ws && ws.readyState === WebSocket.OPEN && !ending) { e.preventDefault(); e.returnValue = ''; } });
});
