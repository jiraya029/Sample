/* Service Desk Trainer — shared frontend runtime (no build step, no deps) */
(function (global) {
  'use strict';

  /* ---------------- tiny DOM helpers ---------------- */
  const $ = (sel, root) => (root || document).querySelector(sel);
  const $$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  function el(tag, cls, text) {
    const n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const reducedMotion = () => window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------------- icons (one family, 1.75 stroke) ---------------- */
  const ICONS = {
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
    moon: '<path d="M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5Z"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M3 3l18 18M10.6 10.6a3 3 0 0 0 4.2 4.2M9.9 5.1A10.4 10.4 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-3.2 4.2M6.6 6.6C3.9 8.6 2 12 2 12s3.5 7 10 7c1.5 0 2.9-.3 4.1-.8"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    alert: '<circle cx="12" cy="12" r="9"/><path d="M12 8v4M12 16h.01"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>',
    x: '<path d="M18 6 6 18M6 6l12 12"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
    download: '<path d="M12 3v12M7 10l5 5 5-5M4 19h16"/>',
    chevron: '<path d="m6 9 6 6 6-6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    arrowLeft: '<path d="M19 12H5M11 18l-6-6 6-6"/>',
    send: '<path d="m4 12 16-8-4 16-4-6-8-2Z"/>',
    thumbUp: '<path d="M7 11v9H4v-9h3Zm0 0 4-7a2 2 0 0 1 3 2v4h4.5a2 2 0 0 1 2 2.3l-1.2 6A2 2 0 0 1 17.3 20H7"/>',
    wrench: '<path d="M14.7 6.3a4 4 0 0 0 5 5l-9.4 9.4a2 2 0 0 1-2.8-2.8l9.4-9.4a4 4 0 0 0-2.2-2.2Z"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M10.8 12.2 20 3M15 8l3 3M18 5l2 2"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/>'
  };
  function icon(name, cls) {
    return '<svg class="icon ' + (cls || '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (ICONS[name] || '') + '</svg>';
  }

  /* ---------------- API ---------------- */
  class ApiError extends Error {
    constructor(message, status, fields) { super(message); this.status = status; this.fields = fields || null; }
  }

  const API_BASE = ((window.SDT_CONFIG && window.SDT_CONFIG.apiBase) || '').replace(/\/$/, '');
  const apiUrl = (path) => (path.startsWith('/api/') ? API_BASE + path : path);

  async function api(path, opts) {
    // 'include' (not 'same-origin'): in the serverless deployment the API lives on
    // API Gateway while these pages are served from S3/CloudFront.
    const init = Object.assign({ headers: {}, credentials: 'include' }, opts || {});
    if (init.body && typeof init.body !== 'string') init.body = JSON.stringify(init.body);
    if (init.body) init.headers['Content-Type'] = 'application/json';
    let res;
    try { res = await fetch(apiUrl(path), init); }
    catch (e) { throw new ApiError('You appear to be offline. Check your connection and try again.', 0); }
    let data = null;
    const ct = res.headers.get('content-type') || '';
    if (ct.includes('application/json')) { try { data = await res.json(); } catch (e) { data = null; } }
    if (!res.ok) {
      if (res.status === 401 && !path.startsWith('/api/auth') && path !== '/api/me') {
        toast.error('Session expired', 'Please sign in again.');
        setTimeout(() => { window.location.href = '/login'; }, 800);
      }
      throw new ApiError((data && data.error) || ('Request failed (' + res.status + ')'), res.status, data && data.fields);
    }
    return data;
  }

  /**
   * POST and read a server-sent-event stream. handlers: { partial, done, error }.
   * Returns an abort function.
   */
  function apiStream(path, body, handlers) {
    const ctrl = new AbortController();
    (async () => {
      let res;
      try {
        res = await fetch(apiUrl(path), { method: 'POST', credentials: 'include', signal: ctrl.signal, headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' }, body: JSON.stringify(body) });
      } catch (e) {
        if (ctrl.signal.aborted) return;
        return handlers.error && handlers.error(new ApiError('You appear to be offline. Check your connection and try again.', 0));
      }
      if (!res.ok || !res.body) {
        let data = null; try { data = await res.json(); } catch (e) { /* ignore */ }
        return handlers.error && handlers.error(new ApiError((data && data.error) || 'Request failed (' + res.status + ')', res.status));
      }
      const reader = res.body.getReader();
      const dec = new TextDecoder();
      let buf = '', evName = 'message', dataLines = [];
      const dispatch = () => {
        if (!dataLines.length) return;
        let payload = null;
        try { payload = JSON.parse(dataLines.join('\n')); } catch (e) { payload = null; }
        dataLines = [];
        if (evName === 'error') handlers.error && handlers.error(new ApiError((payload && payload.error) || 'The stream failed.', 500));
        else if (handlers[evName]) handlers[evName](payload);
        evName = 'message';
      };
      try {
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += dec.decode(value, { stream: true });
          let i;
          while ((i = buf.indexOf('\n')) >= 0) {
            const line = buf.slice(0, i).replace(/\r$/, ''); buf = buf.slice(i + 1);
            if (line === '') dispatch();
            else if (line.startsWith('event:')) evName = line.slice(6).trim();
            else if (line.startsWith('data:')) dataLines.push(line.slice(5).trim());
          }
        }
        dispatch();
        handlers.close && handlers.close();
      } catch (e) {
        if (!ctrl.signal.aborted) handlers.error && handlers.error(new ApiError('Connection to the client simulator dropped.', 0));
      }
    })();
    return () => ctrl.abort();
  }

  /* ---------------- toasts ---------------- */
  let toastRegion = null;
  function ensureToastRegion() {
    if (!toastRegion) {
      toastRegion = el('div', 'toast-region');
      toastRegion.setAttribute('aria-live', 'polite');
      toastRegion.setAttribute('role', 'status');
      document.body.appendChild(toastRegion);
    }
    return toastRegion;
  }
  function showToast(type, title, msg, opts) {
    const region = ensureToastRegion();
    const t = el('div', 'toast ' + type);
    t.innerHTML = icon({ success: 'check', error: 'alert', info: 'info', warn: 'alert' }[type] || 'info') +
      '<div class="toast-body"><div class="toast-title">' + escapeHtml(title) + '</div>' + (msg ? '<div class="toast-msg">' + escapeHtml(msg) + '</div>' : '') + '</div>' +
      '<button class="toast-close" aria-label="Dismiss">' + icon('x') + '</button>';
    const remove = () => { if (!t.isConnected) return; t.classList.add('leaving'); setTimeout(() => t.remove(), reducedMotion() ? 0 : 220); };
    t.querySelector('.toast-close').addEventListener('click', remove);
    region.appendChild(t);
    const ttl = (opts && opts.duration) || (type === 'error' ? 7000 : 4500);
    const timer = setTimeout(remove, ttl);
    t.addEventListener('mouseenter', () => clearTimeout(timer), { once: true });
    return remove;
  }
  const toast = {
    success: (t, m, o) => showToast('success', t, m, o),
    error: (t, m, o) => showToast('error', t, m, o),
    info: (t, m, o) => showToast('info', t, m, o),
    warn: (t, m, o) => showToast('warn', t, m, o)
  };

  /* ---------------- modal (replaces confirm()/prompt()) ---------------- */
  function modal({ title, body, confirmText = 'Confirm', cancelText = 'Cancel', danger = false, render, onConfirm }) {
    return new Promise((resolve) => {
      const previouslyFocused = document.activeElement;
      const wrap = el('div', 'modal');
      wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true'); wrap.setAttribute('aria-labelledby', 'modal-title');
      const card = el('div', 'modal-card');
      card.innerHTML = '<h2 id="modal-title">' + escapeHtml(title) + '</h2>' + (body ? '<p>' + escapeHtml(body) + '</p>' : '') + '<div class="modal-body" hidden></div>' +
        '<div class="modal-actions"><button class="btn btn-ghost" data-act="cancel">' + escapeHtml(cancelText) + '</button>' +
        '<button class="btn ' + (danger ? 'btn-danger' : 'btn-primary') + '" data-act="ok">' + escapeHtml(confirmText) + '</button></div>';
      wrap.appendChild(card);
      const bodyEl = card.querySelector('.modal-body');
      const okBtn = card.querySelector('[data-act="ok"]');
      let ctx = {};
      if (render) { bodyEl.hidden = false; ctx = render(bodyEl) || {}; }
      const close = (val) => { wrap.remove(); document.removeEventListener('keydown', onKey); previouslyFocused && previouslyFocused.focus && previouslyFocused.focus(); resolve(val); };
      const onKey = (e) => { if (e.key === 'Escape') close(false); if (e.key === 'Tab') trapFocus(e); };
      const trapFocus = (e) => {
        const f = $$('button, input, select, textarea, [tabindex]:not([tabindex="-1"])', card).filter(x => !x.disabled);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      };
      card.querySelector('[data-act="cancel"]').addEventListener('click', () => close(false));
      wrap.addEventListener('click', (e) => { if (e.target === wrap) close(false); });
      okBtn.addEventListener('click', async () => {
        if (!onConfirm) return close(true);
        okBtn.dataset.state = 'loading';
        try { const r = await onConfirm(ctx); if (r !== false) close(r === undefined ? true : r); }
        catch (err) { toast.error('Action failed', err.message); }
        finally { delete okBtn.dataset.state; }
      });
      document.addEventListener('keydown', onKey);
      document.body.appendChild(wrap);
      (ctx.focus || okBtn).focus();
    });
  }

  /* ---------------- skeletons ---------------- */
  function skeleton(container, kind, count) {
    const c = typeof container === 'string' ? $(container) : container;
    if (!c) return;
    c.innerHTML = '';
    c.setAttribute('aria-busy', 'true');
    if (kind === 'rows') {
      const wrap = el('div', 'table-wrap'); const t = el('table', 'table'); const tb = el('tbody');
      for (let i = 0; i < (count || 5); i++) {
        const tr = el('tr'); tr.innerHTML = '<td colspan="7"><div class="skel skel-line" style="width:' + (60 + (i * 13) % 35) + '%"></div></td>'; tb.appendChild(tr);
      }
      t.appendChild(tb); wrap.appendChild(t); c.appendChild(wrap);
    } else if (kind === 'block') {
      c.appendChild(el('div', 'skel skel-block'));
    } else if (kind === 'lines') {
      for (let i = 0; i < (count || 3); i++) { const l = el('div', 'skel skel-line'); l.style.width = (90 - i * 20) + '%'; l.style.marginBottom = '10px'; c.appendChild(l); }
    }
  }
  function unskeleton(container) { const c = typeof container === 'string' ? $(container) : container; if (c) c.removeAttribute('aria-busy'); }
  function setStatSkeleton(on) {
    $$('.stat-value').forEach(v => { v.classList.toggle('skel', on); if (on) v.textContent = '00'; });
  }

  /* ---------------- forms ---------------- */
  function setFieldError(input, msg) {
    const field = input.closest('.field');
    const err = field && field.querySelector('.field-error');
    input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (err) { err.innerHTML = msg ? icon('alert') + '<span>' + escapeHtml(msg) + '</span>' : ''; err.id = err.id || (input.id + '-error'); }
    if (msg && err) input.setAttribute('aria-describedby', err.id); else input.removeAttribute('aria-describedby');
  }
  function clearFieldErrors(root) { $$('.input, .select', root).forEach(i => setFieldError(i, '')); }
  /** Apply server-side { fields: {name: msg} } to inputs by data-field attribute. */
  function applyFieldErrors(root, fields) {
    if (!fields) return false;
    let first = null;
    Object.entries(fields).forEach(([k, msg]) => {
      const input = $('[data-field="' + k + '"]', root);
      if (input) { setFieldError(input, msg); first = first || input; }
    });
    if (first) first.focus();
    return Boolean(first);
  }
  const validators = {
    required: (v) => (v.trim() ? null : 'This field is required.'),
    email: (v) => (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? null : 'Enter a valid email address.'),
    password: (v) => {
      if (v.length < 8) return 'Use at least 8 characters.';
      if (!/[A-Za-z]/.test(v) || !/\d/.test(v)) return 'Include at least one letter and one number.';
      return null;
    }
  };
  function passwordStrength(pw) {
    let s = 0;
    if (pw.length >= 8) s++;
    if (pw.length >= 12) s++;
    if (/[A-Z]/.test(pw) && /[a-z]/.test(pw)) s++;
    if (/\d/.test(pw) && /[^A-Za-z0-9]/.test(pw)) s++;
    return Math.min(4, s);
  }
  function bindPasswordToggle(btn, input) {
    btn.innerHTML = icon('eye');
    btn.setAttribute('aria-label', 'Show password');
    btn.addEventListener('click', () => {
      const show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      btn.innerHTML = icon(show ? 'eyeOff' : 'eye');
      btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      input.focus();
    });
  }
  function bindLiveValidation(input, fn) {
    let touched = false;
    input.addEventListener('blur', () => { touched = true; setFieldError(input, fn(input.value)); });
    input.addEventListener('input', () => { if (touched || input.getAttribute('aria-invalid') === 'true') setFieldError(input, fn(input.value)); });
  }
  /** Digits only, auto-submit at 6, paste-friendly. */
  function bindCodeInput(input, onComplete) {
    input.setAttribute('inputmode', 'numeric'); input.setAttribute('autocomplete', 'one-time-code'); input.maxLength = 6;
    input.addEventListener('input', () => {
      const v = input.value.replace(/\D/g, '').slice(0, 6);
      if (v !== input.value) input.value = v;
      setFieldError(input, '');
      if (v.length === 6 && onComplete) onComplete(v);
    });
    input.addEventListener('paste', (e) => {
      const t = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g, '').slice(0, 6);
      if (t) { e.preventDefault(); input.value = t; input.dispatchEvent(new Event('input')); }
    });
  }
  function busy(btn, on) { if (!btn) return; if (on) { btn.dataset.state = 'loading'; btn.disabled = true; } else { delete btn.dataset.state; btn.disabled = false; } }
  function banner(sel, type, msg) {
    const b = $(sel); if (!b) return;
    if (!msg) { b.hidden = true; b.innerHTML = ''; return; }
    b.className = 'banner ' + type; b.hidden = false;
    b.innerHTML = icon({ error: 'alert', success: 'check', info: 'info', warn: 'alert' }[type] || 'info') + '<div>' + escapeHtml(msg) + '</div>';
  }

  /* ---------------- theme ---------------- */
  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    try { localStorage.setItem('sdt_theme', theme); } catch (e) { /* ignore */ }
    const btn = $('#theme-toggle');
    if (btn) { btn.innerHTML = icon(theme === 'light' ? 'moon' : 'sun'); btn.setAttribute('aria-label', theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'); }
  }
  function initTheme() {
    // Light is the default; a stored choice always wins.
    let theme = 'light';
    try { theme = localStorage.getItem('sdt_theme') || 'light'; } catch (e) { /* ignore */ }
    applyTheme(theme);
    const btn = $('#theme-toggle');
    if (btn) btn.addEventListener('click', () => applyTheme(document.documentElement.getAttribute('data-theme') === 'light' ? 'dark' : 'light'));
  }

  /* ---------------- auth + topbar ---------------- */
  async function currentUser() {
    try { return await api('/api/me'); } catch (e) { return null; }
  }
  /** Redirects to /login when signed out. Pass {admin:true} to also require the admin role. */
  async function requireAuth(opts) {
    const user = await currentUser();
    if (!user) { window.location.replace('/login?next=' + encodeURIComponent(location.pathname + location.search)); return null; }
    if (opts && opts.admin && user.role !== 'admin') { window.location.replace('/dashboard'); return null; }
    wireTopbar(user);
    return user;
  }
  function wireTopbar(user) {
    const home = user ? (user.role === 'admin' ? '/admin' : '/dashboard') : '/login';
    const brand = $('#brand-home'); if (brand) brand.addEventListener('click', () => { window.location.href = home; });
    const w = $('#welcome-text'); if (w && user) { w.textContent = user.name; w.hidden = false; }
    const nav = $('#nav-links');
    if (nav && user) {
      const links = user.role === 'admin' ? [['/admin', 'Admin']] : [['/dashboard', 'Dashboard'], ['/setup', 'New ticket']];
      nav.innerHTML = links.map(([href, label]) => '<a class="nav-link" href="' + href + '"' + (location.pathname === href ? ' aria-current="page"' : '') + '>' + label + '</a>').join('');
      nav.hidden = false;
    }
    const out = $('#logout-btn');
    if (out && user) {
      out.hidden = false;
      out.addEventListener('click', async () => {
        busy(out, true);
        try { await api('/api/auth/logout', { method: 'POST' }); } catch (e) { /* ignore */ }
        sessionStorage.clear();
        window.location.href = '/login';
      });
    }
  }

  /* ---------------- formatting ---------------- */
  const OUTCOMES = { resolved: 'Resolved', escalated: 'Escalated', ended_by_agent: 'Ended by agent' };
  const outcomeLabel = (s) => OUTCOMES[s] || s || '-';
  const fmtDate = (d, o) => new Date(d).toLocaleDateString(undefined, o || { year: 'numeric', month: 'short', day: 'numeric' });
  const fmtDateTime = (d) => new Date(d).toLocaleString(undefined, { year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  const fmtRelative = (d) => {
    const diff = (Date.now() - new Date(d).getTime()) / 1000;
    if (diff < 60) return 'just now';
    if (diff < 3600) return Math.floor(diff / 60) + ' min ago';
    if (diff < 86400) return Math.floor(diff / 3600) + ' h ago';
    if (diff < 7 * 86400) return Math.floor(diff / 86400) + ' d ago';
    return fmtDate(d);
  };
  const scoreClass = (v) => (v >= 70 ? 'good' : v >= 40 ? 'mid' : 'low');
  const scoreChip = (v) => '<span class="score-chip ' + scoreClass(Number(v)) + '">' + Math.round(Number(v)) + '</span>';
  const initials = (name) => String(name || '?').split(/\s+/).slice(0, 2).map(p => p[0] || '').join('').toUpperCase();
  const fmtDuration = (sec) => { if (sec == null) return '-'; const m = Math.floor(sec / 60), s = sec % 60; return m ? m + 'm ' + String(s).padStart(2, '0') + 's' : s + 's'; };

  /* ---------------- sortable table utility ---------------- */
  function makeSortable(table, rows, renderRows, defaultKey, defaultDir) {
    let key = defaultKey, dir = defaultDir || 'desc';
    const heads = $$('th.sortable', table);
    function draw() {
      const sorted = rows.slice().sort((a, b) => {
        const av = a[key], bv = b[key];
        const r = (typeof av === 'number' && typeof bv === 'number') ? av - bv : String(av ?? '').localeCompare(String(bv ?? ''), undefined, { numeric: true });
        return dir === 'asc' ? r : -r;
      });
      heads.forEach(h => { const ind = h.querySelector('.sort-ind'); if (ind) ind.textContent = h.dataset.key === key ? (dir === 'asc' ? '\u2191' : '\u2193') : ''; h.setAttribute('aria-sort', h.dataset.key === key ? (dir === 'asc' ? 'ascending' : 'descending') : 'none'); });
      renderRows(sorted);
    }
    heads.forEach(h => h.addEventListener('click', () => { if (key === h.dataset.key) dir = dir === 'asc' ? 'desc' : 'asc'; else { key = h.dataset.key; dir = 'desc'; } draw(); }));
    draw();
    return { redraw: (newRows) => { rows = newRows; draw(); } };
  }

  /* ---------------- trend chart (SVG line) ---------------- */
  function renderTrend(container, points, opts) {
    // points: [{ x: label, y: number, meta }]
    const c = typeof container === 'string' ? $(container) : container;
    c.innerHTML = '';
    c.style.position = 'relative';
    if (!points.length) { c.innerHTML = '<div class="empty"><strong>No sessions yet</strong>Run a ticket to start your trend line.</div>'; return; }
    const W = 600, H = 220, P = { t: 14, r: 14, b: 28, l: 30 };
    const iw = W - P.l - P.r, ih = H - P.t - P.b;
    const n = points.length;
    const xs = points.map((_, i) => P.l + (n === 1 ? iw / 2 : (i / (n - 1)) * iw));
    const ys = points.map(p => P.t + ih - (Math.max(0, Math.min(100, p.y)) / 100) * ih);
    const path = xs.map((x, i) => (i ? 'L' : 'M') + x.toFixed(1) + ' ' + ys[i].toFixed(1)).join(' ');
    const area = path + ' L' + xs[n - 1].toFixed(1) + ' ' + (P.t + ih) + ' L' + xs[0].toFixed(1) + ' ' + (P.t + ih) + ' Z';
    const grid = [0, 25, 50, 75, 100].map(v => { const y = P.t + ih - (v / 100) * ih; return '<line class="grid-line" x1="' + P.l + '" x2="' + (W - P.r) + '" y1="' + y + '" y2="' + y + '"/><text class="axis-text" x="' + (P.l - 6) + '" y="' + (y + 4) + '" text-anchor="end">' + v + '</text>'; }).join('');
    const step = Math.max(1, Math.ceil(n / 6));
    const labelIdx = new Set(points.map((_, i) => i).filter(i => i % step === 0));
    labelIdx.add(n - 1);
    if (n > 1 && (n - 1) % step !== 0 && (n - 1) - Math.floor((n - 1) / step) * step < Math.max(1, step / 2)) labelIdx.delete(Math.floor((n - 1) / step) * step);
    const labels = points.map((p, i) => labelIdx.has(i) ? '<text class="axis-text" x="' + xs[i] + '" y="' + (H - 8) + '" text-anchor="middle">' + escapeHtml(p.x) + '</text>' : '').join('');
    const dots = points.map((p, i) => '<circle class="dot" data-i="' + i + '" cx="' + xs[i] + '" cy="' + ys[i] + '" r="4"><title>' + escapeHtml(p.x + ': ' + p.y) + '</title></circle>').join('');
    c.innerHTML = '<svg class="trend" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + escapeHtml((opts && opts.label) || 'Score trend') + '">' +
      '<defs><linearGradient id="trend-fill" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stop-color="var(--accent)" stop-opacity=".28"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>' +
      grid + (n > 1 ? '<path class="area" d="' + area + '"/>' : '') + '<path class="line' + (reducedMotion() ? '' : ' draw') + '" d="' + path + '"/>' + dots + labels + '</svg><div class="chart-tip" role="tooltip"></div>';
    const line = c.querySelector('.line');
    if (line && line.getTotalLength) line.style.setProperty('--len', line.getTotalLength());
    const tip = c.querySelector('.chart-tip');
    const svg = c.querySelector('svg');
    c.querySelectorAll('.dot').forEach(d => {
      d.addEventListener('mouseenter', () => {
        const p = points[Number(d.dataset.i)];
        tip.innerHTML = escapeHtml(p.x) + ' \u00b7 <b>' + escapeHtml(String(p.y)) + '</b>' + (p.meta ? ' <span class="muted">' + escapeHtml(p.meta) + '</span>' : '');
        const r = svg.getBoundingClientRect();
        tip.style.left = (Number(d.getAttribute('cx')) / W * r.width) + 'px';
        tip.style.top = (Number(d.getAttribute('cy')) / H * r.height) + 'px';
        tip.classList.add('show');
      });
      d.addEventListener('mouseleave', () => tip.classList.remove('show'));
    });
  }

  /* ---------------- shared report row rendering ---------------- */
  function reportRowHtml(r, opts) {
    const o = opts || {};
    return (o.agentCell ? '<td><div class="cell-user"><span class="avatar">' + escapeHtml(initials(r.user_name)) + '</span><div><div>' + escapeHtml(r.user_name) + '</div><div class="sub">' + escapeHtml(r.user_email || '') + '</div></div></div></td>' : '') +
      '<td class="mono">' + escapeHtml(r.ticket_id) + '</td>' +
      '<td>' + escapeHtml(r.scenario) + (r.mode === 'voice' ? ' <span class="pill neutral" title="Live voice call" style="padding:1px 8px;margin-left:6px">Voice</span>' : '') + '</td>' +
      '<td>' + escapeHtml(r.mood) + '</td>' +
      '<td>' + scoreChip(r.overall_score) + '</td>' +
      '<td><span class="pill ' + escapeHtml(r.final_status) + '">' + escapeHtml(outcomeLabel(r.final_status)) + '</span></td>' +
      '<td class="nowrap" title="' + escapeHtml(fmtDateTime(r.created_at)) + '">' + escapeHtml(fmtRelative(r.created_at)) + '</td>' +
      '<td class="actions"><a class="btn btn-sm" href="/report?id=' + encodeURIComponent(r.id) + (o.context ? '&from=' + o.context : '') + '">View</a>' +
      '<a class="btn btn-sm btn-ghost" href="' + apiUrl('/api/reports/' + encodeURIComponent(r.id) + '/download-excel') + '" title="Download Excel">' + icon('download') + '</a></td>';
  }

  /* ---------------- boot ---------------- */
  document.addEventListener('DOMContentLoaded', initTheme);
  // Apply the stored theme as early as possible to avoid a flash.
  try { const t = localStorage.getItem('sdt_theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) { /* ignore */ }

  global.SDT = {
    $, $$, el, escapeHtml, icon, api, apiStream, ApiError, toast, modal,
    skeleton, unskeleton, setStatSkeleton,
    setFieldError, clearFieldErrors, applyFieldErrors, validators, passwordStrength, bindPasswordToggle, bindLiveValidation, bindCodeInput, busy, banner,
    requireAuth, currentUser, wireTopbar, applyTheme,
    outcomeLabel, fmtDate, fmtDateTime, fmtRelative, fmtDuration, scoreClass, scoreChip, initials,
    makeSortable, renderTrend, reportRowHtml, reducedMotion, apiUrl, API_BASE
  };
})(window);
