# Service Desk Trainer — serverless build (v4)

Same application as v3, re-hosted so there is **no server and no database to run**:

| Piece | Runs on | Notes |
| --- | --- | --- |
| Frontend (all pages, CSS, JS) | **S3 + CloudFront** | Static files. A CloudFront Function maps `/login` → `login.html` like `express.static` used to. Security headers + CSP come from a CloudFront response-headers policy. |
| API (auth, OTP, chat, scoring, reports, admin) | **API Gateway + one Lambda** | The unchanged Express app, wrapped by `serverless-http`. Scales to zero. |
| Data (users, reports, codes) | **S3 objects** (`lib/s3db.js`) | One JSON object per record + small index objects. No RDS/Dynamo. |
| AI (chat client, scoring, live gauge) | **Bedrock — Claude Sonnet** | Same as v3. Lambda's execution role supplies credentials; no API key to manage. |
| Live voice relay | **App Runner** (one small always-on container) | The only non-serverless piece. See "Why voice is separate". |

## Why voice is separate

A live call is one continuous bidirectional stream to Nova Sonic for the whole conversation. Lambda invocations are stateless and per-request: each audio frame from the browser would start a *new* invocation with no access to the previous one's open stream. That is a hard platform limit, not a code problem — AWS's own Nova Sonic samples run on a persistent process for the same reason.

App Runner is the smallest "no server" way to run that process: it's a managed container with an HTTPS URL, WebSocket support, and no VPC/load balancer/certificate to define. It costs roughly a few dollars a month at the smallest size while idle; set `VoiceImageUri` empty to deploy without voice at all.

Because the voice service is a different origin from the API, the session cookie isn't sent on the WebSocket upgrade. The browser instead calls `GET /api/voice/token` for a 60-second single-purpose token and passes it as `?token=`. The service also checks `Origin` against the CloudFront domain.

## Why chat isn't streamed anymore

API Gateway's Lambda integration buffers the whole response and returns it when the invocation ends — `res.write()` chunks never reach the browser early. So `/api/session/turn` returns the complete reply as one JSON object, and `chat.js` does a client-side word-by-word reveal over it. Same feel; the network call itself is not streamed. (Voice is unaffected — it never went through API Gateway.)

## How S3 works as the database

Every access pattern the app needs is pre-computed into an index object, because S3 can't query:

```
users/by-id/<id>.json                       user record
index/users-by-email/<sha256(email)>.json   { userId }
index/users-by-sap/<sha256(sapId)>.json     { userId }
index/user-ids.json                         { ids: [...] }      admin listing
reports/by-id/<id>.json                     report (with transcript)
index/reports-by-user/<userId>.json         { ids: [...] }      newest first
index/report-ids.json                       { ids: [...] }      admin listing
otp/<userId>/<purpose>.json                 the one live code
counters/user-id.json, counters/report-id.json
```

Concurrency is the risk with a file-as-database. Every write to a shared object (an index, a counter) goes through S3 conditional writes: read with ETag → write with `If-Match` (or `If-None-Match: *` for first creation) → retry with jitter on 412. `test/s3db_test.js` deliberately races 12 concurrent signups and 8 concurrent report writes and asserts nothing is lost. Versioning is on the data bucket, which gives you an undo for any accidental overwrite.

Trade-offs to know: admin views fan out one GET per record (fine for hundreds of agents / thousands of reports; past that, add a rollup object), and there are no transactions — the code orders operations so a crash mid-write leaves an orphan, never a corrupt index.

## Who can sign in

`AllowedEmailDomains` (template parameter, default `hcltech.com,hcl.com`) restricts sign-up, sign-in and password reset to those email domains. Set it to an empty string to allow any domain. Accounts listed in `SkipOtpEmails` (the break-glass admin) are exempt.

Sign-up stores **nothing** until the emailed code is verified: the submitted details wait under `pending/` in the data bucket (auto-expired after a day by a lifecycle rule) and only become a user record when the code checks out. An abandoned or malicious attempt can therefore never reserve someone else's email or SAP ID.

## One device at a time

Signing in anywhere ends any other session on the account immediately - no
session table, just a number (`session_epoch`) baked into every JWT that only
ever goes up. Real users get a clear explanation instead of a silent failure:
a background check on every page notices within ~45s and redirects to login
with a banner ("you've been signed out - your account was signed in
elsewhere"). If the previous session still looked like it could be in active
use, the account also gets a best-effort email about it.

Admins can see who's signed in where (Admin -> Agents -> the Device column)
and end a session immediately from there - useful for an offboarded employee
or a compromised account. Note: because each Lambda execution environment
caches the epoch check for up to 60 seconds, a force-logout can take that
long to apply everywhere in the worst case, not instantly.

## Downloads

Every screen offers the same TXT + Excel pair: the dashboard (all of your reports), each report, the admin overview (all sessions, and per agent from the Agents table), and the chat/voice pages (the transcript so far, before scoring).

## Deploy

Prereqs: AWS CLI + [SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html) configured for the account; Docker only for voice.

```bash
export JWT_SECRET="$(openssl rand -base64 48)"
export ADMIN_EMAIL=you@company.com ADMIN_PASSWORD='choose-one'          # optional bootstrap admin
export SMTP_URL='smtps://user:pass@smtp.example.com:465' MAIL_FROM='Service Desk Trainer <no-reply@example.com>'  # optional but recommended

./infra/deploy.sh sdt-prod us-east-1                 # API + frontend, no voice
./infra/deploy.sh sdt-prod us-east-1 --with-voice    # also builds/pushes the voice image and deploys App Runner
```

**No local Docker?** Common on cloud-hosted VMs without nested virtualization (Docker Desktop installs but its engine never starts there - a hypervisor limit, not a settings problem). Build the image in AWS instead, via CodeBuild:
```bash
IMAGE=$(./infra/build-voice-codebuild.sh sdt-prod us-east-1 | tail -1)
VOICE_IMAGE="$IMAGE" ./infra/deploy.sh sdt-prod us-east-1 --with-voice
```
`deploy.sh` detects a missing/non-running Docker and prints this exact command itself if you run `--with-voice` without it.

The script builds and deploys the stack, writes the API URL into `public/assets/config.js`, syncs `public/` to the frontend bucket, and invalidates CloudFront. It prints the frontend URL when done.

Without SMTP configured, one-time codes are **not** delivered or logged in production (by design — see the security notes in the v3 README). Configure SMTP or your users cannot sign in.

### Model access

Bedrock model access is automatic on first use. The Lambda's execution role and the App Runner instance role are granted `bedrock:InvokeModel*` in the template; scope the `Resource` down to your model ARNs once you know them. Verify the model ids in your region's Bedrock catalog and pass `TextModelId` / `VoiceModelId` parameters if they differ from the defaults.

### Custom domains (optional, recommended)

Out of the box the frontend is `https://<id>.cloudfront.net` and the API is `https://<id>.execute-api.<region>.amazonaws.com`. Because these are different sites, cookies use `SameSite=None; Secure`. If you add custom domains under one parent (e.g. `app.example.com`, `api.example.com`), set `COOKIE_DOMAIN=.example.com` on the Lambda and the cookie becomes same-site (`Lax`), which is stricter.

## Local development

```bash
npm install
cp .env.example .env    # DATA_BUCKET (a real bucket your AWS creds can reach), JWT_SECRET, AWS_REGION
npm start               # API on :3000
python3 -m http.server 8080 --directory public   # frontend; set apiBase in public/assets/config.js to http://localhost:3000 and FRONTEND_ORIGIN=http://localhost:8080 in .env
npm run start:voice     # optional, :8080 -> set VOICE_WS_URL=ws://localhost:8080/ws/voice in .env
```

## Tests

```bash
npm test
```

Three suites, no AWS calls:

- `test/s3db_test.js` — the S3 data layer against an in-memory S3 with real ETag / conditional-write semantics, including the concurrency races.
- `test/bedrock_voice_test.js` — Bedrock provider + Nova Sonic protocol against fakes.
- `test/serverless_test.js` — the real `lambda/handler.js` invoked with API Gateway v2 events end to end (signup → code → login → chat → score → report → Excel → admin), CORS and cookie behaviour, plus the voice service over a real WebSocket with token auth.

## Cost (rough, idle-to-light use)

S3, CloudFront, API Gateway and Lambda are all pay-per-request and effectively free at training-tool volumes (well inside free tiers for the first year, pennies after). App Runner for voice is the only fixed cost: about $5/month for the smallest instance when it's running; you can pause the service between training sessions. Bedrock usage is per token / per second of audio, as before.

## Files

```
server.js            Express app (unchanged routes; s3db backend; CORS; no static serving)
lambda/handler.js    API Gateway -> Express adapter, normalises Set-Cookie into cookies[]
voice-server.js      Always-on voice relay entry point (App Runner)
Dockerfile.voice     Image for the voice service
lib/s3db.js          S3-as-database layer (same interface as the old db.js)
lib/*.js             bedrock, voice, voiceGateway, catalog, excel, mailer (from v3)
auth.js              + cross-origin cookie policy, voice tokens, allow-listed CSRF origins
public/              Static frontend; assets/config.js carries the API URL
infra/template.yaml  AWS SAM: buckets, CloudFront, HTTP API, Lambda, App Runner, IAM
infra/deploy.sh      One-command build + deploy + frontend upload
infra/build-voice-codebuild.sh   Builds the voice image in AWS (CodeBuild) when local Docker isn't available
infra/codebuild-voice.yaml       CFN for the CodeBuild project used by the script above
infra/buildspec-voice.yml        Its buildspec
```
