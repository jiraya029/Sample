document.addEventListener('DOMContentLoaded', async () => {
  const { $, api, toast, banner, busy, setFieldError, clearFieldErrors, applyFieldErrors, validators, passwordStrength, bindPasswordToggle, bindLiveValidation, bindCodeInput, currentUser } = SDT;

  const next = new URLSearchParams(location.search).get('next');
  const afterAuth = (user) => {
    const dest = user.role === 'admin' ? '/admin' : '/dashboard';
    window.location.replace(next && next.startsWith('/') && !next.startsWith('//') ? next : dest);
  };

  const existing = await currentUser();
  if (existing) return afterAuth(existing);

  /* ---- panes ---- */
  const panes = { login: $('#pane-login'), signup: $('#pane-signup'), forgot: $('#pane-forgot'), otp: $('#pane-otp') };
  function show(which) {
    Object.entries(panes).forEach(([k, p]) => { p.hidden = k !== which; });
    $('#tab-login').setAttribute('aria-selected', String(which !== 'signup'));
    $('#tab-signup').setAttribute('aria-selected', String(which === 'signup'));
    $('.auth-tabs').hidden = which === 'otp';
    Object.keys(panes).forEach(k => banner('#' + k + '-banner', 'error', ''));
    const first = panes[which].querySelector('.input:not([hidden])'); if (first) first.focus();
  }
  $('#brand-home').addEventListener('click', () => show('login'));
  $('#tab-login').addEventListener('click', () => show('login'));
  $('#tab-signup').addEventListener('click', () => show('signup'));
  $('#go-signup').addEventListener('click', () => show('signup'));
  $('#go-login').addEventListener('click', () => show('login'));
  $('#go-forgot').addEventListener('click', () => { forgotStep(1); show('forgot'); });
  $('#forgot-back').addEventListener('click', () => show('login'));
  $('#otp-back').addEventListener('click', () => { challenge = null; show('login'); });
  if (location.hash === '#signup') show('signup');
  if (location.hash === '#forgot') show('forgot');

  bindPasswordToggle($('#login-pw-toggle'), $('#login-password'));
  bindPasswordToggle($('#su-pw-toggle'), $('#su-password'));
  bindPasswordToggle($('#fg-pw-toggle'), $('#fg-password'));

  /* ---- one-time code helpers ---- */
  let challenge = null;
  function describeDelivery(r, sentToSel, bannerSel) {
    $(sentToSel).textContent = 'Sent to ' + r.email + ' · valid ' + r.ttlMin + ' min';
    if (r.devCode) banner(bannerSel, 'warn', 'Email is not configured on this server, so here is your code: ' + r.devCode);
  }
  function startCooldown(btn) {
    let left = 30; btn.disabled = true; const label = btn.textContent;
    const t = setInterval(() => { left--; btn.textContent = left > 0 ? 'Resend in ' + left + 's' : label; if (left <= 0) { clearInterval(t); btn.disabled = false; } }, 1000);
    btn.textContent = 'Resend in 30s';
  }
  async function resend(btn, sentToSel, bannerSel) {
    if (!challenge) return;
    busy(btn, true);
    try {
      const r = await api('/api/auth/resend', { method: 'POST', body: { challenge } });
      challenge = r.challenge; describeDelivery(r, sentToSel, bannerSel);
      toast.success('New code sent');
      busy(btn, false); startCooldown(btn);
    } catch (err) { busy(btn, false); banner(bannerSel, 'error', err.message); }
  }
  function enterOtp(r) {
    challenge = r.challenge;
    $('#otp-code').value = '';
    describeDelivery(r, '#otp-sent-to', '#otp-banner');
    show('otp'); startCooldown($('#otp-resend'));
  }
  $('#otp-resend').addEventListener('click', () => resend($('#otp-resend'), '#otp-sent-to', '#otp-banner'));
  $('#fg-resend').addEventListener('click', () => resend($('#fg-resend'), '#fg-sent-to', '#forgot-banner'));

  /* ---- sign in ---- */
  bindLiveValidation($('#login-email'), validators.email);
  panes.login.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors(panes.login); banner('#login-banner', 'error', '');
    const email = $('#login-email').value.trim(), password = $('#login-password').value;
    let bad = false;
    if (validators.email(email)) { setFieldError($('#login-email'), validators.email(email)); bad = true; }
    if (!password) { setFieldError($('#login-password'), 'Enter your password.'); bad = true; }
    if (bad) return;
    busy($('#login-btn'), true);
    try {
      const r = await api('/api/auth/login', { method: 'POST', body: { email, password } });
      busy($('#login-btn'), false);
      if (r.otpRequired) { $('#otp-lede').textContent = 'We sent a 6-digit code to your email. Enter it below to finish signing in.'; return enterOtp(r); }
      toast.success('Signed in', 'Welcome back, ' + r.name.split(' ')[0] + '.');
      afterAuth(r);
    } catch (err) {
      banner('#login-banner', 'error', err.message);
      busy($('#login-btn'), false);
      $('#login-password').select();
    }
  });

  /* ---- verify code (sign in / sign up) ---- */
  const submitOtp = async () => {
    clearFieldErrors(panes.otp); banner('#otp-banner', 'error', '');
    const code = $('#otp-code').value.replace(/\D/g, '');
    if (code.length !== 6) return setFieldError($('#otp-code'), 'Enter the 6-digit code from your email.');
    busy($('#otp-btn'), true);
    try {
      const user = await api('/api/auth/verify', { method: 'POST', body: { challenge, code, trustDevice: $('#otp-trust').checked } });
      toast.success('Signed in', 'Welcome, ' + user.name.split(' ')[0] + '.');
      afterAuth(user);
    } catch (err) {
      busy($('#otp-btn'), false);
      if (!applyFieldErrors(panes.otp, err.fields)) banner('#otp-banner', 'error', err.message);
      if (err.status === 400 && /expired|Too many/.test(err.message)) $('#otp-resend').disabled = false;
      $('#otp-code').select();
    }
  };
  bindCodeInput($('#otp-code'), submitOtp);
  panes.otp.addEventListener('submit', (e) => { e.preventDefault(); submitOtp(); });

  /* ---- sign up ---- */
  const su = { name: $('#su-name'), email: $('#su-email'), sapId: $('#su-sap'), project: $('#su-project'), lob: $('#su-lob'), password: $('#su-password'), confirm: $('#su-confirm') };
  bindLiveValidation(su.name, validators.required);
  bindLiveValidation(su.email, validators.email);
  bindLiveValidation(su.sapId, validators.required);
  bindLiveValidation(su.project, validators.required);
  bindLiveValidation(su.lob, validators.required);
  bindLiveValidation(su.password, validators.password);
  bindLiveValidation(su.confirm, (v) => (v === su.password.value ? null : 'Passwords do not match.'));
  su.password.addEventListener('input', () => {
    const lvl = passwordStrength(su.password.value);
    $('#su-strength').dataset.level = su.password.value ? String(Math.max(1, lvl)) : '0';
    $('#su-strength-hint').textContent = !su.password.value ? 'At least 8 characters, including a letter and a number.' : ['Too short', 'Weak', 'Okay', 'Good', 'Strong'][lvl];
  });
  panes.signup.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors(panes.signup); banner('#signup-banner', 'error', '');
    const body = { name: su.name.value.trim(), email: su.email.value.trim(), sapId: su.sapId.value.trim(), project: su.project.value.trim(), lob: su.lob.value.trim(), password: su.password.value, confirmPassword: su.confirm.value };
    const errs = {
      name: validators.required(body.name), email: validators.email(body.email), sapId: validators.required(body.sapId),
      project: validators.required(body.project), lob: validators.required(body.lob), password: validators.password(body.password),
      confirmPassword: body.password === body.confirmPassword ? null : 'Passwords do not match.'
    };
    const bad = Object.fromEntries(Object.entries(errs).filter(([, v]) => v));
    if (Object.keys(bad).length) return applyFieldErrors(panes.signup, bad);
    busy($('#signup-btn'), true);
    try {
      const r = await api('/api/auth/signup', { method: 'POST', body });
      busy($('#signup-btn'), false);
      $('#otp-lede').textContent = 'Your account is created. We sent a 6-digit code to your email to confirm it is yours.';
      enterOtp(r);
    } catch (err) {
      if (!applyFieldErrors(panes.signup, err.fields)) banner('#signup-banner', 'error', err.message);
      busy($('#signup-btn'), false);
    }
  });

  /* ---- forgot / reset ---- */
  function forgotStep(n) {
    $('#forgot-step1').hidden = n !== 1; $('#forgot-step2').hidden = n !== 2;
    $('#forgot-lede').textContent = n === 1 ? "Enter your work email and we'll send you a 6-digit code." : 'Enter the code from your email and choose a new password.';
  }
  bindLiveValidation($('#fg-email'), validators.email);
  bindLiveValidation($('#fg-password'), validators.password);
  bindLiveValidation($('#fg-confirm'), (v) => (v === $('#fg-password').value ? null : 'Passwords do not match.'));
  $('#fg-password').addEventListener('input', () => { const v = $('#fg-password').value; $('#fg-strength').dataset.level = v ? String(Math.max(1, passwordStrength(v))) : '0'; });
  bindCodeInput($('#fg-code'), () => $('#fg-password').focus());

  panes.forgot.addEventListener('submit', async (e) => {
    e.preventDefault();
    clearFieldErrors(panes.forgot); banner('#forgot-banner', 'error', '');
    if (!$('#forgot-step1').hidden) {
      const email = $('#fg-email').value.trim();
      if (validators.email(email)) return setFieldError($('#fg-email'), validators.email(email));
      busy($('#forgot-btn'), true);
      try {
        const r = await api('/api/auth/forgot', { method: 'POST', body: { email } });
        challenge = r.challenge;
        forgotStep(2); describeDelivery(r, '#fg-sent-to', '#forgot-banner'); startCooldown($('#fg-resend'));
        if (!r.devCode) banner('#forgot-banner', 'info', 'If an account exists for that email, a code is on its way.');
        $('#fg-code').focus();
      } catch (err) { if (!applyFieldErrors(panes.forgot, err.fields)) banner('#forgot-banner', 'error', err.message); }
      busy($('#forgot-btn'), false);
      return;
    }
    const code = $('#fg-code').value.replace(/\D/g, ''), password = $('#fg-password').value, confirmPassword = $('#fg-confirm').value;
    const errs = { code: code.length === 6 ? null : 'Enter the 6-digit code from your email.', password: validators.password(password), confirmPassword: password === confirmPassword ? null : 'Passwords do not match.' };
    const bad = Object.fromEntries(Object.entries(errs).filter(([, v]) => v));
    if (Object.keys(bad).length) return applyFieldErrors(panes.forgot, bad);
    busy($('#reset-btn'), true);
    try {
      await api('/api/auth/reset', { method: 'POST', body: { challenge, code, password, confirmPassword } });
      toast.success('Password updated', 'Sign in with your new password.');
      $('#login-email').value = $('#fg-email').value.trim();
      show('login'); $('#login-password').focus();
    } catch (err) {
      if (!applyFieldErrors(panes.forgot, err.fields)) banner('#forgot-banner', 'error', err.message);
    }
    busy($('#reset-btn'), false);
  });
});
