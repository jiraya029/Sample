// auth.js
// Password hashing, session cookies (JWT), route guards, one-time codes, and
// the "trust this device" cookie that lets a user skip the login code for 30 days.

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const IS_PROD = process.env.NODE_ENV === 'production';
const TOKEN_COOKIE = 'sdt_token';
const DEVICE_COOKIE = 'sdt_device';
const TOKEN_TTL_SEC = 8 * 60 * 60;
const DEVICE_TTL_SEC = 30 * 24 * 60 * 60;
const OTP_TTL_MIN = 10;
const CHALLENGE_TTL_SEC = 15 * 60;
const PASSWORD_MIN = 8;

let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (IS_PROD) throw new Error('[auth] JWT_SECRET must be set in production.');
  JWT_SECRET = 'dev-secret-change-me';
  console.warn('[auth] JWT_SECRET is not set; using an insecure development secret.');
}

// A real bcrypt hash of a random string. Compared against when the email is
// unknown so a failed login takes the same time whether or not the account exists.
const DUMMY_HASH = bcrypt.hashSync(crypto.randomBytes(16).toString('hex'), 10);

/* ---------------- passwords ---------------- */

function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < PASSWORD_MIN) return 'Password must be at least ' + PASSWORD_MIN + ' characters.';
  if (pw.length > 128) return 'Password is too long.';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Password must include at least one letter and one number.';
  return null;
}
const hashPassword = (plain) => bcrypt.hash(plain, 10);
const verifyPassword = (plain, hash) => bcrypt.compare(plain, hash || DUMMY_HASH);

/* ---------------- session cookie ---------------- */

// Cross-origin by default here (S3/CloudFront frontend, API Gateway API):
// browsers require SameSite=None + Secure for the cookie to be sent at all.
// Set COOKIE_DOMAIN (e.g. .example.com, with both origins under it) to make
// them same-site instead, which is simpler and safer where it's an option.
const COOKIE_DOMAIN = process.env.COOKIE_DOMAIN || undefined;
const SAME_SITE = COOKIE_DOMAIN ? 'lax' : 'none';
const cookieOpts = (maxAgeSec) => ({ httpOnly: true, sameSite: SAME_SITE, secure: SAME_SITE === 'none' ? true : IS_PROD, domain: COOKIE_DOMAIN, path: '/', maxAge: maxAgeSec * 1000 });
const clearOpts = { httpOnly: true, sameSite: SAME_SITE, secure: SAME_SITE === 'none' ? true : IS_PROD, domain: COOKIE_DOMAIN, path: '/' };

function issueToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, name: user.name, ep: user.session_epoch || 1 }, JWT_SECRET, { expiresIn: TOKEN_TTL_SEC, algorithm: 'HS256' });
}
function setAuthCookie(res, token) { res.cookie(TOKEN_COOKIE, token, cookieOpts(TOKEN_TTL_SEC)); }
function clearAuthCookie(res) { res.clearCookie(TOKEN_COOKIE, clearOpts); }

/** Populates req.user from the cookie; never blocks. Epoch is checked in requireAuth. */
function attachUser(req, res, next) {
  const token = req.cookies && req.cookies[TOKEN_COOKIE];
  req.user = null;
  if (token) { try { req.user = jwt.verify(token, JWT_SECRET, { algorithms: ['HS256'] }); } catch (e) { req.user = null; } }
  next();
}

/**
 * Session-epoch check: a password change bumps users.session_epoch, so tokens
 * minted earlier are rejected. Cached per process for 60s to avoid a DB hit on
 * every request.
 */
const epochCache = new Map();
function makeEpochGuard(getSessionEpoch) {
  return async function checkEpoch(req, res) {
    const cached = epochCache.get(req.user.sub);
    let epoch;
    if (cached && cached.until > Date.now()) epoch = cached.epoch;
    else {
      try { epoch = await getSessionEpoch(req.user.sub); } catch (e) { return true; } // DB down: let the route return 503
      epochCache.set(req.user.sub, { epoch, until: Date.now() + 60000 });
    }
    if (epoch === null || (req.user.ep || 1) !== epoch) {
      clearAuthCookie(res);
      res.status(401).json({ error: 'Your session has been signed out. Please sign in again.' });
      return false;
    }
    return true;
  };
}
const forgetEpoch = (userId) => epochCache.delete(userId);

function requireAuthWith(checkEpoch) {
  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
    if (await checkEpoch(req, res)) next();
  };
}
function requireAdminWith(checkEpoch) {
  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
    if (await checkEpoch(req, res)) next();
  };
}

/**
 * CSRF second layer on top of SameSite cookies. The request's Origin must be
 * either this API's own host or one of the configured frontend origins - in
 * the serverless build the frontend (CloudFront) and API (API Gateway) are
 * different origins by design, so "same host only" would block every login.
 */
const ALLOWED_ORIGINS = (process.env.FRONTEND_ORIGIN || '').split(',').map(s => s.trim()).filter(Boolean);
function sameOrigin(req, res, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (!origin) return next();
  const host = req.get('x-forwarded-host') || req.get('host');
  try {
    if (new URL(origin).host === host || ALLOWED_ORIGINS.includes(origin)) return next();
  } catch (e) { /* fall through */ }
  return res.status(403).json({ error: 'Cross-origin request blocked.' });
}

/* ---------------- one-time codes ---------------- */

const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

/** Six digits from a CSPRNG. The hash is keyed per user+purpose so codes can't be cross-matched. */
function newOtp(userId, purpose) {
  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  return { code, codeHash: hashOtp(userId, purpose, code), expiresAt: new Date(Date.now() + OTP_TTL_MIN * 60 * 1000) };
}
const hashOtp = (userId, purpose, code) => sha256(JWT_SECRET + '|' + userId + '|' + purpose + '|' + String(code).replace(/\D/g, ''));

/**
 * The challenge is a short-lived signed token handed to the browser between
 * "we sent you a code" and "here is the code". It carries no secrets, only the
 * otp row id, user id and purpose, so the server stays stateless. For unknown
 * emails a decoy challenge (uid 0) is issued so the response looks identical.
 */
function signChallenge(payload) { return jwt.sign({ ...payload, typ: 'otp' }, JWT_SECRET, { expiresIn: CHALLENGE_TTL_SEC, algorithm: 'HS256' }); }
function readChallenge(token, purpose) {
  try {
    const p = jwt.verify(String(token), JWT_SECRET, { algorithms: ['HS256'] });
    return p.typ === 'otp' && p.purpose === purpose ? p : null;
  } catch (e) { return null; }
}

/* ---------------- email domain policy ---------------- */
// Only these domains may sign up or sign in (ALLOWED_EMAIL_DOMAINS, comma-
// separated, e.g. "hcltech.com,hcl.com"). Empty = no restriction. Break-glass
// accounts listed in SKIP_OTP_EMAILS are exempt so a bootstrap admin at an
// internal/fake domain can still get in.
const ALLOWED_DOMAINS = (process.env.ALLOWED_EMAIL_DOMAINS || '').split(',').map(s => s.trim().toLowerCase().replace(/^@/, '')).filter(Boolean);
const BREAK_GLASS_EMAILS = (process.env.SKIP_OTP_EMAILS || '').split(',').map(s => s.trim().toLowerCase()).filter(Boolean);
function emailDomainAllowed(email) {
  if (!ALLOWED_DOMAINS.length) return true;
  const e = String(email || '').trim().toLowerCase();
  if (BREAK_GLASS_EMAILS.includes(e)) return true;
  const domain = e.split('@')[1] || '';
  return ALLOWED_DOMAINS.includes(domain);
}
/** "@hcltech.com or @hcl.com" - for user-facing messages. */
function allowedDomainsLabel() {
  const list = ALLOWED_DOMAINS.map(d => '@' + d);
  return list.length <= 1 ? list.join('') : list.slice(0, -1).join(', ') + ' or ' + list[list.length - 1];
}

/* ---------------- voice call tokens ---------------- */
// The voice relay runs on a different origin (Fargate) than the API (API
// Gateway), so the session cookie isn't sent on the WebSocket upgrade. The
// browser asks the API for a 60-second single-purpose token and passes it as
// ?token= on the upgrade instead.
function signVoiceToken(user) {
  return jwt.sign({ sub: user.sub || user.id, role: user.role, name: user.name, ep: user.ep || user.session_epoch || 1, typ: 'voice' }, JWT_SECRET, { expiresIn: 60, algorithm: 'HS256' });
}
function readVoiceToken(token) {
  try { const p = jwt.verify(String(token), JWT_SECRET, { algorithms: ['HS256'] }); return p.typ === 'voice' ? p : null; }
  catch (e) { return null; }
}

/* ---------------- trusted devices ---------------- */

function issueDeviceToken(user) {
  return jwt.sign({ sub: user.id, ep: user.session_epoch || 1, typ: 'device' }, JWT_SECRET, { expiresIn: DEVICE_TTL_SEC, algorithm: 'HS256' });
}
function setDeviceCookie(res, token) { res.cookie(DEVICE_COOKIE, token, cookieOpts(DEVICE_TTL_SEC)); }
function clearDeviceCookie(res) { res.clearCookie(DEVICE_COOKIE, clearOpts); }
/** True if this browser was trusted for this user since their last password change. */
function deviceTrusted(req, user) {
  const t = req.cookies && req.cookies[DEVICE_COOKIE];
  if (!t) return false;
  try { const p = jwt.verify(t, JWT_SECRET, { algorithms: ['HS256'] }); return p.typ === 'device' && p.sub === user.id && p.ep === (user.session_epoch || 1); }
  catch (e) { return false; }
}

module.exports = {
  hashPassword, verifyPassword, passwordProblem, PASSWORD_MIN,
  issueToken, setAuthCookie, clearAuthCookie, attachUser, sameOrigin,
  makeEpochGuard, forgetEpoch, requireAuthWith, requireAdminWith,
  newOtp, hashOtp, signChallenge, readChallenge, OTP_TTL_MIN,
  issueDeviceToken, setDeviceCookie, clearDeviceCookie, deviceTrusted, signVoiceToken, readVoiceToken,
  ALLOWED_DOMAINS, BREAK_GLASS_EMAILS, emailDomainAllowed, allowedDomainsLabel,
  TOKEN_COOKIE, DEVICE_COOKIE
};
