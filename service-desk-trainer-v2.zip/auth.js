// auth.js
// Password hashing, JWT issue/verify, cookie handling, route guards, and the
// helpers behind the self-service password reset flow.

const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const IS_PROD = process.env.NODE_ENV === 'production';
const TOKEN_COOKIE = 'sdt_token';
const TOKEN_TTL_SEC = 8 * 60 * 60;
const RESET_TTL_MIN = 30;

// Previously the app silently fell back to a hard-coded dev secret, which
// meant a forgotten env var in production made every session forgeable.
let JWT_SECRET = process.env.JWT_SECRET;
if (!JWT_SECRET) {
  if (IS_PROD) throw new Error('[auth] JWT_SECRET must be set in production.');
  JWT_SECRET = 'dev-secret-change-me';
  console.warn('[auth] JWT_SECRET is not set; using an insecure development secret.');
}

const PASSWORD_MIN = 8;

/** Returns an error string, or null if the password is acceptable. */
function passwordProblem(pw) {
  if (typeof pw !== 'string' || pw.length < PASSWORD_MIN) return 'Password must be at least ' + PASSWORD_MIN + ' characters.';
  if (pw.length > 128) return 'Password is too long.';
  if (!/[A-Za-z]/.test(pw) || !/\d/.test(pw)) return 'Password must include at least one letter and one number.';
  return null;
}

function hashPassword(plain) { return bcrypt.hash(plain, 10); }
function verifyPassword(plain, hash) { return bcrypt.compare(plain, hash); }

function issueToken(user) {
  return jwt.sign({ sub: user.id, role: user.role, name: user.name }, JWT_SECRET, { expiresIn: TOKEN_TTL_SEC });
}

function setAuthCookie(res, token) {
  res.cookie(TOKEN_COOKIE, token, {
    httpOnly: true, sameSite: 'lax', secure: IS_PROD, path: '/', maxAge: TOKEN_TTL_SEC * 1000
  });
}

function clearAuthCookie(res) {
  res.clearCookie(TOKEN_COOKIE, { httpOnly: true, sameSite: 'lax', secure: IS_PROD, path: '/' });
}

/** Populates req.user when a valid token is present; never blocks. */
function attachUser(req, res, next) {
  const token = req.cookies && req.cookies[TOKEN_COOKIE];
  req.user = null;
  if (token) {
    try { req.user = jwt.verify(token, JWT_SECRET); } catch (e) { req.user = null; }
  }
  next();
}

function requireAuth(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
  next();
}

function requireAdmin(req, res, next) {
  if (!req.user) return res.status(401).json({ error: 'Not signed in.' });
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admin access required.' });
  next();
}

/**
 * Cookie-based auth is protected from cross-site POSTs by SameSite=Lax, but
 * checking Origin on state-changing requests is a cheap second layer.
 */
function sameOrigin(req, res, next) {
  if (!['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method)) return next();
  const origin = req.get('origin');
  if (!origin) return next(); // non-browser clients (curl, tests)
  const host = req.get('x-forwarded-host') || req.get('host');
  try {
    if (new URL(origin).host !== host) return res.status(403).json({ error: 'Cross-origin request blocked.' });
  } catch (e) { return res.status(403).json({ error: 'Cross-origin request blocked.' }); }
  next();
}

/* -------- password reset tokens -------- */

function newResetToken() {
  const token = crypto.randomBytes(32).toString('base64url');
  return { token, tokenHash: hashResetToken(token), expiresAt: new Date(Date.now() + RESET_TTL_MIN * 60 * 1000) };
}

function hashResetToken(token) {
  return crypto.createHash('sha256').update(String(token)).digest('hex');
}

module.exports = {
  hashPassword, verifyPassword, passwordProblem, issueToken, setAuthCookie, clearAuthCookie,
  attachUser, requireAuth, requireAdmin, sameOrigin,
  newResetToken, hashResetToken, TOKEN_COOKIE, RESET_TTL_MIN, PASSWORD_MIN
};
