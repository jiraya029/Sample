#!/usr/bin/env bash
# Builds and pushes the voice-service image using AWS CodeBuild, so a
# workstation that can't run Docker (e.g. a VM with no nested virtualization,
# which is common on cloud "jump box" VMs) can still produce the image.
#
#   ./infra/build-voice-codebuild.sh <stack-name> <region>
#
# Prints the pushed image URI on success. Feed it straight into deploy.sh:
#
#   IMAGE=$(./infra/build-voice-codebuild.sh sdt-prod us-east-1 | tail -1)
#   VOICE_IMAGE="$IMAGE" ./infra/deploy.sh sdt-prod us-east-1 --with-voice
set -euo pipefail
STACK="${1:?stack name}"; REGION="${2:?region}"
cd "$(dirname "$0")/.."
HELPER_STACK="${STACK}-voice-build-helper"
TAG="$(date +%Y%m%d%H%M%S)"

echo "Deploying the CodeBuild helper stack (idempotent - safe to re-run)..." >&2
aws cloudformation deploy \
  --template-file infra/codebuild-voice.yaml \
  --stack-name "$HELPER_STACK" \
  --region "$REGION" \
  --capabilities CAPABILITY_IAM \
  --parameter-overrides StackName="$STACK" \
  --no-fail-on-empty-changeset >&2

out() { aws cloudformation describe-stacks --stack-name "$HELPER_STACK" --region "$REGION" --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
REPO_URI=$(out EcrRepositoryUri)
BUCKET=$(out SourceBucketName)
PROJECT=$(out BuildProjectName)

echo "Zipping source (excluding node_modules, .git, test fixtures)..." >&2
ZIP=/tmp/sdt-voice-source-$TAG.zip
rm -f "$ZIP"
zip -qr "$ZIP" . \
  -x "node_modules/*" ".git/*" ".aws-sam/*" "test/*" "public/*" "*.zip" ".env"

echo "Uploading source to s3://${BUCKET}/source.zip ..." >&2
aws s3 cp "$ZIP" "s3://${BUCKET}/source.zip" --region "$REGION" >&2
rm -f "$ZIP"

echo "Starting CodeBuild ($PROJECT), tag=$TAG ..." >&2
BUILD_ID=$(aws codebuild start-build \
  --project-name "$PROJECT" \
  --region "$REGION" \
  --environment-variables-override "name=IMAGE_TAG,value=$TAG,type=PLAINTEXT" \
  --query 'build.id' --output text)

echo "Build started: $BUILD_ID - polling (usually 2-4 minutes)..." >&2
STATUS="IN_PROGRESS"
while [[ "$STATUS" == "IN_PROGRESS" || "$STATUS" == "QUEUED" ]]; do
  sleep 10
  STATUS=$(aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$REGION" --query 'builds[0].buildStatus' --output text)
  echo "  status: $STATUS" >&2
done

if [[ "$STATUS" != "SUCCEEDED" ]]; then
  echo "Build did not succeed (status: $STATUS)." >&2
  echo "Logs:" >&2
  aws codebuild batch-get-builds --ids "$BUILD_ID" --region "$REGION" --query 'builds[0].logs.{group:groupName,stream:streamName}' --output text >&2
  echo "  aws logs tail <group> --log-stream-names <stream> --region $REGION" >&2
  exit 1
fi

IMAGE="${REPO_URI}:${TAG}"
echo "Build succeeded." >&2
echo "$IMAGE"
