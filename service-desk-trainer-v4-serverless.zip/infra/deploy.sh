#!/usr/bin/env bash
# One-command deploy. Prereqs: AWS CLI + SAM CLI configured for the target
# account, Docker only if you want voice mode.
#
#   ./infra/deploy.sh <stack-name> <region> [--with-voice]
#
# Set secrets via env before running:  JWT_SECRET, and optionally SMTP_URL,
# MAIL_FROM, ADMIN_EMAIL, ADMIN_PASSWORD, TEXT_MODEL_ID, VOICE_MODEL_ID.
set -euo pipefail
STACK="${1:?stack name}"; REGION="${2:?region}"; WITH_VOICE="${3:-}"
cd "$(dirname "$0")/.."
: "${JWT_SECRET:?export JWT_SECRET first (openssl rand -base64 48)}"

VOICE_IMAGE="${VOICE_IMAGE:-}"
if [[ -n "$VOICE_IMAGE" ]]; then
  echo "Using pre-built voice image: $VOICE_IMAGE (skipping local docker build)"
elif [[ "$WITH_VOICE" == "--with-voice" ]]; then
  if ! command -v docker >/dev/null 2>&1 || ! docker info >/dev/null 2>&1; then
    echo "Docker isn't available/running here." >&2
    echo "If this is a VM without nested virtualization (Docker Desktop can't start), build the" >&2
    echo "image in AWS instead - no local Docker needed:" >&2
    echo "  IMAGE=\$(./infra/build-voice-codebuild.sh $STACK $REGION | tail -1)" >&2
    echo "  VOICE_IMAGE=\"\$IMAGE\" $0 $STACK $REGION --with-voice" >&2
    exit 1
  fi
  ACCOUNT=$(aws sts get-caller-identity --query Account --output text)
  REPO="${STACK}-voice"
  aws ecr describe-repositories --repository-names "$REPO" --region "$REGION" >/dev/null 2>&1 || aws ecr create-repository --repository-name "$REPO" --region "$REGION" >/dev/null
  VOICE_IMAGE="${ACCOUNT}.dkr.ecr.${REGION}.amazonaws.com/${REPO}:$(git rev-parse --short HEAD 2>/dev/null || date +%s)"
  aws ecr get-login-password --region "$REGION" | docker login --username AWS --password-stdin "${ACCOUNT}.dkr.ecr.${REGION}.amazonaws.com"
  docker build --platform linux/amd64 -f Dockerfile.voice -t "$VOICE_IMAGE" .
  docker push "$VOICE_IMAGE"
fi

sam build -t infra/template.yaml
sam deploy -t infra/template.yaml --stack-name "$STACK" --region "$REGION" --resolve-s3 --capabilities CAPABILITY_IAM --no-fail-on-empty-changeset \
  --parameter-overrides \
    JwtSecret="$JWT_SECRET" \
    VoiceImageUri="$VOICE_IMAGE" \
    TextModelId="${TEXT_MODEL_ID:-us.anthropic.claude-sonnet-4-5-20250929-v1:0}" \
    VoiceModelId="${VOICE_MODEL_ID:-amazon.nova-sonic-v1:0}" \
    SmtpUrl="${SMTP_URL:-}" MailFrom="${MAIL_FROM:-}" AdminEmail="${ADMIN_EMAIL:-}" AdminPassword="${ADMIN_PASSWORD:-}"

out() { aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue" --output text; }
API_URL=$(out ApiUrl); BUCKET=$(out FrontendBucketName); DIST=$(out DistributionId); FRONTEND=$(out FrontendUrl)

# Point the static frontend at the API, upload it, and bust the CDN cache.
cat > public/assets/config.js <<CFG
window.SDT_CONFIG = { apiBase: '${API_URL}' };
CFG
aws s3 sync public/ "s3://${BUCKET}/" --region "$REGION" --delete --cache-control "public, max-age=300"
aws s3 cp public/assets/config.js "s3://${BUCKET}/assets/config.js" --region "$REGION" --cache-control "no-cache"
aws cloudfront create-invalidation --distribution-id "$DIST" --paths "/*" >/dev/null

echo
echo "Frontend : $FRONTEND"
echo "API      : $API_URL"
echo "Voice    : $(out VoiceWsUrl)"
